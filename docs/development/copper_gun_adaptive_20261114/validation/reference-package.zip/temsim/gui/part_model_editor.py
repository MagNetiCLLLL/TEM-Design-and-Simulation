"""Physical Layout's file-backed three-dimensional dimension workspace."""

from pathlib import Path
from copy import deepcopy
from dataclasses import replace
import math
import tomllib

from PySide6.QtCore import Qt, QSize, QTimer, Signal
from PySide6.QtGui import QBrush, QColor, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QCheckBox, QFileDialog, QHBoxLayout, QHeaderView, QLabel, QPushButton,
    QSizePolicy, QSplitter, QTabWidget, QTableWidget, QTableWidgetItem,
    QStyledItemDelegate, QTextBrowser, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)

from temsim.gui.input_policy import WheelSafeComboBox as QComboBox
from temsim.component_representation import SHARED_DEFLECTOR_HOSTS, non_material_role, representation_note
from temsim.manifest_editor import format_toml_value
from temsim.part_model_document import PartModelDocument


class _DimensionDelegate(QStyledItemDelegate):
    def sizeHint(self, option, index):
        # Leave room around wrapped semantic labels and multi-line CAD fields.
        return super().sizeHint(option, index) + QSize(0, 6)


class PartModelEditorPage(QWidget):
    component_selected = Signal(str)
    saved = Signal(str)
    tip_editor_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        from temsim.gui.part_model_view import PartModelView

        self.setObjectName("partModelEditorPage")
        self.session = None
        self._project_root = None
        self._project_paths = ()
        self._catalog_paths = ()
        self._module_origins = {}
        self._coordinate_source_bytes = {}
        self._component_dialog = None
        self._removed_selection_key = None
        self._project_save = None
        self._pending_part = None
        self._pending_reveal = False
        self._selected_key = None
        self._selected_region = "body"
        self._aperture_index = 0
        self._loading = False
        self._saving = False
        self._mesh_records = ()
        self._runtime_values = {}
        self._runtime_refresh_pending = False
        self._runtime_parameters_pending = False
        self._invalid_inputs = {}
        self._topology_selection = ()
        self._simulation_mode = None
        self._field_descriptors = {}
        self._assembly_parts = {}
        self._calculation_status = "not_calculated"
        self._calculation_detail = "No completed calculation in this window."
        self._audit_dialog = None
        self._cad_export_dialog = None
        self._cad_geometry_job = None
        self._cad_geometry_dialog = None
        self._step_import_dialog = None
        self._cad_validation_request = None
        self._cad_validation_report = None
        self._cad_validation_dialog = None
        self._cad_context_assembly = None
        self._auto_geometry_pending = False
        self._overlap_timer = QTimer(self)
        self._overlap_timer.setSingleShot(True)
        self._overlap_timer.setInterval(900)
        self._overlap_timer.timeout.connect(self._run_pending_overlap_check)
        self._region_models = {}
        self.open_button = QPushButton("Open TOML…")
        self.import_step_button = QPushButton("Import STEP…")
        self.import_step_button.setToolTip("Import exact STEP material as a mechanical component, or explicitly register it onto a selected material component. Optical settings are retained.")
        self.import_step_button.clicked.connect(self.import_step)
        self.save_button = QPushButton("Save")
        self.save_copy_button = QPushButton("Save copy…")
        self.export_step_button = QPushButton("Export STEP…")
        self.export_step_button.setToolTip("Export this module's current draft as separate optical units and a complete STEP assembly")
        self.undo_button = QPushButton("Undo")
        self.redo_button = QPushButton("Redo")
        self.revert_button = QPushButton("Revert")
        self.new_component_button = QPushButton("New component…")
        self.place_component_button = QPushButton("Place…")
        self.copy_component_button = QPushButton("Copy to assembly…")
        self.subassembly_button = QPushButton("Subassemblies / placement…")
        self._subassembly_dialog = None
        self.subassembly_button.clicked.connect(self._open_subassemblies)
        self.tip_emission_button = QPushButton("Tip model / emission…")
        self.tip_emission_button.setVisible(False)
        self.tip_emission_button.clicked.connect(self.tip_editor_requested.emit)
        self.tip_detail_button = QPushButton("Fit emitting surface")
        self.tip_detail_button.setVisible(False)
        self.tip_detail_button.clicked.connect(self._fit_tip_emission)
        self.tip_display = QComboBox()
        for label, key in (("Active emitting surface", "emission"),
                           ("Reference body", "reference"), ("Surface + reference outline", "both")):
            self.tip_display.addItem(label, key)
        self.tip_display.setVisible(False)
        self.tip_display.setToolTip("Display choice only. The saved solid and particle calculation are unchanged.")
        self.new_component_button.setToolTip("Add independent mechanical CAD geometry to this file's draft")
        self.place_component_button.setToolTip("Translate the selected component and its children; review local or resolved global Z")
        self.copy_component_button.setToolTip("Create an independent copy in this file or another assembly TOML; Save writes it")
        self.audit_button = QPushButton("Dimension audit…")
        self.audit_button.setToolTip("Review dimension meanings, evidence and missing definitions across saved modules")
        self.geometry_check_button = QPushButton("Check geometry…")
        self.geometry_check_button.setToolTip("Check the current material solids and declared optical openings in the background; electromagnetic fields are not recalculated.")
        self.geometry_check_button.clicked.connect(self.check_geometry)
        self.source_label = QLabel("Open an instrument module or select a component in Physical Layout")
        self.source_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.modules = QComboBox()
        self.modules.setPlaceholderText("Instrument storage templates")
        self.modules.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.modules.setMinimumContentsLength(12)
        self.modules.setToolTip("Storage template for the selected component. A template can reference independent subassembly files; the file label shows the actual dimension source.")
        self.load_module_button = QPushButton("Open storage file")
        self.load_module_button.setEnabled(False)
        self.scope = QComboBox()
        for label, key in (("Selected part", "part"), ("Part + neighbours", "context"), ("Entire module", "module")):
            self.scope.addItem(label, key)
        self.scope.setCurrentIndex(0)
        self.fit_button = QPushButton("Fit")
        self.iso_button = QPushButton("Isometric")
        self.front_button = QPushButton("Axial view")
        self.section = QCheckBox("Section")
        self.aperture = QComboBox()
        self.aperture.setToolTip("Preview one of the existing apertures; no new holes are created")
        self.aperture.hide()
        self.view = PartModelView()
        self.tree = QTreeWidget()
        self.tree.setObjectName("partModelTree")
        self.tree.setHeaderLabels(("Components / regions",))
        self.tree.setMinimumWidth(0)
        self.tree.setIndentation(14)
        self.tree.setSelectionMode(QTreeWidget.SelectionMode.SingleSelection)
        self.parameter_tabs = QTabWidget()
        self.parameter_tabs.setObjectName("partModelParameterTabs")
        self.dimensions = QTableWidget(0, 4)
        self.dimensions.setObjectName("partModelDimensions")
        self.dimensions.setItemDelegate(_DimensionDelegate(self.dimensions))
        self.dimensions.setHorizontalHeaderLabels(("Dimension", "Value", "Unit", "Use"))
        self.dimensions.horizontalHeaderItem(3).setToolTip(
            "Participation in the active simulation model. Inactive dimensions still update the mechanical display; select a row for the exact effects.")
        self.dimensions.verticalHeader().hide()
        self.dimensions.verticalHeader().setMinimumSectionSize(30)
        self.dimensions.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.dimensions.setWordWrap(True)
        self.dimensions.setTextElideMode(Qt.TextElideMode.ElideNone)
        self.dimensions.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.dimensions.horizontalHeader().sectionResized.connect(self.dimensions.resizeRowsToContents)
        self.dimensions.setColumnWidth(1, 88)
        self.dimensions.setColumnWidth(2, 32)
        self.dimensions.setColumnWidth(3, 65)
        self.dimensions.setAlternatingRowColors(True)
        self.parameter_tabs.addTab(self.dimensions, "Dimensions")

        materials_page = QWidget()
        material_layout = QVBoxLayout(materials_page)
        self.region = QComboBox()
        self.material = QComboBox()
        self.material.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.material.setMinimumContentsLength(12)
        from temsim.part_materials import material_catalog
        self._materials = material_catalog()
        for item in self._materials:
            self.material.addItem(item["label"], item["material_key"])
        self.material_hint = QLabel()
        self.material_hint.setWordWrap(True)
        self.material_current = QLabel()
        self.material_current.setWordWrap(True)
        self.assign_button = QPushButton("Assign to this region")
        for widget in (QLabel("Existing material region"), self.region, self.material_current,
                       QLabel("Material"), self.material, self.material_hint, self.assign_button):
            material_layout.addWidget(widget)
        material_layout.addStretch(1)
        self.parameter_tabs.addTab(materials_page, "Materials")
        self.parameters = QTreeWidget()
        self.parameters.setObjectName("partModelAllParameters")
        self.parameters.setHeaderLabels(("Related parameter", "Value"))
        self.parameters.setColumnWidth(0, 190)
        self.parameter_tabs.addTab(self.parameters, "All parameters")
        self._create_features_page()
        from temsim.gui.mechanical_overlap_panel import MechanicalOverlapPanel
        self.overlaps = MechanicalOverlapPanel(self)
        self.parameter_tabs.addTab(self.overlaps, "Mechanical overlaps")
        self.overlaps.check_requested.connect(lambda: self.check_geometry(allow_draft_conflicts=True))
        self.overlaps.auto_check.toggled.connect(self._auto_overlap_toggled)
        self.overlaps.component_requested.connect(self._overlap_component_requested)
        self.selection_label = QLabel("No component selected")
        self.selection_label.setWordWrap(True)
        self.calculation_label = QLabel("Simulation context not connected")
        self.calculation_label.setWordWrap(True)
        self.calculation_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.parameter_detail = QTextBrowser()
        self.parameter_detail.setObjectName("partModelParameterDetail")
        self.parameter_detail.setMinimumHeight(95)
        self.parameter_detail.setMaximumHeight(130)
        self.parameter_detail.setPlainText("Select a parameter to inspect its meaning, evidence and use in the active model.")
        self.model_note = QLabel()
        self.model_note.setWordWrap(True)
        self.model_note.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        side = QWidget()
        side.setMinimumWidth(0)
        side_layout = QVBoxLayout(side)
        side_layout.setContentsMargins(0, 0, 0, 0)
        side_layout.addWidget(self.selection_label)
        side_layout.addWidget(self.calculation_label)
        side_layout.addWidget(self.parameter_tabs, 1)
        side_layout.addWidget(self.parameter_detail)
        side_layout.addWidget(self.model_note)
        canvas = QWidget()
        canvas_layout = QVBoxLayout(canvas)
        canvas_layout.setContentsMargins(0, 0, 0, 0)
        canvas_layout.addWidget(self.view, 1)
        hint = QLabel("Drag: rotate freely · Right drag: pan · Wheel: zoom · Click: select a surface")
        hint.setWordWrap(True)
        canvas_layout.addWidget(hint)
        picking_row = QHBoxLayout()
        self.selection_mode = QComboBox()
        for label, mode in (("Select faces", "face"), ("Select edges", "edge"), ("Select components", "part")):
            self.selection_mode.addItem(label, mode)
        self.clear_topology_button = QPushButton("Clear selection")
        self.clear_topology_button.setToolTip("Clear selected faces and edges")
        self.topology_hint = QLabel("Select a face or edge to highlight its parameters. Ctrl-click adds to the selection.")
        self.topology_hint.setWordWrap(True)
        picking_row.addWidget(self.selection_mode)
        picking_row.addWidget(self.clear_topology_button)
        picking_row.addStretch(1)
        canvas_layout.addLayout(picking_row)
        canvas_layout.addWidget(self.topology_hint)
        self.splitter = QSplitter()
        self.splitter.setObjectName("partModelSplitter")
        self.splitter.addWidget(self.tree)
        self.splitter.addWidget(canvas)
        self.splitter.addWidget(side)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setStretchFactor(2, 0)
        self.splitter.setSizes([190, 660, 350])

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        file_row = QHBoxLayout()
        for widget in (self.open_button, self.import_step_button, self.save_button, self.save_copy_button, self.export_step_button, self.undo_button,
                       self.redo_button, self.revert_button):
            file_row.addWidget(widget)
        file_row.addWidget(self.source_label, 1)
        file_row.addWidget(self.audit_button)
        layout.addLayout(file_row)
        # Source selection and camera controls must not form one nonwrapping
        # row that forces every central workspace tab wider than the window.
        module_row = QHBoxLayout()
        module_row.addWidget(self.modules, 1)
        module_row.addWidget(self.load_module_button)
        module_row.addWidget(self.geometry_check_button)
        layout.addLayout(module_row)
        component_row = QHBoxLayout()
        for widget in (self.new_component_button, self.place_component_button, self.copy_component_button, self.subassembly_button):
            component_row.addWidget(widget)
        component_row.addWidget(self.tip_emission_button)
        component_row.addWidget(self.tip_detail_button)
        component_row.addWidget(self.tip_display)
        component_row.addStretch(1)
        layout.addLayout(component_row)
        view_row = QHBoxLayout()
        for widget in (self.scope, self.fit_button,
                       self.iso_button, self.front_button, self.section):
            view_row.addWidget(widget)
        view_row.addWidget(self.aperture)
        layout.addLayout(view_row)
        layout.addWidget(self.splitter, 1)
        self.status = QLabel("Dimensions stay in the draft until Save. The axial centre stays fixed.")
        self.status.setWordWrap(True)
        self.status.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        layout.addWidget(self.status)
        self.open_button.clicked.connect(self.open_file)
        self.save_button.clicked.connect(self.save)
        self.save_copy_button.clicked.connect(self.save_copy)
        self.export_step_button.clicked.connect(self.export_step)
        self.undo_button.clicked.connect(self.undo)
        self.redo_button.clicked.connect(self.redo)
        self.revert_button.clicked.connect(self.revert)
        self.audit_button.clicked.connect(self.show_dimension_audit)
        self.load_module_button.clicked.connect(self._open_active_module)
        self.new_component_button.clicked.connect(lambda: self._open_component_dialog("new"))
        self.place_component_button.clicked.connect(lambda: self._open_component_dialog("place"))
        self.copy_component_button.clicked.connect(lambda: self._open_component_dialog("copy"))
        self.modules.activated.connect(self._open_active_module)
        self.scope.currentIndexChanged.connect(lambda: self._render())
        self.tip_display.currentIndexChanged.connect(lambda: self._render())
        self.fit_button.clicked.connect(self.view.fit_all)
        self.iso_button.clicked.connect(self.view.set_isometric_view)
        self.front_button.clicked.connect(self.view.set_axial_view)
        self.section.toggled.connect(self.view.set_section_enabled)
        self.tree.currentItemChanged.connect(self._tree_selected)
        self.view.selection_changed.connect(self._surface_selected)
        self.view.topology_selection_changed.connect(self._topology_changed)
        self.selection_mode.currentIndexChanged.connect(
            lambda: self.view.set_selection_mode(self.selection_mode.currentData()))
        self.clear_topology_button.clicked.connect(self.view.clear_topology_selection)
        self.view.set_selection_mode(self.selection_mode.currentData())
        self.dimensions.itemChanged.connect(self._dimension_changed)
        self.dimensions.currentCellChanged.connect(self._parameter_selected)
        self.parameters.currentItemChanged.connect(self._all_parameter_selected)
        self.material.currentIndexChanged.connect(self._material_changed)
        self.region.currentIndexChanged.connect(self._region_changed)
        self.aperture.currentIndexChanged.connect(self._aperture_changed)
        self.assign_button.clicked.connect(self.assign_material)
        for sequence, slot in ((QKeySequence.StandardKey.Save, self.save),
                               (QKeySequence.StandardKey.Undo, self.undo),
                               (QKeySequence.StandardKey.Redo, self.redo)):
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
            shortcut.activated.connect(slot)
        self._material_changed()
        self._update_buttons()

    def set_project_context(self, root, assembly, save_callback, runtime_values=None):
        previous_mesh = self._runtime_mesh_dependencies()
        previous_assembly_mesh = self._runtime_mesh_dependencies(whole_assembly=True)
        previous_parameters = self._selected_runtime_values()
        self._project_root = Path(root).resolve()
        self._cad_context_assembly = assembly
        self._project_save = save_callback
        self._runtime_values = deepcopy(runtime_values or {})
        paths = tuple((self._project_root / path).resolve().relative_to(self._project_root).as_posix()
                      for _kind, path in assembly.selected_module_paths)
        self._project_paths = paths
        self._catalog_paths = self._catalog_component_paths(paths)
        self._module_origins = {}
        self._coordinate_source_bytes = {}
        self._active_tip_definitions = set()
        self._active_definition_files = set()
        from temsim.shared_tip import dependencies
        for relative in (*paths, "catalog.toml"):
            path = (self._project_root / relative).resolve()
            try:
                self._coordinate_source_bytes[path] = path.read_bytes()
                shared = dependencies(path)
                self._coordinate_source_bytes.update(shared)
                self._active_definition_files.update(shared)
                from temsim.shared_tip import raw_document, definition_path
                self._active_tip_definitions.update(source for part in raw_document(path).get("parts", ())
                                                    if (source := definition_path(path, part)) is not None)
            except OSError:
                self._coordinate_source_bytes[path] = None
        for part in getattr(assembly, "parts", ()):
            path = (self._project_root / part.source_file).resolve()
            origin = float(part.center_z_mm) - float(part.data["local_center_z_mm"])
            if math.isfinite(origin):
                self._module_origins[path] = origin
        from temsim.subassemblies import definitions, resolved_origins
        from temsim.module_manifest import read_document
        for path, origin in tuple(self._module_origins.items()):
            document = read_document(path)
            origins = resolved_origins(document)
            for entry, source, _ in definitions(document, path):
                self._module_origins[source] = origin + origins[entry["key"]]
        self.load_module_button.setEnabled(bool(self._catalog_paths))
        selected = self.modules.currentData()
        blocked = self.modules.blockSignals(True)
        self.modules.clear()
        for path in self._catalog_paths:
            self.modules.addItem(path + (" · installed" if path in paths else ""), path)
        self.modules.setCurrentIndex(max(0, self.modules.findData(selected)))
        self.modules.blockSignals(blocked)
        source_reloaded = False
        # Another editor or catalog reload may have accepted newer source
        # dimensions. Refresh a clean document, retaining unresolved drafts.
        if (self.session is not None and not self._saving
                and not self.session.dirty and not self._invalid_inputs):
            try:
                self.session.assert_source_current()
            except (OSError, ValueError):
                try:
                    self.session.reload()
                    keys = {part["key"] for part in self.session.document["parts"]}
                    if self._selected_key not in keys:
                        self._selected_key = self.session.document["parts"][0]["key"]
                        self._selected_region = "body"
                    self._topology_selection = ()
                    self._load_tree()
                    self.select_part(self._selected_key, region=self._selected_region, emit=False)
                    source_reloaded = True
                    self._message("Source reloaded from saved dimensions; view and component selection retained.")
                    self._update_buttons()
                except Exception as exc:
                    self._message(f"Source could not be reloaded: {exc}", error=True)
        if self.session is not None and not source_reloaded:
            # A module can become inactive while its document stays open, or a
            # newly loaded profile can change the working opening. Neither
            # transition may leave the old instrument's aperture in the mesh.
            self._refresh_runtime_dependencies(previous_mesh, previous_parameters, previous_assembly_mesh)
        elif source_reloaded:
            self._queue_overlap_check()
        self._sync_source_context()

    def _catalog_component_paths(self, fallback=()):
        """Module names describe storage, never a whitelist of component kinds."""
        paths = list(fallback)
        try:
            catalog = tomllib.loads((self._project_root / "catalog.toml").read_text(encoding="utf-8-sig"))
            for group, rows in catalog.items():
                if group.endswith("_variants") and isinstance(rows, list):
                    for row in rows:
                        if isinstance(row, dict) and row.get("file"):
                            path = (self._project_root / str(row["file"])).resolve()
                            if path.is_relative_to(self._project_root) and path.is_file():
                                paths.append(path.relative_to(self._project_root).as_posix())
        except (OSError, ValueError):
            # Existing active context remains usable if a catalog is temporarily
            # unavailable; saving still goes through full project validation.
            pass
        return tuple(dict.fromkeys(paths))

    def _open_component_dialog(self, action):
        if self.session is None or self._selected_key is None:
            return None
        if self._invalid_inputs:
            self._message("Correct the invalid dimension entries before changing component structure.", error=True)
            return None
        if self._component_dialog is not None:
            self._component_dialog.raise_()
            self._component_dialog.activateWindow()
            return self._component_dialog
        from temsim.gui.component_dialog import ComponentDialog
        source = self.session
        source_snapshot = deepcopy(source)
        source_key = self._selected_key
        coordinate_sources = dict(self._coordinate_source_bytes)
        target_documents = {}

        def document_for_target(path):
            path = Path(path).resolve()
            if path == source.path:
                return source_snapshot.document
            if path not in target_documents:
                target_documents[path] = PartModelDocument(path)
            return target_documents[path].document

        def stage(values):
            if self.session is not source or self._selected_key != source_key:
                raise ValueError("The selected source changed. Close and reopen this operation.")
            if source.document != source_snapshot.document:
                raise ValueError("The source draft changed. Reopen this operation to review it.")
            source_snapshot.assert_source_current()
            path = values["target_path"]
            same_file = path == source.path
            if not same_file and (source.dirty or self._invalid_inputs):
                raise ValueError("Save or Revert the source draft before copying to another file. "
                                 "A copy in the same file can include the current draft.")
            if values["coordinate_system"] == "global":
                origin = self._module_origins.get(path)
                if origin is None or origin != values["module_origin_z_mm"]:
                    raise ValueError("The installed coordinate frame changed. Reopen the operation to review its new origin.")
                for source_path, expected in coordinate_sources.items():
                    try:
                        current = source_path.read_bytes()
                    except OSError:
                        current = None
                    if current != expected or current is None:
                        raise ValueError("An installed assembly source changed or is unavailable. Reload the catalog before using global coordinates.")
            if same_file:
                candidate = deepcopy(source_snapshot)
            else:
                document_for_target(path)
                candidate = deepcopy(target_documents[path])
                candidate.assert_source_current()
            if action == "new":
                from temsim.component_operations import make_component
                fields = {key: value for key, value in values.items() if key in {
                    "key", "name", "shape", "center_z_mm", "length_mm", "inner_diameter_mm",
                    "outer_diameter_mm", "width_mm", "height_mm", "parent_key"}}
                selected = candidate.add_component(make_component(**fields))
            elif action == "place":
                candidate.place_component(source_key, values["center_z_mm"], include_children=values["include_children"],
                                          physical_pose=values.get("physical_pose"))
                selected = source_key
            else:
                selected = candidate.copy_component_from(source_snapshot, source_key, values["key"], values["center_z_mm"],
                    parent_key=values["parent_key"], include_children=values["include_children"], name=values["name"])
            # A malformed or unsupported CAD operation keeps the review dialog
            # open, instead of accepting then clearing the previous viewport.
            from temsim.part_model_3d import part_model_from_document
            part_model_from_document(candidate.document, selected,
                runtime_values=self._model_runtime_values() if same_file else {})
            candidate.assert_source_current()
            return candidate, selected

        targets = tuple(self._project_root / path for path in self._catalog_paths) if self._project_root else ()
        dialog = ComponentDialog(action, source_path=source.path, part=source.part(source_key),
            target_paths=targets, module_origins=self._module_origins,
            parts_for_target=lambda path: document_for_target(path)["parts"],
            document_for_target=document_for_target, submit=stage, parent=self)
        self._component_dialog = dialog
        dialog.setWindowModality(Qt.WindowModality.WindowModal)

        def finished(result):
            self._component_dialog = None
            if result == dialog.DialogCode.Accepted and dialog.result_value is not None:
                self.session, selected = dialog.result_value
                self._invalid_inputs = {}
                self._topology_selection = ()
                self._pending_part = None
                self._pending_reveal = False
                self._removed_selection_key = None
                self._load_tree()
                self.select_part(selected, emit=False)
                if not self.view.fit_selection():
                    self.view.fit_all()
                self._message("Component draft preview updated. Save writes " + str(self.session.path))
                self._update_buttons()
                self._queue_overlap_check()
            dialog.deleteLater()

        dialog.finished.connect(finished)
        dialog.open()
        return dialog

    def _model_runtime_values(self):
        if self.session is None or self._project_root is None:
            return {}
        active_paths = {(self._project_root / path).resolve() for path in self._project_paths}
        values = self._runtime_values if self.session.path in active_paths or self._document_is_active() else {}
        if self.session.dirty and values.get("feg_tip", {}).get("tip_surface_model") is not None:
            # Draft dimensions take precedence in the file editor only; the
            # actual gun and assembly remain unchanged until Save succeeds.
            values = deepcopy(values)
            values["feg_tip"].pop("tip_surface_model", None)
        return values

    def set_runtime_values(self, values):
        """Refresh operating apertures without replacing the mechanical draft."""
        previous_mesh = self._runtime_mesh_dependencies()
        previous_assembly_mesh = self._runtime_mesh_dependencies(whole_assembly=True)
        previous_parameters = self._selected_runtime_values()
        self._runtime_values = deepcopy(values or {})
        self._refresh_runtime_dependencies(previous_mesh, previous_parameters, previous_assembly_mesh)

    def _selected_runtime_values(self):
        if self.session is None or self._selected_key is None:
            return {}
        values = self._model_runtime_values()
        key = self._selected_key
        if key not in values:
            key = self.session.part(key).get("parent_key")
        return values.get(key, {})

    def _runtime_mesh_dependencies(self, *, whole_assembly=False):
        """Track material openings separately from field-only operating values."""
        if self.session is None or self._selected_key is None:
            return ()
        from temsim.part_model_apertures import _opening, is_strip_aperture
        from temsim.energy_filter_model_3d import slit_render_dependency, supports_energy_filter_part

        parts = {part["key"]: part for part in self.session.document["parts"]}
        if whole_assembly:
            installed = {part.key: part.data for part in
                         getattr(self._cad_context_assembly, "parts", ())}
            parts = {**installed, **parts}
        scope = self.scope.currentData()
        if whole_assembly or scope == "module":
            keys = set(parts)
        else:
            keys = {self._selected_key}
            # Match part_model_from_document's descendant/shared-body closure.
            while True:
                more = {key for key, part in parts.items()
                        if part.get("parent_key") in keys
                        or keys.intersection(part.get("magnetic_lens_keys", ()))}
                if more <= keys:
                    break
                keys.update(more)
            if scope == "context":
                parent = parts[self._selected_key].get("parent_key")
                keys.update(key for key, part in parts.items()
                            if parent and part.get("parent_key") == parent)
        runtime = self._runtime_values if whole_assembly else self._model_runtime_values()
        dependencies = []
        for key, part in parts.items():
            if key in keys and part.get("mechanical_profile") == "electrostatic_parallel_plates":
                dependencies.append((key, "azimuth_deg", deepcopy(runtime.get(key, {}).get("azimuth_deg", 0.))))
            if key in keys and part.get("tip_particle_model"):
                tip = runtime.get(key, {})
                dependencies.append((key, deepcopy(tip.get("tip_surface_model", "saved")),
                                     deepcopy(tip.get("tip_analytic_emission"))))
            if (key in keys and supports_energy_filter_part(part)
                    and part.get("mechanical_profile") == "xo_energy_slit_assembly"
                    and part.get("model_3d", {}).get("base", {}).get("kind", "existing") == "existing"):
                try:
                    opening = slit_render_dependency(part, runtime.get(key))
                except (TypeError, ValueError, OverflowError) as exc:
                    opening = str(exc)
                dependencies.append((key, opening))
            if (key not in keys or not is_strip_aperture(part)
                    or part.get("model_3d", {}).get("base", {}).get("kind", "existing") != "existing"):
                continue
            try:
                index = self._aperture_index if key == self._selected_key else 0
                opening = _opening(part, runtime.get(key), index)
            except ValueError as exc:
                # Invalid input is handled by the normal preview error path.
                opening = str(exc)
            dependencies.append((key, opening))
        return tuple(dependencies)

    def _refresh_runtime_dependencies(self, previous_mesh, previous_parameters, previous_assembly_mesh=None):
        self._runtime_refresh_pending |= previous_mesh != self._runtime_mesh_dependencies()
        self._runtime_parameters_pending |= previous_parameters != self._selected_runtime_values()
        self._refresh_geometry_report_status()
        assembly_changed = (previous_assembly_mesh is not None and
                            previous_assembly_mesh != self._runtime_mesh_dependencies(whole_assembly=True))
        if self.session is not None and (assembly_changed or previous_mesh != self._runtime_mesh_dependencies()):
            self._queue_overlap_check()
        if self.isVisible():
            self._flush_runtime_refresh()

    def _flush_runtime_refresh(self):
        if self.session is None or self._selected_key is None:
            return
        mesh_pending = self._runtime_refresh_pending
        parameters_pending = self._runtime_parameters_pending
        self._runtime_refresh_pending = self._runtime_parameters_pending = False
        if mesh_pending:
            self._load_parameters()
            self._render(preserve_view=True)
        elif parameters_pending:
            # Operating annotations can change without changing any CAD mesh.
            self._load_all_parameters()

    def set_simulation_context(self, mode=None, descriptors=None, by_key=None, *, round_lens_settings=None):
        self._simulation_mode = mode
        self._field_descriptors = descriptors or {}
        self._round_lens_settings = round_lens_settings
        self._assembly_parts = by_key or {}
        if self.session is not None:
            self._refresh_parameter_annotations()
        self._refresh_calculation_status()

    def set_calculation_status(self, status, detail=""):
        if status not in {"not_calculated", "stale", "running", "current", "failed"}:
            raise ValueError(f"Unknown calculation status: {status}")
        self._calculation_status, self._calculation_detail = status, detail
        self._refresh_calculation_status()

    def _document_is_active(self):
        if self.session is None or self._project_root is None:
            return False
        if self.session.path in {(self._project_root / path).resolve() for path in self._project_paths}:
            return True
        if self.session.path in getattr(self, "_active_definition_files", ()):
            return True
        if self._selected_key == "feg_tip":
            from temsim.shared_tip import definition_path
            source = definition_path(self.session.path, self.session.part("feg_tip")) or self.session.path
            return source in getattr(self, "_active_definition_files", ())
        return False

    def _meaning_context(self):
        active = self._document_is_active()
        parts = dict(self._assembly_parts) if active else {}
        if self.session is not None:
            parts.update({part["key"]: part for part in self.session.document["parts"]
                          if not active or part["key"] == self._selected_key or part["key"] not in parts
                          or self.session.path in {(self._project_root / path).resolve() for path in self._project_paths}})
        return parts, self._simulation_mode if active else None, self._field_descriptors if active else {}

    def _parameter_information(self, path, field=None):
        from temsim.parameter_semantics import describe_parameter
        from temsim.parameter_impact import describe_parameter_impact
        parts, mode, descriptors = self._meaning_context()
        part = (parts.get(path[1], {}) if len(path) > 1 and path[0] in {"parts", "runtime", "derived"}
                else self.session.document if self.session is not None else {})
        meaning = describe_parameter(part, tuple(path), by_key=parts)
        impact = describe_parameter_impact(part, tuple(path), by_key=parts,
                                           simulation_mode=mode, descriptors=descriptors,
                                           round_lens_settings=getattr(self, "_round_lens_settings", None))
        if part.get("tip_particle_model"):
            from temsim.tip_emission_view import emission_parameter_information
            meaning, impact = emission_parameter_information(part, path,
                self._model_runtime_values().get(part["key"]), meaning, impact)
        if non_material_role(part):
            label = (field.label if field is not None else "Stored " + " / ".join(
                str(piece).removesuffix("_" + meaning.unit).replace("_", " ") for piece in path[2:]))
            meaning = replace(meaning, label=label, category="unknown",
                              category_label="Channel / reference metadata",
                              description=representation_note(part))
        label = field.label if field is not None else meaning.label
        reason = field.reason if field is not None and field.reason else meaning.description
        text = (f"{label} · {meaning.category_label}\n"
                f"Evidence: {meaning.source_label}\nUse: {impact.label}\n\n"
                f"{reason}\nSource detail: {meaning.source_note}\nCalculation detail: {impact.detail}")
        return meaning, impact, text

    def _refresh_parameter_annotations(self):
        if self.session is None:
            return
        from temsim.magnetic_circuits import is_custom_mechanical_part
        parts_by_key = {part["key"]: part for part in self.session.document["parts"]}
        blocked = self.dimensions.blockSignals(True)
        try:
            for row in range(self.dimensions.rowCount()):
                value = self.dimensions.item(row, 1)
                if value is None:
                    continue
                field = value.data(Qt.ItemDataRole.UserRole + 2)
                path = value.data(Qt.ItemDataRole.UserRole)
                meaning, impact, text = self._parameter_information(path, field)
                short = {"active": "Active", "inactive": "Inactive", "unsupported": "Unsupported",
                         "configuration_required": "Setup", "unknown": "Check"}.get(impact.status, "Check")
                if impact.label == "Reference tip definition":
                    short = "Reference"
                elif impact.label == "Derived from active emission":
                    short = "Derived"
                parameter_part = parts_by_key.get(path[1], {}) if len(path) > 1 and path[0] == "parts" else {}
                if meaning.category == "cad" or is_custom_mechanical_part(parameter_part):
                    short = "CAD only"
                # A short status remains visible; the full evidence and routing
                # are available for every row and in the selection inspector.
                use = QTableWidgetItem(short)
                use.setFlags(use.flags() & ~Qt.ItemFlag.ItemIsEditable)
                use.setForeground(QColor({"active": "#7fcea5", "inactive": "#d1b36d",
                                          "unsupported": "#a3bdd8"}.get(impact.status, "#bdc6d1")))
                self.dimensions.setItem(row, 3, use)
                for column in range(self.dimensions.columnCount()):
                    item = self.dimensions.item(row, column)
                    if item is not None:
                        item.setToolTip(text)
                value.setData(Qt.ItemDataRole.UserRole + 3, meaning)
                use.setData(Qt.ItemDataRole.UserRole, impact)
        finally:
            self.dimensions.blockSignals(blocked)
        if self.dimensions.currentRow() < 0 and self.dimensions.rowCount():
            self.dimensions.setCurrentCell(0, 0)
        if self.parameter_tabs.currentWidget() is self.parameters and self.parameters.currentItem() is not None:
            self._all_parameter_selected(self.parameters.currentItem())
        else:
            self._parameter_selected(self.dimensions.currentRow())

    def _parameter_selected(self, row, *_):
        if self._loading:
            return
        item = self.dimensions.item(row, 1)
        if item is not None:
            _, _, text = self._parameter_information(item.data(Qt.ItemDataRole.UserRole),
                                                      item.data(Qt.ItemDataRole.UserRole + 2))
            self.parameter_detail.setPlainText(text)

    def _all_parameter_selected(self, item, _previous=None):
        if self._loading or item is None or self.session is None:
            return
        path = item.data(0, Qt.ItemDataRole.UserRole)
        if path and len(path) >= 2:
            self.parameter_detail.setPlainText(self._parameter_information(path)[2])

    def _refresh_calculation_status(self):
        if not hasattr(self, "calculation_label"):
            return
        parts, mode, descriptors = self._meaning_context()
        from temsim.simulation_modes import MODE_BY_KEY
        mode_label = MODE_BY_KEY[mode].label if mode in MODE_BY_KEY else "Not linked to active simulation"
        status = {"not_calculated": "Not calculated", "stale": "Results out of date",
                  "running": "Calculating", "current": "Result current for active model",
                  "failed": "Calculation failed"}[self._calculation_status]
        lines = [mode_label]
        details = [self._calculation_detail]
        source_changed = False
        if self.session is not None and not self._saving:
            try:
                self.session.assert_source_current()
            except (OSError, ValueError) as exc:
                source_changed = True
                lines.append("Source changed or unavailable · displayed dimensions need reload")
                details.append(str(exc) + "\nResolve any draft, then reopen the source or reload the catalog.")
        if self.session is not None and self._selected_key in parts:
            from temsim.parameter_impact import component_impact_summary, describe_parameter_impact
            summary = component_impact_summary(parts[self._selected_key], by_key=parts,
                                               simulation_mode=mode, descriptors=descriptors,
                                               round_lens_settings=getattr(self, "_round_lens_settings", None))
            details.append(summary.detail)
            if summary.status == "configuration_required":
                lines.append("Field setup required · inspect parameter usage")
            ignored = summary.ignored_cad_parameters
            if ignored:
                lines.append(f"CAD changes excluded from physics ({len(ignored)} parameters)")
                details.append("Excluded from beam / field calculation:\n" + "\n".join(ignored))
            if self.session.dirty or self._invalid_inputs:
                lines.append("Unsaved draft · simulation still uses saved dimensions")
                affected = set()
                for path in self.session.updates():
                    impact = describe_parameter_impact(parts[path[1]], path, by_key=parts,
                                                       simulation_mode=mode, descriptors=descriptors,
                                                       round_lens_settings=getattr(self, "_round_lens_settings", None))
                    affected.update(impact.affected_results)
                if affected:
                    details.append("After Save, review: " + ", ".join(sorted(affected)))
            elif mode is not None and not source_changed:
                lines.append(status)
        self.calculation_label.setText("\n".join(lines))
        self.calculation_label.setToolTip("\n\n".join(text for text in details if text))

    def show_dimension_audit(self):
        from temsim.dimension_audit import audit_catalog, audit_document
        from temsim.gui.dimension_audit import DimensionAuditDialog
        try:
            if self._project_root is not None:
                audit = audit_catalog(self._project_root)
                scope = "Saved catalog dimensions; unsaved drafts are excluded"
            elif self.session is not None:
                audit = audit_document(self.session.document, source=str(self.session.path))
                scope = "Current file draft"
            else:
                self._message("Open a module to audit its dimensions.")
                return
            if self._audit_dialog is not None:
                self._audit_dialog.close()
                self._audit_dialog.deleteLater()
            dialog = DimensionAuditDialog(audit, self, scope=scope)
            dialog.parameter_requested.connect(self._audit_parameter_requested)
            self._audit_dialog = dialog
            dialog.show()
            return dialog
        except Exception as exc:
            self._message(f"Dimension audit failed: {exc}", error=True)

    def _audit_parameter_requested(self, source, key, path):
        location = Path(source)
        if not location.is_absolute() and self._project_root is not None:
            location = self._project_root / location
        if self.open_path(location, selected_key=key):
            path = tuple(path)
            self._highlight_parameter_paths({path})
            located = False
            for row in range(self.dimensions.rowCount()):
                if tuple(self.dimensions.item(row, 1).data(Qt.ItemDataRole.UserRole)) == path:
                    self.parameter_tabs.setCurrentWidget(self.dimensions)
                    self.dimensions.setCurrentCell(row, 0)
                    located = True
                    break
            if not located:
                self.parameter_tabs.setCurrentWidget(self.parameters)
                def find(parent):
                    if tuple(parent.data(0, Qt.ItemDataRole.UserRole) or ()) == path:
                        return parent
                    for index in range(parent.childCount()):
                        match = find(parent.child(index))
                        if match is not None:
                            return match
                    return None
                item = None
                for index in range(self.parameters.topLevelItemCount()):
                    item = find(self.parameters.topLevelItem(index))
                    if item is not None:
                        break
                if item is not None:
                    self.parameters.setCurrentItem(item)
                    self.parameters.scrollToItem(item)
                    located = True
                else:
                    self.parameters.clearSelection()
                    message = ("Audit field " + ".".join(map(str, path))
                               + " is not defined in this source file. The component is open for review; no dimension was substituted.")
                    self._message(message, error=True)
                    self.parameter_detail.setPlainText(message)
            if self._audit_dialog is not None:
                self._audit_dialog.accept()
            if key:
                self._emit_project_selection()

    def _create_features_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        self.base_shape = QComboBox()
        self.base_shape.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.base_shape.setMinimumContentsLength(12)
        for label, key in (("Existing component geometry", "existing"),
                           ("Imported STEP geometry", "step"),
                           ("Box", "box"), ("Elliptic cylinder", "elliptic_cylinder")):
            self.base_shape.addItem(label, key)
        self.apply_shape_button = QPushButton("Use this base shape")
        self.reset_model_button = QPushButton("Restore original shape")
        layout.addWidget(QLabel("Base shape"))
        layout.addWidget(self.base_shape)
        layout.addWidget(self.apply_shape_button)
        layout.addWidget(self.reset_model_button)
        self.feature_tree = QTreeWidget()
        self.feature_tree.setObjectName("partModelFeatures")
        self.feature_tree.setHeaderLabels(("Cut feature", "Type"))
        self.feature_tree.setRootIsDecorated(False)
        self.feature_tree.setMinimumWidth(0)
        self.feature_tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.feature_tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(self.feature_tree, 1)
        row = QHBoxLayout()
        self.add_hole_button = QPushButton("Add hole…")
        self.add_slot_button = QPushButton("Add slot / groove…")
        row.addWidget(self.add_hole_button)
        row.addWidget(self.add_slot_button)
        layout.addLayout(row)
        row = QHBoxLayout()
        self.edit_feature_button = QPushButton("Edit feature…")
        self.remove_feature_button = QPushButton("Remove feature")
        row.addWidget(self.edit_feature_button)
        row.addWidget(self.remove_feature_button)
        layout.addLayout(row)
        note = QLabel("Change dimensions and physical lens position/rotation in Dimensions (rotations in mrad). "
                      "A selected face or edge supplies the initial cut position. "
                      "Holes and slots remove material; all changes support Undo and Save.\n\n"
                      "Physical magnetic lens placement moves its field and child hardware. "
                      "CAD shape changes do not infer field strength from coil dimensions.\n\n"
                      "STEP supports configured dimensions and physical placement. Custom base shapes, "
                      "holes, slots and scaling use the same saved recipe for preview and exact STEP export. "
                      "Imported STEP previews use its tessellation; exact export and geometry checks use its B-rep. "
                      "Original CAD feature history is not recovered. View sections only change the display.")
        self.feature_scope_note = note
        note.setWordWrap(True)
        note.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(note)
        self.parameter_tabs.addTab(page, "Features")
        self.apply_shape_button.clicked.connect(self._apply_base_shape)
        self.reset_model_button.clicked.connect(self._reset_model_shape)
        self.add_hole_button.clicked.connect(lambda: self._edit_feature("hole"))
        self.add_slot_button.clicked.connect(lambda: self._edit_feature("slot"))
        self.edit_feature_button.clicked.connect(lambda: self._edit_feature())
        self.remove_feature_button.clicked.connect(self._remove_feature)
        self.feature_tree.itemSelectionChanged.connect(self._feature_selected)
        self.feature_tree.itemDoubleClicked.connect(lambda *_: self._edit_feature())

    def _load_features(self):
        part = self.session.part(self._selected_key)
        model = part.get("model_3d", {})
        self.base_shape.setCurrentIndex(max(0, self.base_shape.findData(model.get("base", {}).get("kind", "existing"))))
        imported = model.get("base", {}).get("kind") == "step"
        self.base_shape.model().item(self.base_shape.findData("step")).setEnabled(imported)
        self.reset_model_button.setToolTip(
            "Restore the imported STEP's original sizes and remove cuts; keep its current placement."
            if imported else "Remove explicit shape edits and restore the component's configured native geometry.")
        self.apply_shape_button.setToolTip(
            "Choosing another base replaces the imported geometry in this draft. Undo restores the STEP source."
            if imported else "Change the material shape; this does not create a new optical field model.")
        current = self.feature_tree.currentItem()
        selected = current.data(0, Qt.ItemDataRole.UserRole) if current else None
        blocked = self.feature_tree.blockSignals(True)
        self.feature_tree.clear()
        for feature in model.get("features", ()):
            node = QTreeWidgetItem((feature["id"], feature["kind"]))
            node.setData(0, Qt.ItemDataRole.UserRole, feature["id"])
            self.feature_tree.addTopLevelItem(node)
            if feature["id"] == selected:
                self.feature_tree.setCurrentItem(node)
        self.feature_tree.blockSignals(blocked)
        material = self._material_editing_enabled()
        self.reset_model_button.setEnabled(material and bool(model))
        self.edit_feature_button.setEnabled(material and self.feature_tree.currentItem() is not None)
        self.remove_feature_button.setEnabled(material and self.feature_tree.currentItem() is not None)

    def _apply_base_shape(self):
        if not self._material_editing_enabled():
            return
        from copy import deepcopy
        from temsim.part_model_features import default_model_3d
        part = self.session.part(self._selected_key)
        model = deepcopy(part.get("model_3d") or default_model_3d(part))
        kind = self.base_shape.currentData()
        if kind == "step":
            if part.get("model_3d", {}).get("base", {}).get("kind") != "step":
                self._message("Use Import STEP to choose an exact source geometry.", error=True)
            return
        base = {"kind": kind}
        if kind != "existing":
            diameter = float(part.get("mechanical_outer_diameter_mm", 10.0))
            base.update(width_mm=max(diameter, 0.01), height_mm=max(diameter, 0.01),
                        length_mm=max(float(part.get("length_mm", 10.0)), 0.01))
        model["base"] = base
        try:
            self.session.set_model_3d(self._selected_key, model)
            prefix = ("parts", self._selected_key, "model_3d", "base")
            self._invalid_inputs = {path: text for path, text in self._invalid_inputs.items() if path[:4] != prefix}
            self._draft_changed()
            self.parameter_tabs.setCurrentWidget(self.dimensions)
        except Exception as exc:
            self._message(str(exc), error=True)

    def _reset_model_shape(self):
        if self._material_editing_enabled():
            if self.session.part(self._selected_key).get("model_3d", {}).get("base", {}).get("kind") == "step":
                self.session.reset_model_geometry(self._selected_key)
            else:
                self.session.set_model_3d(self._selected_key, None)
            prefix = ("parts", self._selected_key, "model_3d")
            self._invalid_inputs = {path: text for path, text in self._invalid_inputs.items() if path[:3] != prefix}
            self._topology_selection = ()
            self._draft_changed()

    def _feature_defaults(self, kind):
        part = self.session.part(self._selected_key)
        features = part.get("model_3d", {}).get("features", ())
        count = 1
        while f"{kind}_{count}" in {item["id"] for item in features}:
            count += 1
        diameter = max(float(part.get("mechanical_outer_diameter_mm", 10.0)), 0.01)
        length = max(float(part.get("length_mm", 10.0)), 0.01)
        inner = float(part.get("mechanical_inner_diameter_mm", part.get("mechanical_bore_diameter_mm", 0.0)))
        center, axis, depth = [(inner + diameter) * 0.25, 0.0, 0.0], "z", length * 1.2
        hit = next((item for item in reversed(self._topology_selection) if item.get("key") == self._selected_key), None)
        if hit and hit.get("point") is not None:
            from temsim.part_model_features import feature_placement
            from temsim.energy_filter_model_3d import energy_filter_feature_hit, supports_energy_filter_part
            point, normal = hit["point"], hit.get("normal", [0, 0, 1])
            if supports_energy_filter_part(part):
                by_key = {row["key"]: row for row in self.session.document["parts"]}
                point, normal = energy_filter_feature_hit(part, by_key, point, normal)
            else:
                import numpy as np
                from temsim.lens_pose import mechanical_part_transform_mm, supports_physical_lens_pose
                by_key = {row["key"]: row for row in self.session.document["parts"]}
                rotation, translation = mechanical_part_transform_mm(part, by_key)
                point = rotation.T @ (np.asarray(point) - translation)
                normal = rotation.T @ np.asarray(normal)
                if supports_physical_lens_pose(part):
                    part = deepcopy(part)
                    transform = part.get("model_3d", {}).get("transform", {})
                    transform.pop("offset_mm", None)
                    transform.pop("rotation_deg", None)
            center, axis, depth = feature_placement(part, point, normal)
        feature = dict(id=f"{kind}_{count}", kind=kind, axis=axis,
                       center_mm=list(center), depth_mm=float(depth))
        size = max(0.01, min(diameter * 0.08, max(diameter - inner, 0.1) * 0.25))
        if kind == "hole":
            feature["diameter_mm"] = size
        else:
            feature.update(width_mm=size, length_mm=size * 3, rotation_deg=0.0)
        return feature

    def _edit_feature(self, kind=None):
        if not self._material_editing_enabled():
            return
        from temsim.gui.part_feature_dialog import PartFeatureDialog
        if kind:
            feature = self._feature_defaults(kind)
        else:
            current = self.feature_tree.currentItem()
            if current is None:
                return
            feature = next(item for item in self.session.part(self._selected_key).get("model_3d", {}).get("features", ())
                           if item["id"] == current.data(0, Qt.ItemDataRole.UserRole))
        dialog = PartFeatureDialog(feature, self)
        if dialog.exec() != dialog.DialogCode.Accepted:
            return
        try:
            self.session.upsert_model_feature(self._selected_key, dialog.feature())
            index = next(index for index, item in enumerate(self.session.part(self._selected_key)["model_3d"]["features"])
                         if item["id"] == feature["id"])
            prefix = ("parts", self._selected_key, "model_3d", "features", index)
            self._invalid_inputs = {path: text for path, text in self._invalid_inputs.items() if path[:5] != prefix}
            self._draft_changed()
            for index in range(self.feature_tree.topLevelItemCount()):
                node = self.feature_tree.topLevelItem(index)
                if node.data(0, Qt.ItemDataRole.UserRole) == feature["id"]:
                    self.feature_tree.setCurrentItem(node)
                    break
        except Exception as exc:
            self._message(str(exc), error=True)

    def _remove_feature(self):
        current = self.feature_tree.currentItem()
        if self._material_editing_enabled() and current is not None:
            feature_id = current.data(0, Qt.ItemDataRole.UserRole)
            index = next(index for index, item in enumerate(self.session.part(self._selected_key)["model_3d"]["features"])
                         if item["id"] == feature_id)
            self.session.remove_model_feature(self._selected_key, feature_id)
            prefix = ("parts", self._selected_key, "model_3d", "features")
            invalid = {}
            for path, text in self._invalid_inputs.items():
                if path[:4] == prefix:
                    if path[4] == index:
                        continue
                    if path[4] > index:
                        path = (*prefix, path[4] - 1, *path[5:])
                invalid[path] = text
            self._invalid_inputs = invalid
            self._topology_selection = ()
            self._draft_changed()

    def _feature_selected(self):
        if self._loading or self.session is None:
            return
        node = self.feature_tree.currentItem()
        material = self._material_editing_enabled()
        self.edit_feature_button.setEnabled(material and node is not None)
        self.remove_feature_button.setEnabled(material and node is not None)
        if node is None:
            return
        features = self.session.part(self._selected_key).get("model_3d", {}).get("features", ())
        index = next((index for index, item in enumerate(features) if item["id"] == node.data(0, Qt.ItemDataRole.UserRole)), None)
        if index is not None:
            self._highlight_parameter_paths({("parts", self._selected_key, "model_3d", "features", index)})

    def _topology_changed(self, selection, *, activate_parameters=True):
        self._topology_selection = tuple(selection or ())
        labels = [item.get("label", str(item.get("id", ""))) for item in self._topology_selection]
        self.topology_hint.setText("Selected: " + "; ".join(labels) if labels else
                                   "Select a face or edge to highlight its parameters. Ctrl-click adds to the selection.")
        paths = {tuple(path) for item in self._topology_selection for path in item.get("parameter_paths", ())}
        self._highlight_parameter_paths(paths)
        if paths and activate_parameters:
            self.parameter_tabs.setCurrentWidget(self.dimensions)

    def _highlight_parameter_paths(self, paths):
        paths = {tuple(path) for path in paths}
        def matches(path):
            return path is not None and any(tuple(path[:len(prefix)]) == prefix for prefix in paths)
        def priority(path):
            if len(path) > 3 and path[2:4] == ["model_3d", "features"]:
                return 0
            if len(path) > 3 and path[2:4] == ["model_3d", "transform"]:
                return 2
            return 1
        first = None
        first_priority = 3
        blocked = self.dimensions.blockSignals(True)
        for row in range(self.dimensions.rowCount()):
            path = self.dimensions.item(row, 1).data(Qt.ItemDataRole.UserRole)
            match = matches(path)
            for column in range(self.dimensions.columnCount()):
                item = self.dimensions.item(row, column)
                item.setBackground(QBrush(QColor("#665125")) if match else QBrush())
                item.setData(Qt.ItemDataRole.UserRole + 1, bool(match))
            if match and priority(list(path)) < first_priority:
                first = self.dimensions.item(row, 0)
                first_priority = priority(list(path))
        self.dimensions.blockSignals(blocked)
        if first is not None:
            self.dimensions.scrollToItem(first, QTableWidget.ScrollHint.PositionAtTop)
            if paths:
                self.dimensions.setCurrentCell(first.row(), 0)
        tree_first = [None, 3]
        def visit(node):
            path = node.data(0, Qt.ItemDataRole.UserRole)
            match = matches(path)
            for column in range(2):
                node.setBackground(column, QBrush(QColor("#665125")) if match else QBrush())
            if match:
                if node.childCount() == 0 and priority(list(path)) < tree_first[1]:
                    tree_first[:] = [node, priority(list(path))]
                parent = node.parent()
                while parent is not None:
                    parent.setExpanded(True)
                    parent = parent.parent()
            for index in range(node.childCount()):
                visit(node.child(index))
        for index in range(self.parameters.topLevelItemCount()):
            visit(self.parameters.topLevelItem(index))
        if tree_first[0] is not None:
            self.parameters.scrollToItem(tree_first[0], QTreeWidget.ScrollHint.PositionAtTop)

    def focus_project_part(self, part):
        if self._project_root is None:
            return
        path = self._project_root / part.source_file
        if self.session is not None and self.session.path == path.resolve() and self._selected_key == part.key:
            self._pending_part = None
            self._pending_reveal = False
            return
        if self._pending_part != (path, part.key):
            self._pending_reveal = False
        self._pending_part = (path, part.key)
        if self.isVisible() and not self._saving:
            self._open_pending_part()

    def reveal_project_part(self, part):
        """Explicit 2D navigation also fits an already selected 3D component."""
        if self._project_root is None:
            return
        self._pending_part = (self._project_root / part.source_file, part.key)
        self._pending_reveal = True
        if self.isVisible() and not self._saving:
            self._open_pending_part()

    def showEvent(self, event):
        super().showEvent(event)
        if self._pending_part is not None:
            self._open_pending_part()
        elif self.session is None and self.modules.count():
            self._open_active_module()
        self._flush_runtime_refresh()
        if self._auto_geometry_pending:
            self._overlap_timer.start()

    def hideEvent(self, event):
        self._overlap_timer.stop()
        super().hideEvent(event)

    def _open_pending_part(self):
        path, key = self._pending_part
        reveal = self._pending_reveal
        if self.session is not None and self.session.path == Path(path).resolve():
            if any(part["key"] == key for part in self.session.document["parts"]):
                self.select_part(key, emit=False)
            self._pending_part = None
        elif self.session is None or not (self.session.dirty or self._invalid_inputs):
            if self.open_path(path, selected_key=key):
                self._pending_part = None
        else:
            self._message("Save or Revert the current draft before switching source files.", error=True)
        if self._pending_part is None:
            self._pending_reveal = False
            if reveal and not self.view.fit_selection():
                self.view.fit_all()

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open instrument model", "", "Instrument TOML (*.toml)")
        if path:
            self.open_path(path)

    def _open_active_module(self):
        path = self.modules.currentData()
        if path and self._project_root is not None:
            self.open_path(self._project_root / path)
            self._sync_source_context()

    def _sync_source_context(self):
        """The selector and file label always describe the document on screen."""
        if self.session is None:
            return
        path = self.session.path
        relative = (path.relative_to(self._project_root).as_posix()
                    if self._project_root is not None and path.is_relative_to(self._project_root)
                    else str(path))
        blocked = self.modules.blockSignals(True)
        index = self.modules.findData(relative)
        if index < 0:
            self.modules.addItem(f"External: {path.name}", relative)
            index = self.modules.count() - 1
        self.modules.setCurrentIndex(index)
        self.modules.blockSignals(blocked)
        marker = "* " if self.session.dirty or self._invalid_inputs else ""
        from temsim.shared_tip import definition_path
        shared = definition_path(path, self.session.part(self._selected_key)) if self._selected_key else None
        if path in getattr(self, "_active_tip_definitions", ()):
            shared = path
        suffix = f" · shared {shared.name}" if shared is not None else ""
        from temsim.subassemblies import sources
        owner = self.session._subassembly_owners.get(self._selected_key)
        storage = next((source for entry, source in sources(self.session.document, path)
                        if entry["key"] == owner), None)
        if storage is not None:
            suffix = f" · stored in {storage.name}"
        self.source_label.setText(f"{marker}{path.name} · {self._selected_key or ''}{suffix}")
        self.source_label.setToolTip(
            f"Source: {path}\nComponent: {self._selected_key or ''}\n"
            + (f"Tip: {shared}\nSaving tip dimensions or emission settings updates every linked FEG assembly."
               if shared is not None else "Components belonging to this module share this TOML file.")
        )
        if storage is not None:
            self.source_label.setToolTip(f"Installed module: {path}\nPart definitions: {storage}\n"
                                        "Save writes dimensions to this subassembly and placement to the installed module.")

    def _open_subassemblies(self):
        if self.session is None or not self.session.document.get("subassemblies"):
            return
        from temsim.gui.subassembly_dialog import SubassemblyPlacementDialog
        if self._subassembly_dialog is not None:
            self._subassembly_dialog.close()
        self._subassembly_dialog = SubassemblyPlacementDialog(self.session, self._draft_changed, self)
        self._subassembly_dialog.show()

    def open_path(self, path, *, selected_key=None):
        if self.session is not None and (self.session.dirty or self._invalid_inputs):
            self._message("Save, Save copy or Revert the current draft before opening another file.", error=True)
            return False
        try:
            candidate = PartModelDocument(path)
        except Exception as exc:
            self._message(str(exc), error=True)
            return False
        self.session = candidate
        self._auto_geometry_pending = False
        self._overlap_timer.stop()
        self.overlaps.pending("File opened. Edit a dimension or choose Check now to check material overlaps.")
        self._invalid_inputs = {}
        self._topology_selection = ()
        self._removed_selection_key = None
        self._pending_part = None
        self._pending_reveal = False
        self._selected_key = selected_key or candidate.document["parts"][0]["key"]
        self._selected_region = "body"
        self._aperture_index = 0
        self._load_tree()
        self.select_part(self._selected_key, emit=False)
        self.view.fit_all()
        self._message("File opened. Edit existing dimensions or assign materials, then Save.")
        self._update_buttons()
        return True

    def _load_tree(self):
        self._loading = True
        try:
            expanded = {key for key, item in getattr(self, "_subassembly_nodes", {}).items() if item.isExpanded()}
            initial = not getattr(self, "_subassembly_nodes", {})
            self.tree.clear()
            nodes = {}
            groups = {}
            for entry in self.session.document.get("subassemblies", ()):
                item = QTreeWidgetItem((entry.get("name", entry["key"]),))
                item.setToolTip(0, f"Subassembly · {entry['file']}\nEdit group position with Subassemblies / placement.")
                self.tree.addTopLevelItem(item)
                item.setExpanded(initial or entry["key"] in expanded)
                groups[entry["key"]] = item
            self._subassembly_nodes = groups
            for part in self.session.document["parts"]:
                item = QTreeWidgetItem((part.get("name", part["key"]),))
                item.setData(0, Qt.ItemDataRole.UserRole, part["key"])
                item.setToolTip(0, part["key"])
                nodes[part["key"]] = item
            for part in self.session.document["parts"]:
                item = nodes[part["key"]]
                parent = nodes.get(part.get("parent_key"))
                if parent is not None and parent is not item:
                    parent.addChild(item)
                else:
                    owner = groups.get(self.session._subassembly_owners.get(part["key"]))
                    if owner is None:
                        self.tree.addTopLevelItem(item)
                    else:
                        owner.addChild(item)
            self._tree_nodes = nodes
        finally:
            self._loading = False

    def _tree_selected(self, current, _previous):
        if current is not None and not self._loading:
            self.select_part(current.data(0, Qt.ItemDataRole.UserRole))

    def _surface_selected(self, key, region):
        if key:
            self.select_part(key, region=region)
        else:
            self._sync_view_selection()

    def select_part(self, key, *, region="body", emit=True):
        if self.session is None:
            return
        try:
            part = self.session.part(key)
        except StopIteration:
            return
        preserve_view = self._selected_key == key or self.scope.currentData() == "module"
        if self._selected_key != key:
            self._aperture_index = 0
            self._topology_selection = ()
        self._selected_key, self._selected_region = key, region
        self._loading = True
        self.tree.setCurrentItem(self._tree_nodes[key])
        parent = self._tree_nodes[key].parent()
        while parent is not None:
            parent.setExpanded(True)
            parent = parent.parent()
        self.tree.scrollToItem(self._tree_nodes[key])
        self._loading = False
        self.selection_label.setText(part.get("name", key))
        self._load_parameters()
        self._render(preserve_view=preserve_view)
        self._sync_source_context()
        is_tip = bool(part.get("tip_particle_model"))
        self.tip_emission_button.setVisible(is_tip and key == "feg_tip")
        self.tip_emission_button.setEnabled(self._document_is_active())
        self.tip_detail_button.setVisible(is_tip)
        self._update_buttons()
        if emit:
            self._emit_project_selection()

    def _emit_project_selection(self):
        if self._document_is_active():
            self.component_selected.emit(self._selected_key)

    def _fit_tip_emission(self):
        if not self.tip_display.isHidden() and self.tip_display.currentData() == "reference":
            self.tip_display.setCurrentIndex(self.tip_display.findData("emission"))
        if not self.view.fit_region(self._selected_key, "emitting_cap"):
            self._message("No active curved emitting surface in this model. Use Tip model / emission to inspect the selected source.")

    def _sync_view_selection(self):
        """A selected assembly highlights its material children as one component."""
        keys = {self._selected_key}
        if self.session is not None:
            while True:
                children = {part["key"] for part in self.session.document["parts"]
                            if part.get("parent_key") in keys}
                if children <= keys:
                    break
                keys.update(children)
        self.view.set_selection(self._selected_key,
                                None if self._selected_region == "body" else self._selected_region,
                                related_keys=keys)

    def _load_parameters(self):
        if self.session is None or self._selected_key is None:
            return
        from temsim.part_model_3d import part_model_from_document, part_dimension_specs
        runtime_values = self._model_runtime_values()
        fields = part_dimension_specs(self.session.document, self._selected_key, runtime_values=runtime_values)
        base = self.session.part(self._selected_key).get("model_3d", {}).get("base", {})
        if base.get("kind", "existing") != "existing":
            # Explicit solids own their model dimensions. Original assembly
            # dimensions remain available in All parameters and the TOML panel.
            from temsim.lens_pose import PHYSICAL_POSE_FIELDS
            fields = tuple(field for field in fields if field.path[2] == "model_3d"
                           or field.path[2] in PHYSICAL_POSE_FIELDS)
        try:
            model = part_model_from_document(self.session.document, self._selected_key,
                                             aperture_index=self._aperture_index, runtime_values=runtime_values)
            notes = model.notes
            self._region_models = {mesh.region: mesh for mesh in model.meshes if mesh.key == self._selected_key}
            regions = sorted({mesh.region for mesh in model.meshes if mesh.key == self._selected_key})
        except ValueError as exc:
            self._region_models = {}
            notes, regions = ("Preview needs valid dimensions: " + str(exc),), ()
        self._loading = True
        try:
            self.dimensions.setRowCount(len(fields))
            for row, field in enumerate(fields):
                dimension_name = field.path[2]
                text = field.label
                if dimension_name == "model_3d":
                    text = self._model_dimension_label(field.path, field.label)
                label = QTableWidgetItem(text)
                label.setFlags(label.flags() & ~Qt.ItemFlag.ItemIsEditable)
                formatted = ("∞" if field.path[-1] == "emission_radius_nm" and math.isinf(field.value)
                             else format_toml_value(field.value))
                if field.path[-1] in {"emission_support_diameter_nm", "emission_depth_nm"}:
                    formatted = f"{field.value:.7g}"
                value = QTableWidgetItem(self._invalid_inputs.get(tuple(field.path), formatted))
                value.setData(Qt.ItemDataRole.UserRole, field.path)
                value.setData(Qt.ItemDataRole.UserRole + 2, field)
                if not field.editable:
                    value.setFlags(value.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    value.setForeground(Qt.GlobalColor.gray)
                for item in (label, value):
                    item.setToolTip(field.reason or str(field.path))
                    if dimension_name == "vacuum_inner_diameter_mm" and not field.reason:
                        item.setToolTip(
                            "Electron-beam passage constraint, separate from the material hole. "
                            "Edit Material inner diameter or Existing bore diameter to resize the body hole. "
                            "The saved assembly must satisfy its shared vacuum constraints."
                        )
                units = QTableWidgetItem(field.unit)
                units.setFlags(units.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.dimensions.setItem(row, 0, label)
                self.dimensions.setItem(row, 1, value)
                self.dimensions.setItem(row, 2, units)
            self.model_note.setText("\n".join(notes[:2]))
            self.model_note.setToolTip("\n".join(notes))
            selected_part = self.session.part(self._selected_key)
            hole_field = next((name for name in ("aperture_hole_diameters_mm", "aperture_hole_diameters_um",
                "hole_diameters_mm", "hole_diameters_um") if name in selected_part), None)
            self.aperture.clear()
            if hole_field:
                for index, value in enumerate(selected_part[hole_field]):
                    self.aperture.addItem(f"Hole {index + 1}: {value:g} {hole_field.rsplit('_', 1)[-1]}", index)
                self.aperture.setCurrentIndex(min(self._aperture_index, self.aperture.count() - 1))
            self.aperture.setVisible(bool(hole_field))
            self.region.clear()
            self.region.addItem("Entire part (default)", "body")
            for name in regions:
                if name != "body":
                    self.region.addItem(name.title(), name)
            self.region.setCurrentIndex(max(0, self.region.findData(self._selected_region)))
            self._selected_region = self.region.currentData()
            self._load_all_parameters()
            self._load_features()
        finally:
            self._loading = False
        self._refresh_parameter_annotations()
        self._refresh_calculation_status()
        self._region_changed()
        self._highlight_parameter_paths({tuple(path) for item in self._topology_selection
                                         for path in item.get("parameter_paths", ())})

    def _model_dimension_label(self, path, fallback):
        if len(path) < 5:
            return fallback
        section, field = path[3:5]
        if section == "base":
            return {"width_mm": "Base width (X)", "height_mm": "Base height (Y)",
                    "length_mm": "Base length (Z)"}.get(field, fallback)
        if section == "transform" and len(path) == 6:
            axis = "XYZ"[path[5]]
            return "CAD " + axis + {"scale_xy": " scale", "offset_mm": " offset",
                                    "rotation_deg": " rotation"}.get(field, " " + field)
        if section == "features" and len(path) >= 6:
            feature = self.session.part(path[1])["model_3d"]["features"][field]
            name = {"diameter_mm": "Diameter", "depth_mm": "Cut depth",
                    "width_mm": "Slot width", "length_mm": "Slot length",
                    "rotation_deg": "Slot rotation"}.get(path[5], path[5])
            if path[5] == "center_mm" and len(path) == 7:
                name = "XYZ"[path[6]] + " position"
            return feature["id"] + "\n" + name
        return fallback

    def _load_all_parameters(self):
        self._runtime_parameters_pending = False
        self.parameters.clear()
        part = self.session.part(self._selected_key)
        by_key = {item["key"]: item for item in self.session.document["parts"]}
        rows = [("Selected component", part, ("parts", self._selected_key))]
        if part.get("parent_key") in by_key:
            rows.append(("Parent assembly", by_key[part["parent_key"]], ("parts", part["parent_key"])))
        rows.extend(("Child: " + item.get("name", item["key"]), item, ("parts", item["key"]))
                    for item in by_key.values() if item.get("parent_key") == self._selected_key)
        rows.extend((name.title(), self.session.document[name], (name,)) for name in ("module", "geometry", "ports")
                    if name in self.session.document)
        runtime_values = self._model_runtime_values()
        if self._selected_key in runtime_values:
            rows.append(("Current operating values (read-only)", runtime_values[self._selected_key], ("runtime", self._selected_key)))
        elif part.get("parent_key") in runtime_values:
            rows.append(("Parent operating values (read-only)", runtime_values[part["parent_key"]], ("runtime", part["parent_key"])))
        for name, values, path in rows:
            node = QTreeWidgetItem((name, ""))
            self.parameters.addTopLevelItem(node)
            self._parameter_children(node, values, path)
        self.parameters.topLevelItem(0).setExpanded(True)

    @classmethod
    def _parameter_children(cls, parent, values, path=()):
        entries = values.items() if isinstance(values, dict) else enumerate(values)
        for key, value in entries:
            if key == "asset_json" and isinstance(value, str):
                from temsim.step_assets import read_asset
                try:
                    asset = read_asset(value)
                    source = asset.get("source", {})
                    summary = f"Embedded STEP source · {len(asset['leaves'])} bodies · {source.get('filename', 'STEP')}"
                    detail = (summary + "\nSHA-256: " + str(source.get("sha256", "unknown")) +
                              "\nExact source B-rep is stored in the TOML. Use Dimensions and Features to edit its recipe.")
                except ValueError:
                    summary = detail = "Invalid embedded STEP source; re-import the STEP file."
                item = QTreeWidgetItem((str(key), summary))
                item.setData(0, Qt.ItemDataRole.UserRole, (*path, key))
                item.setToolTip(1, detail)
                parent.addChild(item)
                continue
            nested = isinstance(value, (dict, list, tuple))
            item = QTreeWidgetItem((str(key), "" if nested else str(value)))
            item.setData(0, Qt.ItemDataRole.UserRole, (*path, key))
            item.setToolTip(1, "Expand to inspect fields." if nested else str(value))
            parent.addChild(item)
            if nested:
                cls._parameter_children(item, value, (*path, key))

    def _dimension_changed(self, item):
        if self._loading or item.column() != 1 or self.session is None:
            return
        path = tuple(item.data(Qt.ItemDataRole.UserRole))
        try:
            self.session.set_dimension(path, float(item.text()))
            self._invalid_inputs.pop(path, None)
            if len(path) == 4 and path[2] in {"aperture_hole_diameters_mm", "aperture_hole_diameters_um",
                                           "hole_diameters_mm", "hole_diameters_um"}:
                self._aperture_index = path[3]
            self._load_parameters()
            if self._render(preserve_view=True):
                self._message("Unapplied draft. Other dimensions can be edited before validating and saving.")
            self._queue_overlap_check()
        except Exception as exc:
            self._invalid_inputs[path] = item.text()
            self._message(str(exc), error=True)
            self._overlap_timer.stop()
            self.overlaps.pending("Edit rejected: " + str(exc) + "\nThe previous valid geometry is retained.")
        self._update_buttons()

    def _material_changed(self):
        key = self.material.currentData()
        row = next((item for item in self._materials if item["material_key"] == key), {})
        self.material_hint.setText(row.get("scope", ""))

    def _aperture_changed(self):
        if not self._loading and self.aperture.currentData() is not None:
            self._aperture_index = self.aperture.currentData()
            self._render(preserve_view=True)
            self._refresh_geometry_report_status()

    def _region_changed(self):
        if self._loading or self.session is None or not self._selected_key:
            return
        from temsim.part_materials import material_for_region, material_application_scope
        self._selected_region = self.region.currentData() or "body"
        self._sync_view_selection()
        if non_material_role(self.session.part(self._selected_key)):
            self.material_current.setText(representation_note(self.session.part(self._selected_key)))
            return
        if not self._region_material_editing_enabled():
            mesh = self._region_models.get(self._selected_region)
            material = mesh.material_class if mesh is not None else "Reconstructed material"
            description = mesh.description if mesh is not None else ""
            self.material_current.setText(
                f"CAD region: {self._selected_region}\nMaterial: {material}\n\n"
                "Read-only reconstruction for 3D display and STEP. This region is not a separate solver material assignment."
                + ("\n\n" + description if description else ""))
            self._update_buttons()
            return
        try:
            assignment = material_for_region(self.session.part(self._selected_key), self._selected_region)
            current_class = self.session.part(self._selected_key).get("material_class", "").lower()
            material_key = assignment["material_key"] if assignment else (
                "copper" if "copper" in current_class or "winding" in current_class else
                "nonmagnetic_stainless_steel" if "nonmagnetic" in current_class else "femm_pure_iron"
            )
            index = self.material.findData(material_key)
            if index >= 0:
                self.material.setCurrentIndex(index)
            self.material_current.setText("Assigned: " + assignment["label"] if assignment else
                "Current: " + self.session.part(self._selected_key).get("material_class", "Unspecified") + " (existing model default)")
            self.material_current.setText(self.material_current.text() + "\n\n" +
                material_application_scope(self.session.part(self._selected_key)))
        except ValueError as exc:
            self.material_current.setText(str(exc))
        self._update_buttons()

    def assign_material(self):
        if not self._region_material_editing_enabled():
            return
        try:
            self.session.assign_material(self._selected_key, self.material.currentData(), self._selected_region)
            self._load_parameters()
            self._render(preserve_view=True)
            self._message("Material assignment staged. Save to apply it to the file.")
        except Exception as exc:
            self._message(str(exc), error=True)
        self._update_buttons()

    def _render(self, *, preserve_view=False):
        if self.session is None or self._selected_key is None:
            return
        self._runtime_refresh_pending = False
        from temsim.part_model_3d import part_model_from_document, module_model_from_document
        from temsim.part_materials import configured_region_colour
        runtime_values = self._model_runtime_values()
        try:
            if self.scope.currentData() == "module":
                model = module_model_from_document(self.session.document, angular_segments=16,
                                                   runtime_values=runtime_values,
                                                   aperture_indices={self._selected_key: self._aperture_index})
                meshes = list(model.meshes)
            else:
                model = part_model_from_document(self.session.document, self._selected_key,
                                                 aperture_index=self._aperture_index, runtime_values=runtime_values)
                meshes = list(model.meshes)
                if self.scope.currentData() == "context":
                    parent = self.session.part(self._selected_key).get("parent_key")
                    for part in self.session.document["parts"]:
                        if parent and part.get("parent_key") == parent and part["key"] != self._selected_key:
                            meshes.extend(part_model_from_document(self.session.document, part["key"],
                                include_children=False, runtime_values=runtime_values).meshes)
            records, seen = [], set()
            from temsim.tip_emission_view import analytic_emission, emission_display_meshes
            selected = self.session.part(self._selected_key)
            analytic = analytic_emission(selected, runtime_values.get(self._selected_key)) is not None
            self.tip_display.setVisible(analytic)
            display = self.tip_display.currentData()
            title = ({"emission": "Active emitting surface · equal XYZ scale",
                      "reference": "Reference tip body", "both": "Emission + reference outline"}[display]
                     if analytic else "3D model")
            self.view.set_view_labels(title=title, empty_text=(
                "Point emission: zero projected source size; no finite surface to display."
                if analytic else representation_note(selected) if non_material_role(selected)
                else "Select a part to view its 3D model"))
            if analytic and display != "reference":
                if display == "emission" and self.scope.currentData() == "part":
                    meshes = [mesh for mesh in meshes if mesh.key != self._selected_key]
                else:
                    meshes = [replace(mesh, wireframe=True) if mesh.key == self._selected_key else mesh for mesh in meshes]
                meshes.extend(emission_display_meshes(selected, runtime_values.get(self._selected_key)))
            for mesh in meshes:
                part = self.session.part(mesh.key)
                if part.get("mechanical_profile") == "magnetic_lens_assembly" and not part.get("model_3d") and len(meshes) > 1:
                    continue  # The parent envelope would hide its actual material children.
                # A part/region may consist of several distinct surface meshes.
                signature = (mesh.key, mesh.region, mesh.description)
                if signature in seen:
                    continue
                seen.add(signature)
                # Launch surfaces and normal guides are not assignable material.
                imported_region = (part.get("model_3d", {}).get("base", {}).get("kind") == "step"
                                   and str(mesh.region).startswith("step_"))
                color = (mesh.color if imported_region or mesh.region in {"emitting_cap", "emission_normals"}
                         else configured_region_colour(part, mesh.region, mesh.color))
                records.append(dict(vertices=mesh.vertices, faces=mesh.faces, key=mesh.key,
                                    region=mesh.region, color=color,
                                    face_groups=mesh.face_groups, surfaces=mesh.surfaces, edges=mesh.edges,
                                    wireframe=mesh.wireframe))
            self._mesh_records = tuple(records)
            selected_topology = self._topology_selection
            self.view.set_meshes(records, preserve_view=preserve_view)
            self._sync_view_selection()
            self.view.set_topology_selection(selected_topology)
            self._topology_changed(self.view.topology_selection, activate_parameters=False)
            return True
        except Exception as exc:
            self._mesh_records = ()
            self.view.set_meshes((), preserve_view=True)
            self._topology_changed(())
            self._message("Preview: " + str(exc), error=True)
            return False

    def import_step(self):
        """Import an exact source once; dimensions/features use existing controls."""
        if self._invalid_inputs:
            self._message("Correct the invalid dimensions before importing STEP.", error=True)
            return
        if self._cad_geometry_job is not None and self._cad_geometry_job.busy:
            self._cad_geometry_dialog.show()
            self._cad_geometry_dialog.raise_()
            return
        if self._step_import_dialog is not None:
            self._step_import_dialog.raise_()
            return
        path, _ = QFileDialog.getOpenFileName(self, "Import STEP material", "", "STEP files (*.step *.stp);;All files (*)")
        if not path:
            return
        from temsim.gui.cad_step_import import StepImportDialog
        session = self.session
        snapshot = deepcopy(session.document) if session is not None else None
        source_path = session.path.resolve() if session is not None else None
        selected = None
        if self._material_editing_enabled():
            part = session.part(self._selected_key)
            # Assemblies own independent leaves. Replacing a parent while its
            # children remain visible would silently duplicate the material.
            if not any(p.get("parent_key") == part["key"] for p in session.document["parts"]):
                selected = part
        dialog = StepImportDialog(path, selected_part=selected,
            existing_keys=(p["key"] for p in session.document["parts"]) if session is not None else (), parent=self)
        self._step_import_dialog = dialog
        dialog.setWindowModality(Qt.WindowModality.WindowModal)

        def reviewed(result):
            self._step_import_dialog = None
            if result == dialog.DialogCode.Accepted and dialog.result_value is not None:
                values = dialog.result_value
                destination = None
                if session is None:
                    name, _ = QFileDialog.getSaveFileName(self, "Choose a new TOML for this STEP model",
                        str(Path(path).with_suffix(".toml")), "Instrument TOML (*.toml)")
                    if not name:
                        dialog.deleteLater()
                        return
                    destination = Path(name).resolve()
                    if destination.exists():
                        self._message("Choose a new TOML path. Open an existing TOML first to add imported material to it.", error=True)
                        dialog.deleteLater()
                        return
                self._start_step_import(values, session, snapshot, destination, source_path=source_path)
            dialog.deleteLater()

        dialog.finished.connect(reviewed)
        dialog.open()

    def _start_step_import(self, values, source_session, source_document, destination=None, *, source_path=None):
        from temsim.gui.cad_geometry_job import CadGeometryJob, CadGeometryProgress, request_digest
        try:
            source_path = (Path(source_path).resolve() if source_path is not None else
                           source_session.path.resolve() if source_session is not None else None)
            if self.session is not source_session or (source_session is not None and
                    (source_session.path.resolve() != source_path or source_session.document != source_document)):
                raise ValueError("The target draft changed. Reopen Import STEP to review the current target.")
            request = {"op": "import_step", "path": values["path"],
                       "draft_digest": request_digest(source_document),
                       "target_document_path": str(source_path or destination),
                       "linear_tolerance_mm": .05, "angular_tolerance_rad": .1}
            self._dispose_finished_geometry_job()
            job = CadGeometryJob(request, self)
            progress = CadGeometryProgress(job, "Import STEP", self)
            self._cad_geometry_job, self._cad_geometry_dialog = job, progress

            def completed(success, receipt, message):
                if self._cad_geometry_job is not job:
                    return
                if not success:
                    self._message(message, error=True)
                    self._update_buttons()
                    return
                if (self.session is not source_session or self._invalid_inputs
                        or (source_session is not None and (source_session.path.resolve() != source_path
                                                            or source_session.document != source_document))):
                    self._message("The STEP import finished after the draft changed. Its result was not applied; the current geometry is retained.", error=True)
                    self._update_buttons()
                    return
                try:
                    asset = receipt["result"]
                    if source_session is None:
                        candidate = PartModelDocument.from_step_asset(asset, destination,
                            key=values["key"], name=values["name"])
                        selected_key = candidate.document["parts"][0]["key"]
                    else:
                        candidate = deepcopy(source_session)
                        candidate.assert_source_current()
                        selected_key = candidate.import_step_asset(asset, mode=values["mode"],
                            target_key=values["key"] if values["mode"] == "replace" else None,
                            registration=values["registration"], key=values["key"], name=values["name"])
                    # Validate the mesh before replacing the current session.
                    # This only consumes the worker's tessellation, not OCC.
                    from temsim.part_model_3d import part_model_from_document
                    part_model_from_document(candidate.document, selected_key)
                    self.session = candidate
                    self._invalid_inputs = {}
                    self._topology_selection = ()
                    self._pending_part = None
                    self._pending_reveal = False
                    self._removed_selection_key = None
                    self._load_tree()
                    self.select_part(selected_key, emit=False)
                    self.view.fit_all()
                    self._message("STEP imported into the draft. Use Dimensions and Features to edit; Save writes the TOML. Optical settings were not inferred from the imported shape.")
                except Exception as exc:
                    self._message("STEP was not applied: " + str(exc), error=True)
                self._update_buttons()

            job.completed.connect(completed)
            job.start()
            progress.show()
            self._message("Reading STEP in the background. The current draft and geometry remain available.")
            self._update_buttons()
        except Exception as exc:
            self._message(str(exc), error=True)
            self._update_buttons()

    def _dispose_finished_geometry_job(self):
        # Receipts can contain large source B-reps. Do not retain every old
        # QObject/signal closure (and its captured document) under the editor.
        old = self._cad_geometry_job
        if old is not None and not old.busy:
            if self._cad_geometry_dialog is not None:
                self._cad_geometry_dialog.close()
                self._cad_geometry_dialog.deleteLater()
                self._cad_geometry_dialog = None
            old.deleteLater()
            self._cad_geometry_job = None

    def _auto_overlap_toggled(self, enabled):
        if enabled and self.session is not None:
            self._queue_overlap_check()
        else:
            self._overlap_timer.stop()
            self._auto_geometry_pending = False

    def _queue_overlap_check(self):
        self.overlaps.pending()
        self._auto_geometry_pending = self.overlaps.auto_check.isChecked()
        job = self._cad_geometry_job
        if job is not None and job.busy and getattr(job, "automatic_overlap_check", False):
            job.cancel()
        if self._auto_geometry_pending and self.isVisible():
            self._overlap_timer.start()

    def _run_pending_overlap_check(self):
        if not self._auto_geometry_pending or not self.isVisible() or self._invalid_inputs:
            return
        if self._cad_geometry_job is not None and self._cad_geometry_job.busy:
            self._overlap_timer.start()
            return
        self._auto_geometry_pending = False
        self.check_geometry(automatic=True)

    def _overlap_component_requested(self, key, region):
        if key in getattr(self, "_tree_nodes", {}):
            self.select_part(key, region=region)
            self.parameter_tabs.setCurrentWidget(self.dimensions)
            self.view.fit_selection()
        else:
            self.component_selected.emit(key)
            self._message(f"{key} belongs to another assembly component. Save or Revert this draft before opening its dimensions.")

    def _overlap_names(self):
        return {part["key"]: part.get("name", part["key"])
                for part in self.session.document["parts"]} if self.session else {}

    def _geometry_aperture_indices(self):
        # Omitted indices already mean zero. Navigating to another component
        # must not invalidate an unchanged material check merely by its key.
        from temsim.part_model_apertures import is_strip_aperture
        if (self.session is not None and self._selected_key is not None
                and self._aperture_index and is_strip_aperture(self.session.part(self._selected_key))):
            return {self._selected_key: self._aperture_index}
        return {}

    def check_geometry(self, *, automatic=False, allow_draft_conflicts=False):
        """Review exact current-draft geometry without modifying or saving it."""
        if self.session is None or self._invalid_inputs:
            return
        if self._cad_geometry_job is not None and self._cad_geometry_job.busy:
            if not automatic and self._cad_geometry_dialog is not None:
                self._cad_geometry_dialog.show()
                self._cad_geometry_dialog.raise_()
            return
        from temsim.cad_assembly_edit import build_current_assembly_edit_catalog, assembly_edit_context_is_current
        from temsim.gui.cad_geometry_job import CadGeometryJob, CadGeometryProgress
        from temsim.cad_edit_validation import build_edit_validation_request, finalize_edit_validation
        try:
            # A physically buildable draft may intentionally intersect a
            # neighbour while being edited. Material checks must list those
            # pairs before Save's full configuration validation, whether they
            # run automatically or were requested with Check now.
            if not (automatic or allow_draft_conflicts):
                self.session.validate()
            session = self.session
            session_path = session.path.resolve()
            runtime = self._runtime_values
            indices = self._geometry_aperture_indices()
            catalog = build_current_assembly_edit_catalog(session, project_root=self._project_root,
                project_paths=self._project_paths, module_origins=self._module_origins,
                coordinate_source_bytes=self._coordinate_source_bytes, assembly=self._cad_context_assembly,
                runtime_values=runtime, aperture_indices=indices)
            request = build_edit_validation_request(session.document, catalog,
                runtime_values=runtime, aperture_indices=indices)
            self._dispose_finished_geometry_job()
            job = CadGeometryJob(request, self)
            progress = CadGeometryProgress(job, "Check geometry", self)
            self._cad_geometry_job, self._cad_geometry_dialog = job, progress
            job.automatic_overlap_check = automatic

            def completed(success, receipt, message):
                if self._cad_geometry_job is not job:
                    return
                try:
                    if not success:
                        raise ValueError(message)
                    if (self.session is not session or self._invalid_inputs
                            or session.path.resolve() != session_path):
                        raise ValueError("Geometry result is stale; the target draft changed.")
                    if not assembly_edit_context_is_current(job.request["catalog"],
                            assembly=self._cad_context_assembly, module_origins=self._module_origins,
                            coordinate_source_bytes=self._coordinate_source_bytes,
                            runtime_values=self._runtime_values,
                            aperture_indices=self._geometry_aperture_indices(), full_source_check=True):
                        raise ValueError("Geometry result is stale; the installed assembly, source files or operating openings changed.")
                    report = finalize_edit_validation(job.request, receipt,
                        document=session.document, runtime_values=self._runtime_values,
                        aperture_indices=self._geometry_aperture_indices())
                    self._cad_validation_request = deepcopy(job.request)
                    self._cad_validation_report = report
                    self.overlaps.set_report(report, names=self._overlap_names())
                    if not automatic:
                        self._show_geometry_report(report)
                    elif any(row.get("collisions") for row in report["geometry_report"]["assemblies"]):
                        self.parameter_tabs.setTabText(self.parameter_tabs.indexOf(self.overlaps), "Mechanical overlaps !")
                    else:
                        self.parameter_tabs.setTabText(self.parameter_tabs.indexOf(self.overlaps), "Mechanical overlaps")
                    self._message("Geometry checked within the listed scope." if report["can_apply"] else
                        "Geometry conflicts found. Review the report before saving or using the geometry.",
                        error=not report["can_apply"])
                except Exception as exc:
                    if not (automatic and self._auto_geometry_pending):
                        self.overlaps.pending("Check incomplete: " + str(exc))
                        self._message(str(exc), error=True)
                self._update_buttons()
                if self._auto_geometry_pending and self.isVisible():
                    self._overlap_timer.start()

            job.completed.connect(completed)
            # This check already captures all preceding edits. A subsequent
            # edit can enqueue a new request while this one is running.
            self._auto_geometry_pending = False
            self._overlap_timer.stop()
            job.start()
            if not automatic:
                progress.show()
            self.overlaps.pending("Checking current material geometry in the background…")
            self._message("Checking material intersections and declared optical openings in the background.")
        except Exception as exc:
            self.overlaps.pending("Check unavailable: " + str(exc))
            self._message(str(exc), error=True)
        self._update_buttons()

    def _show_geometry_report(self, report):
        import json
        from PySide6.QtWidgets import QDialog, QPlainTextEdit
        if self._cad_validation_dialog is not None:
            self._cad_validation_dialog.close()
            self._cad_validation_dialog.deleteLater()
        dialog = QDialog(self)
        dialog.setWindowTitle("Geometry check — current draft")
        dialog.resize(760, 560)
        layout = QVBoxLayout(dialog)
        status = QLabel()
        status.setWordWrap(True)
        status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        dialog.report_status = status
        details = QPlainTextEdit()
        details.setReadOnly(True)
        details.setPlainText(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False))
        dialog.report_details = details
        layout.addWidget(status)
        layout.addWidget(details)
        close = QPushButton("Close")
        close.clicked.connect(dialog.close)
        layout.addWidget(close)
        self._cad_validation_dialog = dialog
        self._refresh_geometry_report_status()
        dialog.show()

    def _geometry_report_is_current(self):
        from temsim.cad_edit_validation import validation_is_current
        from temsim.cad_assembly_edit import assembly_edit_context_is_current
        return bool(self._cad_validation_report is not None and self.session is not None and
            str(self.session.path.resolve()) == self._cad_validation_request["catalog"].get(
                "edit_context", {}).get("draft_path") and
            not self._invalid_inputs and validation_is_current(
            self._cad_validation_request, self.session.document,
            runtime_values=self._runtime_values,
            aperture_indices=self._geometry_aperture_indices()) and
            assembly_edit_context_is_current(self._cad_validation_request["catalog"],
                assembly=self._cad_context_assembly, module_origins=self._module_origins,
                coordinate_source_bytes=self._coordinate_source_bytes,
                runtime_values=self._runtime_values,
                aperture_indices=self._geometry_aperture_indices()))

    def _refresh_geometry_report_status(self):
        if self._cad_validation_report is None:
            return
        current = self._geometry_report_is_current()
        report = self._cad_validation_report
        label = ("Current draft: " + ("no conflicts in the checked scope." if report["can_apply"] else
                 "geometry conflicts found.")) if current else "Previous draft only — this report is stale. Run Check geometry for the current draft."
        if self._cad_validation_dialog is not None:
            self._cad_validation_dialog.report_status.setText(label +
                " Electromagnetic fields were not recomputed; STEP material does not define new optical roles.")
        self.geometry_check_button.setToolTip(label)
        if current and not self._auto_geometry_pending:
            self.overlaps.set_report(report, names=self._overlap_names())
        elif not current and self.overlaps._current:
            self.overlaps.set_report(report, names=self._overlap_names(), current=False)

    def export_step(self):
        if self.session is None or self._invalid_inputs:
            return
        if self._cad_export_dialog is not None and self._cad_export_dialog.busy:
            self._cad_export_dialog.show()
            self._cad_export_dialog.raise_()
            return
        from datetime import datetime
        from temsim.gui.cad_export import CadExportDialog, draft_catalog
        try:
            # A valid B-rep alone does not establish valid shared mechanical
            # dimensions or plane bindings. Apply the same gate as Save before
            # opening a destination or launching the optional CAD interpreter.
            self.session.validate()
            catalog = draft_catalog(self.session.document, source=self.session.path,
                                    runtime_values=self._model_runtime_values(),
                                    aperture_indices={self._selected_key: self._aperture_index})
            chosen = QFileDialog.getExistingDirectory(self, "Choose a folder for the STEP export")
            if not chosen:
                return
            # A fresh subfolder preserves any older export in the chosen folder.
            base = Path(chosen) / ("step-" + datetime.now().strftime("%Y%m%d-%H%M%S"))
            destination, number = base, 1
            while destination.exists():
                destination = base.with_name(base.name + f"-{number}")
                number += 1
            dialog = CadExportDialog(catalog, destination, self)
            self._cad_export_dialog = dialog
            dialog.completed.connect(self._step_export_completed)
            dialog.start()
            dialog.show()
            self._message("STEP export started in the background from the current draft.")
        except Exception as exc:
            self._message(str(exc), error=True)
        self._update_buttons()

    def _step_export_completed(self, success, message):
        self._message(message + "\n" + str(self._cad_export_dialog.output_directory), error=not success)
        self._update_buttons()

    def save(self):
        if self.session is None:
            return False
        if self._invalid_inputs:
            self._message("Correct the invalid dimension entries before saving.", error=True)
            return False
        self._saving = True
        pending, reveal = self._pending_part, self._pending_reveal
        completed = False
        try:
            callback = None
            from temsim.shared_tip import catalog_definitions
            if self._project_root is not None and self.session.path in catalog_definitions(self._project_root):
                callback = self._project_save
            if self._project_root is not None and self.session.path.is_relative_to(self._project_root):
                relative = self.session.path.relative_to(self._project_root).as_posix()
                if relative in self._catalog_paths:
                    callback = self._project_save
                else:
                    raise ValueError("This file is not registered in the instrument catalog. Save a copy outside the instrument catalog.")
            self.session.save(project_save=callback)
            self._load_parameters()
            current_geometry = self._geometry_report_is_current()
            if current_geometry and not self._cad_validation_report["can_apply"]:
                self._message("Draft saved. Parameter validation passed, but the current geometry report contains conflicts; review it before using the model.", error=True)
            elif current_geometry:
                self._message("Saved. Parameters validated; material geometry was checked within the report's declared scope.")
            else:
                self._message("Saved. Parameter validation passed. Check geometry reviews material intersections and declared optical openings separately.")
            self.saved.emit(str(self.session.path))
            completed = True
            return True
        except Exception as exc:
            self._message("Not saved: " + str(exc), error=True)
            return False
        finally:
            self._saving = False
            self._update_buttons()
            if pending is not None:
                self._pending_part, self._pending_reveal = pending, reveal
            if completed:
                self._resume_pending_part()

    def save_copy(self):
        if self.session is None:
            return
        if self._invalid_inputs:
            self._message("Correct the invalid dimension entries before saving a copy.", error=True)
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save model copy", str(Path.cwd() / (self.session.path.stem + "-edited.toml")), "Instrument TOML (*.toml)")
        if not path:
            return
        try:
            destination = Path(path).resolve()
            if self._project_root is not None and destination.is_relative_to(self._project_root):
                raise ValueError("Save copies outside the instrument catalog; use Save for the active module.")
            self.session.save_copy(destination)
            self._load_parameters()
            self._render(preserve_view=True)
            self._message("Model copy saved. This file is independent of the active instrument.")
            self._update_buttons()
        except Exception as exc:
            self._message("Not saved: " + str(exc), error=True)

    def undo(self):
        if self.session is not None:
            if self._invalid_inputs:
                self._invalid_inputs.clear()
            else:
                self.session.undo()
            self._draft_changed()

    def redo(self):
        if self.session is not None:
            self.session.redo()
            if self._removed_selection_key in {part["key"] for part in self.session.document["parts"]}:
                self._selected_key = self._removed_selection_key
                self._removed_selection_key = None
            self._draft_changed()

    def revert(self):
        if self.session is not None:
            self._invalid_inputs.clear()
            self.session.revert()
            self._draft_changed()
            self._resume_pending_part()

    def _resume_pending_part(self):
        if self.isVisible() and self._pending_part is not None:
            path, key = self._pending_part
            self._open_pending_part()
            if self._pending_part is None and self.session.path == Path(path).resolve() and self._selected_key == key:
                self._emit_project_selection()

    def _draft_changed(self):
        keys = {part["key"] for part in self.session.document["parts"]}
        if self._selected_key not in keys:
            self._removed_selection_key = self._selected_key
            self._selected_key = self.session.document["parts"][0]["key"]
            self._selected_region = "body"
            self._topology_selection = ()
        if keys != set(getattr(self, "_tree_nodes", {})):
            self._load_tree()
        self._loading = True
        self.tree.setCurrentItem(self._tree_nodes[self._selected_key])
        self._loading = False
        self.selection_label.setText(self.session.part(self._selected_key).get("name", self._selected_key))
        self._load_parameters()
        rendered = self._render(preserve_view=True)
        self._update_buttons()
        if rendered:
            self._message("Draft updated." if self.session.dirty else "Saved dimensions restored.")
        self._queue_overlap_check()

    def _message(self, text, *, error=False):
        self.status.setText(text)
        self.status.setStyleSheet("color: #ffb4a9;" if error else "")

    def _material_editing_enabled(self):
        return (self.session is not None and self._selected_key is not None
                and not non_material_role(self.session.part(self._selected_key)))

    def _region_material_editing_enabled(self):
        if not self._material_editing_enabled():
            return False
        from temsim.cad_catalog import is_reconstruction_region
        from temsim.part_materials import REGIONS
        return (self._selected_region in REGIONS
                and not is_reconstruction_region(self.session.part(self._selected_key), self._selected_region))

    def _update_buttons(self):
        loaded = self.session is not None
        running_geometry = self._cad_geometry_job is not None and self._cad_geometry_job.busy
        self.import_step_button.setEnabled(not self._invalid_inputs and not running_geometry)
        self.geometry_check_button.setEnabled(loaded and not self._invalid_inputs and not running_geometry)
        self.subassembly_button.setEnabled(loaded and bool(self.session.document.get("subassemblies")) and not self._invalid_inputs)
        self.save_button.setEnabled(loaded and self.session.dirty and not self._invalid_inputs)
        self.save_copy_button.setEnabled(loaded and not self._invalid_inputs)
        running_export = self._cad_export_dialog is not None and self._cad_export_dialog.busy
        self.export_step_button.setEnabled(loaded and not self._invalid_inputs and not running_export)
        self.export_step_button.setToolTip(
            "Export the validated module draft, including displayed aperture openings. "
            "Imported STEP and saved cuts/scaling are evaluated as exact B-rep operations. "
            "Display sections do not cut the exported material.")
        self.revert_button.setEnabled(loaded and (self.session.dirty or bool(self._invalid_inputs)))
        self.undo_button.setEnabled(loaded and (self.session.can_undo or bool(self._invalid_inputs)))
        self.redo_button.setEnabled(loaded and self.session.can_redo and not self._invalid_inputs)
        material = self._material_editing_enabled()
        for control in (self.assign_button, self.material, self.region, self.apply_shape_button,
                        self.base_shape, self.add_hole_button, self.add_slot_button):
            control.setEnabled(material)
        self.assign_button.setEnabled(self._region_material_editing_enabled())
        self.material.setEnabled(self._region_material_editing_enabled())
        model = self.session.part(self._selected_key).get("model_3d", {}) if material else {}
        self.reset_model_button.setEnabled(material and bool(model))
        self.edit_feature_button.setEnabled(material and self.feature_tree.currentItem() is not None)
        self.remove_feature_button.setEnabled(material and self.feature_tree.currentItem() is not None)
        for button in (self.new_component_button, self.place_component_button, self.copy_component_button):
            button.setEnabled(loaded and self._selected_key is not None and not self._invalid_inputs)
        host = SHARED_DEFLECTOR_HOSTS.get(self._selected_key)
        if host:
            for button in (self.place_component_button, self.copy_component_button):
                button.setEnabled(False)
                button.setToolTip(f"This control channel shares {host}; select the physical host to edit its placement.")
        else:
            self.place_component_button.setToolTip("Translate the selected component and its children; review local or resolved global Z")
            self.copy_component_button.setToolTip("Create an independent copy in this file or another assembly TOML; Save writes it")
        if loaded:
            self._sync_source_context()
        self._refresh_calculation_status()
        self._refresh_geometry_report_status()
