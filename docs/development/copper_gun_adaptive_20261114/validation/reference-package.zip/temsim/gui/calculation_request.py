"""Small GUI-owned request capture, with independent background preparation.

Capture copies editable values but does not reload configuration, resolve the
column, hash external files or solve reference planes. The worker never reads
the live State. Full-graph requests also detach the installed TOML assembly;
lightweight legacy previews may share its recursively frozen definition.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field, replace
import math
from threading import Event
from types import SimpleNamespace

from temsim.calculation_cache import calculation_signatures, state_model_signature
from temsim.calculation_manifest import (
    ExternalInputIdentity,
    assert_external_input_inventory_unchanged,
    capture_external_input_identities,
)
from temsim.instrument_snapshot import encode_instrument, decode_instrument
from temsim import input_io
from temsim.job_events import job_stage
from temsim.calculation_workflow import admit_workflow, validate_workflow, workflow_signatures


HIGH_ACCURACY_MAXIMUM_STEP_MM = 0.05


def resolve_request_step_mm(quality, requested_step_mm):
    """Bound new GUI High accuracy jobs without modifying restored settings.

    This is a numerical execution policy, not a convergence certificate for
    every field or working point. Explicitly finer steps retain their value.
    Offline calculations and archive restoration do not use this GUI policy.
    """
    step = float(requested_step_mm)
    if not math.isfinite(step) or step <= 0:
        raise ValueError("Particle integration step must be finite and positive")
    return min(step, HIGH_ACCURACY_MAXIMUM_STEP_MM) if quality == "High accuracy" else step


def request_numerical_preparation(quality, requested_step_mm):
    """Describe the requested and applied resolution outside physical inputs."""
    applied = resolve_request_step_mm(quality, requested_step_mm)
    return dict(schema="gui-request-numerical-preparation-v1", quality=str(quality),
        requested_step_mm=float(requested_step_mm), applied_step_mm=applied,
        high_accuracy_maximum_step_mm=HIGH_ACCURACY_MAXIMUM_STEP_MM if quality == "High accuracy" else None,
        changed=applied != float(requested_step_mm),
        qualification="Execution resolution only; working-point convergence requires independent refinement")


class PreparationCancelled(Exception):
    """An obsolete request stopped at a safe preparation boundary."""


class _CapturedModelState(SimpleNamespace):
    def to_dict(self):
        # Signature helpers may normalize their input dictionaries. Keep the
        # original capture independent from every consumer.
        return deepcopy(self._payload)


def reconstruct_calculation_state(
    state_type, payload, resolved_assembly, simulation_time_s,
    quality, ray_count, step_mm,
):
    """Keep the same persistence/assembly authority as synchronous requests."""
    # Bind captured geometry during restoration, before validating operating
    # field widths against bodies that may differ from the live catalog.
    snapshot = state_type.from_dict(payload, resolved_assembly=resolved_assembly)
    if simulation_time_s is not None:
        snapshot.simulation_time_s = float(simulation_time_s)
    return apply_request_numerics(snapshot, quality, ray_count, step_mm)


def apply_request_numerics(snapshot, quality, ray_count, step_mm):
    """Apply declared request resolution to a detached state, never optics."""
    from temsim.physics.optical_tuning import resolve_tuning_ray_count
    ray_count = resolve_tuning_ray_count(snapshot,quality,ray_count)
    emitter = getattr(snapshot.electron_gun, "emitter", None)
    if emitter is not None:
        emitter.ray_count = int(ray_count)
    else:
        snapshot.electron_gun.ray_count = int(ray_count)
    snapshot.step_mm = resolve_request_step_mm(quality, step_mm)
    snapshot.history_step_mm = max(
        snapshot.step_mm, 2.0 if quality == "Preview" else 0.5,
    )
    return snapshot


@dataclass(frozen=True, slots=True)
class PreparedCalculationRequest:
    snapshot: object
    model_signature: str
    request_signatures: dict[str, str]
    ray_count: int
    step_mm: float
    external_inputs: tuple[ExternalInputIdentity, ...] = ()
    calculation_manifest: object = None
    memory_estimate: int = 0
    numerical_preparation: dict = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class CapturedCalculationRequest:
    """Owned editable-value capture; not a reference to a live instrument.

    The private signature view also copies the small component collections and
    resolved anchors. State.to_dict intentionally omits TOML-owned live geometry;
    retaining that geometry is essential to reproduce the original model tag.
    Preview/Medium omit heavy numeric products. High accuracy additionally
    captures the complete parameter graph, including field-map arrays.
    """

    state_type: type
    quality: str
    ray_count: int
    step_mm: float
    _model_state: _CapturedModelState
    _simulation_time_s: float | None
    _instrument_graph: object = None
    _input_assets: object = None
    workflow: str = "full"

    @classmethod
    @input_io.using_state_inputs
    def capture(
        cls, state: object, quality: str, ray_count: int, step_mm: float,
        *, workflow: str = "full",
    ) -> CapturedCalculationRequest:
        validate_workflow(workflow)
        from temsim.optics.electron_gun.source_policy import require_physical_gun_source
        require_physical_gun_source(getattr(state, "electron_gun", None))
        from temsim.physics.optical_tuning import resolve_tuning_ray_count
        ray_count = resolve_tuning_ray_count(state,quality,ray_count)
        graph = None
        assets = None
        from temsim.parameter_registry import unmapped_public_inputs
        extensions = unmapped_public_inputs(state)
        if quality == "High accuracy" or input_io.archive_payload(state) is not None or extensions:
            from temsim.optics.model import State
            if isinstance(state, State):
                from temsim.input_assets import INPUT_ASSETS
                assets = INPUT_ASSETS.capture()
                try:
                    graph = encode_instrument(state, asset_store=assets)
                except Exception:
                    assets.close()
                    raise
        payload = deepcopy(state.to_dict())
        assembly = getattr(state, "_resolved_assembly", None)
        # Components are small parameter objects, not the State's solver caches.
        # Use one memo so aliases (e.g. an Objective lens in several lists) stay
        # coherent, and the immutable assembly is never passed to deepcopy.
        memo = {} if assembly is None else {id(assembly): assembly}
        names = (
            "lenses", "apertures", "stigmators", "deflectors",
            "corrector_elements", "recording_planes", "stem_detectors",
            "sample", "_upper_objective_package_resolved_positions_mm",
            "_ac_downstream_resolved_positions_mm",
            "lens_field_map_descriptors",
        )
        values = {
            name: deepcopy(getattr(state, name), memo)
            for name in names if hasattr(state, name)
        }
        time_s = (
            float(state.simulation_time_s)
            if hasattr(state, "simulation_time_s") else None
        )
        view = _CapturedModelState(
            _payload=payload, _resolved_assembly=assembly,
            simulation_time_s=0.0 if time_s is None else time_s,
            _captured_unmapped_inputs=extensions, **values,
        )
        if input_io.archive_payload(state) is not None:
            view._archive_inputs = input_io.archive_payload(state)
        return cls(
            type(state), str(quality), int(ray_count), float(step_mm), view, time_s, graph, assets, workflow,
        )

    @input_io.using_state_inputs
    def prepare(self, cancel_event: Event) -> PreparedCalculationRequest:
        def check_cancelled():
            if cancel_event.is_set():
                raise PreparationCancelled()

        check_cancelled()
        with job_stage("prepare_identity", backend="CPU"):
            external_inputs = capture_external_input_identities(self._model_state)
            model_signature = state_model_signature(self._model_state)
        check_cancelled()
        if self._instrument_graph is not None:
            snapshot = apply_request_numerics(decode_instrument(self._instrument_graph, assets=self._input_assets),
                self.quality, self.ray_count, self.step_mm)
        else:
            snapshot = reconstruct_calculation_state(
                self.state_type, self._model_state.to_dict(),
                self._model_state._resolved_assembly, self._simulation_time_s,
                self.quality, self.ray_count, self.step_mm,
            )
        check_cancelled()
        from temsim.physics.backend_execution import classical_backend_preflight
        classical_backend_preflight(snapshot)
        numerical_preparation = request_numerical_preparation(self.quality, self.step_mm)
        applied_step_mm = snapshot.step_mm
        with job_stage("prepare_signatures", backend="CPU"):
            signatures = workflow_signatures(calculation_signatures(snapshot), self.workflow)
        check_cancelled()
        assert_external_input_inventory_unchanged(snapshot, external_inputs)
        manifest, estimate = None, 0
        if self.quality == "High accuracy":
            from temsim.gui.calculation_controller import estimate_calculation_memory_bytes, HIGH_ACCURACY_MEMORY_BUDGET_BYTES
            from temsim.calculation_manifest import capture_calculation_manifest
            admit_workflow(snapshot, self.workflow)
            check_cancelled()
            estimate = estimate_calculation_memory_bytes(snapshot, self.quality, self.ray_count, applied_step_mm,
                                                        workflow=self.workflow)
            if estimate > HIGH_ACCURACY_MEMORY_BUDGET_BYTES:
                raise ValueError("Requested calculation exceeds the configured working-memory budget; change numerical settings explicitly")
            manifest = capture_calculation_manifest(snapshot, ray_count=self.ray_count, step_mm=applied_step_mm)
            if self.workflow != "full":
                manifest = replace(manifest, calculation_signatures=signatures)
            check_cancelled()
        return PreparedCalculationRequest(
            snapshot, model_signature, signatures, self.ray_count, applied_step_mm,
            external_inputs, manifest, estimate, numerical_preparation,
        )
