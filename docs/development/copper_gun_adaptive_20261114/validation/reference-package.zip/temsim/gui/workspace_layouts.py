"""Named, presentation-only workspace layouts with per-ray-panel size variants."""
from __future__ import annotations

from copy import deepcopy
from uuid import uuid4

from PySide6.QtCore import QByteArray, QEvent, QObject, QSignalBlocker, QTimer
from PySide6.QtGui import QActionGroup
from PySide6.QtWidgets import QDockWidget, QInputDialog, QSplitter, QTabWidget, QWidget


class WorkspaceLayouts(QObject):
    ROOT = "workspace_layouts/v1"
    RAY_SPLITTERS = {
        "rayDiagramVerticalSplitter", "rayDiagramWorkspaceSplitter",
        "rayDiagramConjugateSplitter",
    }
    RAY_DETAIL_DEFAULTS = {
        "conjugate": False, "interaction": True, "conjugate_details": False,
        "ray_plot_details": False,
    }
    TASK_PAGES = {"Instrument": "Physical Layout", "Alignment": "Ray Diagram",
                  "Experiments": "Design Explorer", "Results": "Ray Diagram"}
    LIVE_PAGES = {"Alignment": "Calculation", "Results": "Working points"}

    def __init__(self, window, settings, menu):
        super().__init__(window)
        self.window, self.settings, self.menu = window, settings, menu
        self.active_id = "default"
        self.restoring = True
        self.splitters = self._named_widgets(QSplitter)
        self.tabs = self._named_widgets(QTabWidget)
        workspace = window.workspace
        self.toggles = {
            "magnetic_link_ray": workspace.magnetic_field.field_lines.link_view,
            "transverse": workspace.transverse_beam_toggle,
            "conjugate": workspace.conjugate_planes_toggle,
            "interaction": workspace.interaction_detail_toggle,
            "conjugate_details": workspace.conjugate_planes.details_toggle,
            "ray_plot_details": workspace.ray_plot_details_toggle,
            "advanced_bank": workspace.interactive_calculation.advanced_bank,
        }
        self.ray_variant = self._ray_variant()
        self.splitter_states = {
            name: {self._variant(name): widget.saveState()}
            for name, widget in self.splitters.items()
        }
        self.pending = set()
        self.restore_timer = QTimer(self)
        self.restore_timer.setSingleShot(True)
        self.restore_timer.timeout.connect(self._restore_pending)
        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.setInterval(600)
        self.save_timer.timeout.connect(self.save_current)
        for name, splitter in self.splitters.items():
            splitter.splitterMoved.connect(lambda *_, n=name: self._splitter_moved(n))
            splitter.installEventFilter(self)
        for tabs in self.tabs.values():
            tabs.currentChanged.connect(self.schedule_save)
        for toggle in self.toggles.values():
            toggle.toggled.connect(self.schedule_save)
        window.installEventFilter(self)
        for dock in window.findChildren(QDockWidget):
            dock.installEventFilter(self)
            dock.visibilityChanged.connect(self.schedule_save)
            dock.topLevelChanged.connect(self.schedule_save)
            dock.dockLocationChanged.connect(self.schedule_save)
        workspace.ray_layout_changing.connect(self._before_ray_change)
        workspace.ray_layout_changed.connect(self._after_ray_change)
        workspace.transverse_beam.plot_sizes_changed.connect(self.schedule_save)
        self.defaults = self._snapshot()
        self.action_group = None
        self.menu.aboutToShow.connect(self.refresh_menu)

    def _named_widgets(self, widget_type):
        # Persist application-owned widgets by stable names, never by list
        # indices or ambiguous names belonging to plotting-library internals.
        widgets = self.window.findChildren(widget_type)
        names = [widget.objectName() for widget in widgets]
        return {widget.objectName(): widget for widget in widgets
                if widget.objectName() and names.count(widget.objectName()) == 1
                and widget.count() > 0}

    def _ray_variant(self):
        workspace = self.window.workspace
        # Magnetic field is a separate main tab. Retain the m0 prefix so
        # existing saved ray-panel arrangements keep their stable keys.
        base = f"m0t{int(workspace.transverse_beam_toggle.isChecked())}"
        conjugate = workspace.conjugate_planes_toggle.isChecked()
        interaction = workspace.interaction_detail_toggle.isChecked()
        # Keep existing saved m/t proportions for the original arrangement.
        # Optional readouts get independent sizes without replacing that state.
        variant = base if not conjugate and interaction else f"{base}c{int(conjugate)}i{int(interaction)}"
        return variant + ("d1" if workspace.ray_plot_details_toggle.isChecked() else "")

    def _variant(self, name):
        return self.ray_variant if name in self.RAY_SPLITTERS else "default"

    def _migrate_splitter_states(self, raw, toggles):
        if not isinstance(raw, dict):
            return {}
        legacy_magnetic = isinstance(toggles, dict) and toggles.get("magnetic") is True
        result = {}
        for name, variants in raw.items():
            if not isinstance(variants, dict):
                continue
            valid = {key: state for key, state in variants.items()
                     if isinstance(key, str) and isinstance(state, QByteArray)}
            if name in self.RAY_SPLITTERS:
                # The two former magnetic visibility variants now describe
                # the same ray layout. Prefer the variant the user last used.
                preferred = "m1" if legacy_magnetic else "m0"
                ordered = sorted(valid, key=lambda key: key.startswith(preferred))
                valid = {
                    ("m0" + key[2:] if key.startswith(("m0t", "m1t")) else key): valid[key]
                    for key in ordered
                }
            if name == "rayDiagramVerticalSplitter" and name in self.splitters:
                # Qt restores the remaining first two panes from its legacy
                # three-pane state. Re-save through its public API to discard
                # the removed field pane while keeping sizes and splitter flags.
                live = self.splitters[name]
                migration = QSplitter(live.orientation())
                for _ in range(live.count()):
                    migration.addWidget(QWidget())
                valid = {key: migration.saveState() for key, state in valid.items()
                         if migration.restoreState(state)}
                migration.deleteLater()
            result[name] = valid
        return result

    def _remember(self, name):
        widget = self.splitters[name]
        if widget.isVisible() and name not in self.pending:
            self.splitter_states.setdefault(name, {})[self._variant(name)] = widget.saveState()

    def _splitter_moved(self, name):
        if not self.restoring:
            # A real drag takes precedence over a pending restore.
            self.pending.discard(name)
            self._remember(name)
            self.schedule_save()

    def _before_ray_change(self):
        if not self.restoring:
            for name in self.RAY_SPLITTERS:
                if name in self.splitters:
                    self._remember(name)

    def _after_ray_change(self):
        if self.restoring:
            return
        self.ray_variant = self._ray_variant()
        self.pending.update(self.RAY_SPLITTERS & self.splitters.keys())
        self.restore_timer.start(0)
        self.schedule_save()

    def eventFilter(self, watched, event):
        if not self.restoring:
            if event.type() == QEvent.Type.Show and isinstance(watched, QSplitter):
                self.pending.add(watched.objectName())
                self.restore_timer.start(0)
            if event.type() in (QEvent.Type.Resize, QEvent.Type.Move, QEvent.Type.Show, QEvent.Type.Hide):
                self.schedule_save()
        return super().eventFilter(watched, event)

    def _restore_pending(self):
        previous = self.restoring
        self.restoring = True
        try:
            for name in tuple(self.pending):
                widget = self.splitters.get(name)
                if widget is None:
                    self.pending.discard(name)
                elif widget.isVisible():
                    state = self.splitter_states.get(name, {}).get(self._variant(name))
                    if isinstance(state, QByteArray):
                        widget.restoreState(state)
                    self.pending.discard(name)
        finally:
            self.restoring = previous

    def schedule_save(self, *_):
        if not self.restoring:
            self.save_timer.start()

    def _snapshot(self):
        for name in self.splitters:
            self._remember(name)
        return {
            "schema": 1,
            "geometry": self.window.saveGeometry(),
            "docks": self.window.saveState(),
            "splitters": deepcopy(self.splitter_states),
            "tabs": {name: tabs.tabText(tabs.currentIndex()) for name, tabs in self.tabs.items()},
            "toggles": {name: toggle.isChecked() for name, toggle in self.toggles.items()},
            "transverse_plot_sizes": self.window.workspace.transverse_beam.plot_size_state(),
            "live_width_initialized": getattr(self.window, "_live_tuning_layout_initialized", False),
        }

    def _key(self, layout_id, field):
        return f"{self.ROOT}/layouts/{layout_id}/{field}"

    def _task_snapshot(self, name):
        data = deepcopy(self.defaults)
        data["tabs"]["visualizationTabs"] = self.TASK_PAGES[name]
        if name in self.LIVE_PAGES:
            data["tabs"]["liveTuningPages"] = self.LIVE_PAGES[name]
        data["dock_visibility"] = {"instrumentDock": name != "Results",
                                   "liveTuningDock": name in self.LIVE_PAGES,
                                   "virtualElectronsDock": False}
        return data

    def entries(self):
        self.settings.beginGroup(f"{self.ROOT}/layouts")
        keys = self.settings.childGroups()
        self.settings.endGroup()
        return {key: str(self.settings.value(self._key(key, "name"), key)) for key in keys}

    def restore_active(self):
        if "default" not in self.entries():
            self.settings.setValue(self._key("default", "name"), "Default")
        # Seed arrangements once; keep every existing named/active layout.
        names = {name.casefold() for name in self.entries().values()}
        for name in self.TASK_PAGES:
            if name.casefold() in names:
                continue
            layout_id = "task_"+name.lower()
            if layout_id in self.entries():
                continue
            data = self._task_snapshot(name)
            self.settings.setValue(self._key(layout_id, "name"), name)
            self.settings.setValue(self._key(layout_id, "data"), data)
        selected = str(self.settings.value(f"{self.ROOT}/active", "default"))
        self.active_id = selected if selected in self.entries() else "default"
        saved = self.settings.value(self._key(self.active_id, "data"))
        if isinstance(saved, dict) and saved.get("schema") == 1:
            self._apply(saved)
        else:
            # Migration: keep the legacy main-window state and live splitter
            # on first use, instead of resetting existing user preferences.
            self.restoring = False
        self.refresh_menu()

    def _apply(self, data):
        self.save_timer.stop()
        self.restore_timer.stop()
        self.restoring = True
        try:
            # Picture sizes belong to each named presentation layout. Legacy
            # layouts use defaults instead of inheriting another layout's sizes.
            self.window.workspace.transverse_beam.set_plot_size_state(
                data.get("transverse_plot_sizes")
            )
            for field, restore in (("geometry", self.window.restoreGeometry), ("docks", self.window.restoreState)):
                value = data.get(field)
                if isinstance(value, QByteArray) and not value.isEmpty():
                    restore(value)
            for name, visible in data.get("dock_visibility", {}).items():
                dock = self.window.findChild(QDockWidget, name)
                if dock is not None and type(visible) is bool:
                    dock.setVisible(visible)
                    if visible:
                        dock.raise_()
            toggles = data.get("toggles", {})
            # Older layouts predate the optional readouts. Restore their
            # original presentation instead of inheriting another layout's
            # expanded conjugate panel or hidden interaction budget.
            restored_toggles = dict(self.RAY_DETAIL_DEFAULTS)
            if isinstance(toggles, dict):
                restored_toggles.update(toggles)
            for name, checked in restored_toggles.items():
                if name in self.toggles and isinstance(checked, bool):
                    self.toggles[name].setChecked(checked)
            self.ray_variant = self._ray_variant()
            raw = data.get("splitters", {})
            self.splitter_states = self._migrate_splitter_states(raw, toggles)
            self.window._live_tuning_layout_initialized = bool(data.get("live_width_initialized", True))
            # Restoring presentation tabs must not emit computation requests.
            tab_states = data.get("tabs", {})
            for name, title in (tab_states.items() if isinstance(tab_states, dict) else ()):
                if name == "physicalLayoutTabs" and isinstance(title, str):
                    title = {"2D section": "2D", "3D model editor": "3D Parts"}.get(title, title)
                if name == "energyFilterOutputTabs" and title == "Physical + rays":
                    # Structure and ray plots now live in their own workspaces.
                    # Retain the outputs page with a deterministic default.
                    title = "EELS spectrum"
                tabs = self.tabs.get(name)
                if tabs is not None:
                    for index in range(tabs.count()):
                        if tabs.tabText(index) == title:
                            with QSignalBlocker(tabs):
                                tabs.setCurrentIndex(index)
                            break
            self.pending = set(self.splitters)
        finally:
            self.restoring = False
        # Hidden pages get their own saved sizes after being laid out on Show.
        self.restore_timer.start(0)
        # The blocked tab signal also carries a read-only cache-status refresh.
        # Restore that notification explicitly without emitting calculation or
        # parameter-edit signals. Clean/hidden pages avoid unnecessary work.
        self.window._design_explorer_tab_changed(
            self.window.workspace.tabs.currentIndex()
        )

    def save_current(self):
        if self.restoring:
            return
        self.save_timer.stop()
        self._restore_pending()
        self.settings.setValue(self._key(self.active_id, "data"), self._snapshot())
        self.settings.setValue(f"{self.ROOT}/active", self.active_id)
        self.settings.sync()
        if self.settings.status() != self.settings.Status.NoError:
            self.window.status_label.setText("Could not save workspace layout settings")

    def select(self, layout_id):
        if layout_id == self.active_id:
            return
        if layout_id not in self.entries():
            raise ValueError("Unknown workspace layout")
        data = self.settings.value(self._key(layout_id, "data"))
        if not isinstance(data, dict) or data.get("schema") != 1:
            raise ValueError("This workspace layout is unavailable or incompatible")
        self.save_current()
        self.active_id = layout_id
        self._apply(data)
        self.settings.setValue(f"{self.ROOT}/active", layout_id)
        self.refresh_menu()

    def save_as(self, name):
        name = name.strip()
        if not name or len(name) > 64:
            raise ValueError("Enter a layout name with 1 to 64 characters")
        if name.casefold() in {value.casefold() for value in self.entries().values()}:
            raise ValueError("A layout already uses this name")
        self.save_current()
        layout_id = uuid4().hex
        self.settings.setValue(self._key(layout_id, "name"), name)
        self.active_id = layout_id
        self.save_current()
        self.refresh_menu()
        return layout_id

    def _ask_save_as(self):
        name, accepted = QInputDialog.getText(self.window, "Save layout as", "Layout name")
        if accepted:
            try:
                self.save_as(name)
            except ValueError as exc:
                self.window.status_label.setText(str(exc))

    def _select_from_menu(self, layout_id):
        try:
            self.select(layout_id)
        except ValueError as exc:
            self.window.status_label.setText(str(exc))

    def refresh_menu(self):
        self.menu.clear()
        if self.action_group is not None:
            self.action_group.deleteLater()
        self.action_group = QActionGroup(self)
        for key, name in sorted(self.entries().items(), key=lambda item: (item[0] != "default", item[1].casefold())):
            action = self.menu.addAction(name)
            action.setCheckable(True)
            action.setChecked(key == self.active_id)
            self.action_group.addAction(action)
            action.triggered.connect(lambda checked=False, k=key: self._select_from_menu(k))
        self.menu.addSeparator()
        self.menu.addAction("Save current layout", self.save_current)
        self.menu.addAction("Save layout as...", self._ask_save_as)

    def reset_current(self):
        data = deepcopy(self.defaults)
        for name in self.TASK_PAGES:
            if self.active_id == "task_"+name.lower():
                data = self._task_snapshot(name)
        self._apply(data)
        self.schedule_save()

    def close(self):
        self.save_current()
        self.restoring = True
        self.save_timer.stop()
        self.restore_timer.stop()
