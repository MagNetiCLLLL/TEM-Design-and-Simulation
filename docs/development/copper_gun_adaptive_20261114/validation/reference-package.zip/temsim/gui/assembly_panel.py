"""Complete TEM assembly selector."""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLayout,
    QPushButton,
    QScrollArea,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from temsim.assembly_catalog import AssemblySelection
from temsim.component_keys import ENERGY_FILTER_INTERNAL_KEYS
from temsim.gui.direct_alignment_panel import DirectAlignmentPanel
from temsim.gui.instrument_tree import InstrumentTree, OPTICAL_FILTERS
from temsim.gui.input_policy import WheelSafeComboBox as QComboBox
from temsim.operating_modes import (
    compatible_modes,
    condenser_mode_key,
    load_operating_mode_catalog,
    mode_by_key,
)


class _NavigationTabs(QTabWidget):
    """Scrolling navigation pages must not resize the surrounding setup area."""

    def hasHeightForWidth(self) -> bool:
        return False


class AssemblyPanel(QWidget):
    configuration_requested = Signal()
    operating_mode_requested = Signal(str, str)
    image_projection_requested = Signal()
    condenser_mode_requested = Signal(str)
    direct_alignment_requested = Signal(str, float)
    component_selected = Signal(object)
    component_activated = Signal(object, str)
    navigation_requested = Signal(str, str, float)

    def __init__(self, catalog, selection: AssemblySelection, parent=None) -> None:
        super().__init__(parent)
        self.catalog = catalog

        box = QGroupBox("Instrument configuration")
        box_layout = QVBoxLayout(box)
        self.configure_button = QPushButton("Configure instrument…")
        self.configure_button.setObjectName("configureInstrumentButton")
        self.configure_button.clicked.connect(self.configuration_requested)
        box_layout.addWidget(self.configure_button)
        self.configuration_summary = QLabel()
        self.configuration_summary.setWordWrap(True)
        self.configuration_summary.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        box_layout.addWidget(self.configuration_summary)
        self.set_selection(selection)

        self.operating_mode_catalog = load_operating_mode_catalog()
        mode_box = QGroupBox("Optical operating preset")
        mode_form = QFormLayout(mode_box)
        self.probe_mode = QComboBox()
        self.probe_mode.setObjectName("probeModeSelector")
        self.nanoprobe_range_combo = QComboBox()
        self.nanoprobe_range_combo.setObjectName("nanoprobeRangeSelector")
        self.nanoprobe_range_label = QLabel("Nanoprobe range")
        self.projector_mode = QComboBox()
        self.projector_mode.setObjectName("projectorModeSelector")
        for selector in (self.probe_mode, self.projector_mode):
            selector.setSizeAdjustPolicy(
                QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
            )
            selector.setMinimumContentsLength(18)
        mode_form.addRow("Probe / illumination", self.probe_mode)
        mode_form.addRow(self.nanoprobe_range_label, self.nanoprobe_range_combo)
        mode_form.addRow("Projection", self.projector_mode)
        self.nanoprobe_range_combo.setToolTip(
            "Select the Normal or Large angle optical branch, then apply the preset. "
            "The branches use different C3 and relay settings."
        )
        self.probe_mode.setToolTip(
            "Sample illumination: Microprobe or Nanoprobe, independent of "
            "Image / Diffraction projection. Apply the preset to change optics."
        )
        self.projector_mode.setToolTip(
            "Optics below the sample: Image or Diffraction, independent of "
            "Microprobe / Nanoprobe illumination. Apply the preset to change optics."
        )
        self.apply_operating_mode_button = QPushButton(
            "Apply stored lens preset"
        )
        self.apply_operating_mode_button.setObjectName(
            "applyOperatingModeButton"
        )
        mode_form.addRow(self.apply_operating_mode_button)
        self.focus_image_button = QPushButton("Focus Image at receiver")
        self.focus_image_button.setObjectName("focusImageReceiverButton")
        self.focus_image_button.setToolTip(
            "Refocus Image projection at the inserted screen or Camera while keeping "
            "illumination, Objective and receiver insertion unchanged. "
            "When both are retracted, use the Camera optical reference."
        )
        self.focus_image_button.setEnabled(False)
        self.focus_image_button.clicked.connect(self.image_projection_requested)
        mode_form.addRow(self.focus_image_button)
        self.operating_mode_status = QLabel()
        self.operating_mode_status.setObjectName("operatingModeStatus")
        self.operating_mode_status.setWordWrap(True)
        self.operating_mode_status.setStyleSheet(
            "color: #475569; font-weight: 600;"
        )
        mode_form.addRow(self.operating_mode_status)
        self.load_operating_modes(
            selection, "nano_probe", "diffraction"
        )

        self._assembly = None
        self._runtime_targets = {}
        self._suppress_forward_selection = False

        optical_page = QWidget()
        optical_layout = QVBoxLayout(optical_page)
        optical_layout.setContentsMargins(0, 0, 0, 0)
        filter_row = QHBoxLayout()
        filter_row.addWidget(QLabel("Show"))
        self.optical_filter = QComboBox()
        self.optical_filter.setObjectName("opticalComponentFilter")
        for key, label in OPTICAL_FILTERS:
            self.optical_filter.addItem(label, key)
        self.optical_filter.setToolTip(
            "Show one active functional group; electron-source and "
            "corrector components stay with their own assemblies"
        )
        filter_row.addWidget(self.optical_filter, 1)
        optical_layout.addLayout(filter_row)
        self.tree = InstrumentTree()
        optical_layout.addWidget(self.tree, 1)

        mechanical_page = QWidget()
        mechanical_layout = QVBoxLayout(mechanical_page)
        mechanical_layout.setContentsMargins(0, 0, 0, 0)
        mechanical_hint = QLabel(
            "TOML/layout parts without an independent optical runtime object"
        )
        mechanical_hint.setWordWrap(True)
        mechanical_hint.setStyleSheet("color: #64748b; font-weight: 600;")
        mechanical_layout.addWidget(mechanical_hint)
        self.mechanical_tree = InstrumentTree()
        self.mechanical_tree.setObjectName("mechanicalInstrumentTree")
        mechanical_layout.addWidget(self.mechanical_tree, 1)

        self.component_pages = _NavigationTabs()
        self.component_pages.setObjectName("componentNavigationPages")
        self.component_pages.addTab(optical_page, "Optical")
        self.component_pages.addTab(mechanical_page, "Mechanical")
        self.direct_alignment_panel = DirectAlignmentPanel(
            self.operating_mode_catalog, self
        )
        self.direct_alignment = self.direct_alignment_panel
        self.direct_alignment_panel.set_selected_mode_keys(
            self.selected_condenser_mode_key(), self.projector_mode.currentData()
        )
        self.component_pages.addTab(
            self.direct_alignment_panel, "Direct Alignment"
        )
        from temsim.gui.assembly_structure_tree import AssemblyStructureTree
        self.assembly_tree = AssemblyStructureTree()
        assembly_page = QWidget()
        assembly_layout = QVBoxLayout(assembly_page)
        assembly_layout.setContentsMargins(0, 0, 0, 0)
        assembly_layout.addWidget(self.assembly_tree, 1)
        self.export_structure_button = QPushButton("Export assembly map...")
        self.export_structure_button.setToolTip("Save component identities, parent relationships and resolved positions for comparison.")
        self.export_structure_button.clicked.connect(self._export_structure)
        assembly_layout.addWidget(self.export_structure_button)
        self.assembly_tree_index = self.component_pages.addTab(assembly_page, "Assembly")
        self.assembly_tree.component_selected.connect(
            lambda selection: self._forward_selection(self.assembly_tree_index, selection))
        self.assembly_tree.component_activated.connect(
            lambda selection: self._forward_activation(self.assembly_tree_index, selection, "mechanical"))
        self.assembly_tree.navigation_requested.connect(self.navigation_requested)
        self.component_pages.setCurrentIndex(self.assembly_tree_index)

        setup_content = QWidget()
        setup_content.setObjectName("assemblySetupScrollContent")
        setup_layout = QVBoxLayout(setup_content)
        setup_layout.setContentsMargins(0, 0, 0, 0)
        setup_layout.setSizeConstraint(
            QLayout.SizeConstraint.SetMinAndMaxSize
        )
        setup_layout.addWidget(box)
        setup_layout.addWidget(mode_box)

        self.setup_scroll_area = QScrollArea()
        self.setup_scroll_area.setObjectName("assemblySetupScrollArea")
        self.setup_scroll_area.setWidgetResizable(True)
        self.setup_scroll_area.setFrameShape(QScrollArea.Shape.NoFrame)
        self.setup_scroll_area.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self.setup_scroll_area.setWidget(setup_content)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.setup_scroll_area, 1)
        layout.addWidget(self.component_pages, 1)

        self.optical_filter.currentIndexChanged.connect(
            self._reload_optical_tree
        )
        self.component_pages.currentChanged.connect(self._page_changed)
        self.probe_mode.currentIndexChanged.connect(
            self._update_operating_mode_description
        )
        self.nanoprobe_range_combo.currentIndexChanged.connect(
            self._update_operating_mode_description
        )
        self.projector_mode.currentIndexChanged.connect(
            self._update_operating_mode_description
        )
        self.apply_operating_mode_button.clicked.connect(
            self._request_operating_mode
        )
        self.tree.component_selected.connect(
            lambda selection: self._forward_selection(0, selection)
        )
        self.mechanical_tree.component_selected.connect(
            lambda selection: self._forward_selection(1, selection)
        )
        self.tree.component_activated.connect(
            lambda selection: self._forward_activation(
                0, selection, "optical"
            )
        )
        self.mechanical_tree.component_activated.connect(
            lambda selection: self._forward_activation(
                1, selection, "mechanical"
            )
        )
        self.direct_alignment_panel.adjustment_requested.connect(
            self.direct_alignment_requested.emit
        )

    def current_selection(self) -> AssemblySelection:
        """Return the validated immutable configuration, independent of widgets."""
        return self._selection

    def _export_structure(self):
        from pathlib import Path
        import json
        from PySide6.QtWidgets import QFileDialog, QMessageBox
        if self.assembly_tree.structure is None:
            return
        filename, _ = QFileDialog.getSaveFileName(self, "Export assembly map", "assembly-structure.json", "JSON (*.json)")
        if filename:
            try:
                Path(filename).write_text(json.dumps(self.assembly_tree.structure.to_dict(),
                    indent=2, ensure_ascii=False, allow_nan=False)+"\n", encoding="utf-8")
            except OSError as exc:
                QMessageBox.warning(self, "Export assembly map", str(exc))

    def set_selection(self, selection: AssemblySelection) -> None:
        selection = self.catalog.normalise_selection(selection)
        self._operating_column_name = selection.column
        self._has_c3_hardware = bool(self.catalog._by_name(self.catalog.columns, selection.column).properties["c3_lens"])
        from temsim.instrument_configuration import InstrumentUnits
        units = InstrumentUnits.from_selection(self.catalog, selection)
        names = ["Cold FEG" if units.source == "cold_feg" else "Thermionic"]
        names.extend(label for key, label in (
            ("monochromator", "Monochromator"), ("beam_blanker", "Beam blanker"),
            ("c3_lens", "C3"), ("probe_corrector", "Probe corrector"),
            ("image_corrector", "B-COR" if units.image_corrector_design == "bcor" else "CETCOR"),
            ("energy_filter", "Energy filter"))
            if getattr(units, key))
        self.configuration_summary.setText(" · ".join(names))
        self._selection = selection

    def reload_catalog(self, catalog, selection: AssemblySelection) -> None:
        selection = catalog.normalise_selection(selection)
        self.catalog = catalog
        self.set_selection(selection)
        self.operating_mode_catalog = load_operating_mode_catalog()
        self.direct_alignment_panel.set_catalog(self.operating_mode_catalog)
        self.load_operating_modes(selection)

    def load_operating_modes(
        self,
        selection: AssemblySelection,
        condenser_key: str | None = None,
        projector_key: str | None = None,
        *, nanoprobe_range: str | None = None, simulation_mode: str | None = None,
    ) -> None:
        """Populate only modes compatible with the selected assembly."""

        selection = self.catalog.normalise_selection(selection)
        self._operating_column_name = selection.column
        self._has_c3_hardware = bool(self.catalog._by_name(self.catalog.columns, selection.column).properties["c3_lens"])
        if simulation_mode is not None:
            catalog = load_operating_mode_catalog(simulation_mode)
            if catalog.direct_alignments != self.operating_mode_catalog.direct_alignments:
                self.direct_alignment_panel.set_catalog(catalog)
            self.operating_mode_catalog = catalog
        condenser_key = condenser_key or self.selected_condenser_mode_key()
        projector_key = projector_key or self.projector_mode.currentData()
        condenser_modes = compatible_modes(
            "condenser",
            selection.column,
            selection.recording,
            self.operating_mode_catalog,
        )
        projector_modes = compatible_modes(
            "projector",
            selection.column,
            selection.recording,
            self.operating_mode_catalog,
        )
        nano_keys = {"nano_probe", "nano_probe_large_angle"}
        remembered_range = (self.nanoprobe_range_combo.currentData()
                            if nanoprobe_range is None else
                            {"normal": "nano_probe", "large_angle": "nano_probe_large_angle"}[nanoprobe_range])
        range_preferred = condenser_key if condenser_key in nano_keys else remembered_range
        probe_items = [(mode.name, mode.key) for mode in condenser_modes
                       if mode.key not in nano_keys]
        nano_modes = {mode.key for mode in condenser_modes if mode.key in nano_keys}
        if nano_modes:
            probe_items.append(("Nanoprobe", "nano_probe"))
        range_items = [(label, key) for label, key in (
            ("Normal", "nano_probe"), ("Large angle", "nano_probe_large_angle"))
            if self._has_c3_hardware and key in nano_modes]
        references = {mode.key: mode.targets.get("achieved_convergence_sem_angle_mrad")
                      for mode in condenser_modes}
        angles = "; ".join(f"{label}: {float(references[key]):.3g} mrad"
                           for label, key in range_items if references[key] is not None)
        self.nanoprobe_range_combo.setToolTip(
            "Select the Normal or Large angle optical branch, then apply the preset. "
            "The branches use different C3 and relay settings. "
            + (f"Stored reference semi-angles: {angles}. See each preset's qualification limits."
               if angles else "No reference semi-angle is available.")
        )
        for combo, items, preferred in (
            (self.probe_mode, probe_items,
             "nano_probe" if condenser_key in nano_keys else condenser_key),
            (self.nanoprobe_range_combo, range_items, range_preferred),
            (self.projector_mode, [(mode.name, mode.key) for mode in projector_modes], projector_key),
        ):
            blocked = combo.blockSignals(True)
            combo.clear()
            for label, key in items:
                combo.addItem(label, key)
            index = combo.findData(preferred)
            combo.setCurrentIndex(index if index >= 0 else 0)
            combo.blockSignals(blocked)
        self.apply_operating_mode_button.setEnabled(
            self.probe_mode.count() > 0
        )
        self.projector_mode.setPlaceholderText("Current projection retained")
        self.projector_mode.setToolTip(
            "No calibrated projection preset is available for this assembly. "
            "Applying illumination retains the current projection settings."
            if not projector_modes else
            "Apply the selected Image or Diffraction lens preset."
        )
        self._update_operating_mode_description()

    def set_operating_mode_keys(
        self, condenser_key: str, projector_key: str
    ) -> None:
        nano = condenser_key in {"nano_probe", "nano_probe_large_angle"}
        for combo, key in (
            (self.probe_mode, "nano_probe" if nano else condenser_key),
            (self.nanoprobe_range_combo,
             condenser_key if nano else self.nanoprobe_range_combo.currentData()),
            (self.projector_mode, projector_key),
        ):
            index = combo.findData(key)
            if index >= 0:
                blocked = combo.blockSignals(True)
                combo.setCurrentIndex(index)
                combo.blockSignals(blocked)
        self._update_operating_mode_description()

    def selected_condenser_mode_key(self) -> str | None:
        """Return the complete pending preset key without changing live optics."""
        key = self.probe_mode.currentData()
        if key == "nano_probe" and getattr(self, "_has_c3_hardware", True):
            return self.nanoprobe_range_combo.currentData()
        return key

    def set_operating_mode_status(self, text: str) -> None:
        self.operating_mode_status.setText(text)

    def set_direct_alignment_state(self, state) -> None:
        condenser = condenser_mode_key(state)
        self._image_focus_modes = (condenser, "imaging" if state.projector_mode == "image" else "diffraction")
        self._update_image_focus_button()
        available_modes = {
            str(combo.itemData(index))
            for combo in (self.probe_mode, self.nanoprobe_range_combo, self.projector_mode)
            for index in range(combo.count())
            if combo.itemData(index) is not None
        }
        self.direct_alignment_panel.set_state(state, available_modes)

    def update_direct_alignment_metrics(self, metrics) -> None:
        self.direct_alignment_panel.update_metrics(metrics)

    def show_direct_alignment_result(self, result) -> None:
        self.direct_alignment_panel.show_result(result)

    def set_direct_alignment_busy(self, key: str | None) -> None:
        self.direct_alignment_panel.set_busy(key)
        self._image_focus_busy = key is not None
        self._update_image_focus_button()

    def _update_image_focus_button(self) -> None:
        selected = (self.selected_condenser_mode_key(), self.projector_mode.currentData())
        self.focus_image_button.setEnabled(
            selected[1] == "imaging"
            and selected == getattr(self, "_image_focus_modes", None)
            and not getattr(self, "_image_focus_busy", False)
        )

    def set_direct_alignment_message(
        self, message: str, *, error: bool = False
    ) -> None:
        self.direct_alignment_panel.show_status_message(
            message, error=error
        )

    def _update_operating_mode_description(self, _index: int = -1) -> None:
        self._update_image_focus_button()
        nano_selected = self.probe_mode.currentData() == "nano_probe"
        show_range = nano_selected and getattr(self, "_has_c3_hardware", True)
        self.nanoprobe_range_combo.setVisible(show_range)
        self.nanoprobe_range_label.setVisible(show_range)
        condenser_key = self.selected_condenser_mode_key()
        projector_key = self.projector_mode.currentData()
        alignment_panel = getattr(self, "direct_alignment_panel", None)
        if alignment_panel is not None:
            alignment_panel.set_selected_mode_keys(condenser_key, projector_key)
        if condenser_key is None:
            self.operating_mode_status.setText(
                "No calibrated preset is available for this assembly."
            )
            self.operating_mode_status.setToolTip("")
            return
        condenser = mode_by_key(
            condenser_key, self.operating_mode_catalog, column_name=self._operating_column_name
        )
        projector = (mode_by_key(projector_key, self.operating_mode_catalog, column_name=self._operating_column_name)
                     if projector_key is not None else None)
        retained = condenser.calibration_status.startswith("retained_not_recomputed_")
        self.apply_operating_mode_button.setText(
            "Apply illumination preset" if projector is None else
            "Apply stored lens preset"
        )
        angle = condenser.targets.get(
            "achieved_convergence_sem_angle_mrad"
        )
        plane = projector.targets.get("conjugate_plane", "") if projector else "current projection retained"
        plane_label = {
            "objective_image_plane": "objective image plane",
            "objective_back_focal_plane": "objective back focal plane",
            "mode_dependent_image_reference_plane": "image reference plane",
            "mode_dependent_diffraction_reference_plane": (
                "diffraction reference plane"
            ),
        }.get(str(plane), str(plane))
        if condenser.key in {"nano_probe", "nano_probe_large_angle"} and self._has_c3_hardware:
            illumination_note = (
                "Convergence: C2 + C3 + C2 aperture; "
                "probe focus: Mini Condenser + Objective; corrector matching also matters."
            )
        elif condenser.key == "nano_probe":
            illumination_note = (
                "Two-condenser C1 + C2 hardware; no C3 or Normal/Large angle branches. "
                "Probe focus: Mini Condenser + Objective."
            )
        else:
            illumination_note = (
                "Microprobe illumination is calibrated quasi-parallel at "
                "the sample."
            )
        devices = condenser.devices
        c2 = float(devices["condenser_lens_2"]["percent"])
        c3_text = (f"C3 {float(devices['condenser_lens_3']['percent']):.2f}% | "
                   if self._has_c3_hardware and "condenser_lens_3" in devices else "")
        objective = float(devices["objective_lens"]["percent"])
        aperture_values = condenser.apertures["condenser_aperture_2"]
        aperture_um = float(aperture_values["diameter_mm"]) * 1000.0
        angle_text = f"{float(angle):.3f} mrad" if angle is not None else "unmeasured"
        detail_text = (
            f"Preset reference sample semi-angle: {angle_text}. "
            f"C2 {c2:.2f}% | {c3_text}C2 aperture "
            f"diameter {aperture_um:.0f} µm, Objective focus {objective:.1f}%. "
            f"{illumination_note} Projection conjugate: {plane_label}. "
            "These are stored reference values, not measurements of the current beam. "
            "Applying the preset does not revalidate the current source, geometry or "
            "Mini Condenser magnitude. "
            "Apply the preset, use Direct Alignment for coupled user-level "
            "adjustments, or edit individual values under Optical > "
            "Lenses/Correctors."
        )
        self.operating_mode_status.setText(
            ("Stored reference; recalibration pending | " if retained else "Stored reference | ")
            + (f"{self.nanoprobe_range_combo.currentText()} | " if show_range else "")
            + f"{angle_text} | C2 {c2:.2f}% | {c3_text}"
            f"C2 aperture {aperture_um:.0f} µm | Objective {objective:.1f}% | "
            f"{plane_label}"
        )
        self.operating_mode_status.setToolTip(
            detail_text + "\n\nIllumination reference: " + condenser.calibration_reference
            + ("\n\nProjection reference: " + projector.calibration_reference if projector else "")
        )

    def _request_operating_mode(self) -> None:
        condenser_key = self.selected_condenser_mode_key()
        projector_key = self.projector_mode.currentData()
        if condenser_key is not None and projector_key is not None:
            self.operating_mode_requested.emit(
                str(condenser_key), str(projector_key)
            )
        elif condenser_key is not None:
            self.condenser_mode_requested.emit(str(condenser_key))

    def load_assembly(self, assembly, runtime_targets=None) -> None:
        self._assembly = assembly
        self._runtime_targets = dict(runtime_targets or {})
        self.assembly_tree.load_assembly(assembly)
        self.tree.load_optical(
            assembly,
            self._runtime_targets,
            self.optical_filter.currentData() or "all",
            select_first=True,
        )
        self.mechanical_tree.load_mechanical(
            assembly,
            self._runtime_targets,
            select_first=False,
        )
        if self.component_pages.currentIndex() == self.assembly_tree_index:
            if self.assembly_tree.currentItem() is None:
                self.assembly_tree.select_first()
            else:
                self._emit_current_tree_selection(self.assembly_tree)

    def _reload_optical_tree(self, _index: int = -1) -> None:
        if self._assembly is None:
            return
        previous_key = self.tree.current_key()
        self.tree.load_optical(
            self._assembly,
            self._runtime_targets,
            self.optical_filter.currentData() or "all",
            select_first=False,
        )
        if previous_key is None or not self.tree.select_key(previous_key):
            self.tree.select_first()

    def _page_changed(self, index: int) -> None:
        if self._suppress_forward_selection:
            return
        if index == 2:
            return
        if index == self.assembly_tree_index:
            if self.assembly_tree.currentItem() is None:
                self.assembly_tree.select_first()
            else:
                self._emit_current_tree_selection(self.assembly_tree)
            return
        if index not in (0, 1):
            return
        tree = self.tree if index == 0 else self.mechanical_tree
        if tree.currentItem() is None:
            tree.select_first()
        else:
            selection = tree.currentItem().data(
                0, Qt.ItemDataRole.UserRole
            )
            if selection is not None:
                self.component_selected.emit(selection)

    def _forward_selection(self, page_index: int, selection) -> None:
        if (
            not self._suppress_forward_selection
            and self.component_pages.currentIndex() == page_index
        ):
            if page_index != self.assembly_tree_index:
                self.assembly_tree.select_key(selection.key, emit=False)
            else:
                self._sync_secondary_trees(selection.key)
            self.component_selected.emit(selection)

    def _sync_secondary_trees(self, key):
        """Keep optional optical / mechanical views on the selected component."""
        previous = self._suppress_forward_selection
        self._suppress_forward_selection = True
        try:
            category = self._optical_category_for_key(key)
            if category is not None:
                index = self.optical_filter.findData(category)
                if index >= 0:
                    self.optical_filter.setCurrentIndex(index)
            self.tree.select_key(key)
            self.mechanical_tree.select_key(key)
        finally:
            self._suppress_forward_selection = previous

    def _forward_activation(
        self, page_index: int, selection, source: str
    ) -> None:
        if (
            not self._suppress_forward_selection
            and self.component_pages.currentIndex() == page_index
        ):
            self.component_activated.emit(selection, source)

    def _optical_category_for_key(self, key: str) -> str | None:
        if key == "energy_filter" or key in ENERGY_FILTER_INTERNAL_KEYS:
            return None
        if key == "simulation":
            return "all"
        if key == "electron_gun":
            return "electron_source"
        if self._assembly is None:
            return None
        part = next(
            (
                candidate for candidate in self._assembly.parts
                if candidate.key == key
            ),
            None,
        )
        target = self._runtime_targets.get(key)
        module_type = next(
            (
                module.type
                for module in self._assembly.modules
                if module.key == getattr(part, "module_key", None)
            ),
            None,
        )
        if (
            part is None
            or target is None
            or not InstrumentTree._is_optical_part(
                part, self._runtime_targets
            )
        ):
            return None
        return InstrumentTree.optical_category(
            part, target, module_type=module_type
        )

    def _emit_current_tree_selection(self, tree: InstrumentTree) -> None:
        current = tree.currentItem()
        if current is None:
            return
        selection = current.data(0, Qt.ItemDataRole.UserRole)
        if selection is not None:
            self.component_selected.emit(selection)

    def select_key(self, key: str) -> bool:
        """Open, filter and emit the component selected from a plot."""

        key = str(key)
        if (self.component_pages.currentIndex() == self.assembly_tree_index
                and self.assembly_tree.select_key(key, emit=False)):
            self._sync_secondary_trees(key)
            self._emit_current_tree_selection(self.assembly_tree)
            return True
        self.assembly_tree.select_key(key, emit=False)
        selected_tree = None
        selected_page = -1
        self._suppress_forward_selection = True
        try:
            category = self._optical_category_for_key(key)
            if category is not None:
                index = self.optical_filter.findData(category)
                if (
                    index >= 0
                    and self.optical_filter.currentIndex() != index
                ):
                    self.optical_filter.setCurrentIndex(index)
                if self.tree.select_key(key):
                    selected_tree = self.tree
                    selected_page = 0
            if selected_tree is None and self.tree.select_key(key):
                selected_tree = self.tree
                selected_page = 0
            if (
                selected_tree is None
                and self.optical_filter.currentData() != "all"
            ):
                all_index = self.optical_filter.findData("all")
                if all_index >= 0:
                    self.optical_filter.setCurrentIndex(all_index)
                if self.tree.select_key(key):
                    selected_tree = self.tree
                    selected_page = 0
            if (
                selected_tree is None
                and self.mechanical_tree.select_key(key)
            ):
                selected_tree = self.mechanical_tree
                selected_page = 1
            if selected_tree is not None:
                self.component_pages.setCurrentIndex(selected_page)
        finally:
            self._suppress_forward_selection = False
        if selected_tree is None:
            return False
        self._emit_current_tree_selection(selected_tree)
        return True
