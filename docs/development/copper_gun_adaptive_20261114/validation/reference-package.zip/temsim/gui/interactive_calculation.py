"""Explicit range planning and independent cached signal inspection."""
from __future__ import annotations

import json
import math
from pathlib import Path

from PySide6.QtCore import Qt, QSettings, QSignalBlocker, QTimer, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QLineEdit, QHeaderView, QSplitter, QFormLayout,
    QGroupBox, QProgressBar, QFileDialog,
    QSlider, QListWidget, QListWidgetItem, QTabWidget, QScrollArea,
)
from temsim.gui.input_policy import WheelSafeComboBox as QComboBox
from temsim.gui.input_policy import WheelSafeDoubleSpinBox as QDoubleSpinBox
from temsim.gui.input_policy import WheelSafeSpinBox as QSpinBox
from temsim.gui.interactive_controller import InteractiveController
from temsim.gui.aligned_control_table import AlignedControlTable
from temsim.interactive_calculation import (
    CalculationRange, InteractivePlan, available_controls, validate_plan,
    LIVE_CONTROL_GROUPS,
)
from temsim.physics.optical_tuning import TUNING_PROFILES, resolve_tuning_ray_count


_SPLITTER_SETTINGS_KEY = "interactive_calculation/control_splitter"
_LIVE_REFRESH_MS = 50
_BANK_DEBOUNCE_MS = 180


def _label(text):
    label = QLabel(text)
    label.setWordWrap(True)
    label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse
                                  | Qt.TextInteractionFlag.TextSelectableByKeyboard)
    return label


class InteractiveCalculationPage(QWidget):
    capture_requested = Signal()
    build_requested = Signal()
    operation_finished = Signal()
    tuning_changed = Signal(object)
    high_accuracy_requested = Signal()
    rays_requested = Signal()
    readout_updated = Signal(object)
    readout_status_changed = Signal(str)
    section_changed = Signal()
    section_save_requested = Signal()
    section_load_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("interactiveCalculationPage")
        self.controller = InteractiveController(self)
        self.source_state = None
        self.current_state = lambda: self.source_state
        self.seeds = ()
        self.controls = ()
        self.live_widgets = {}
        self.live_plan = None
        self._live_mode = False
        self._readout = None
        self._failed = False
        self._section_result = None
        self._tuning_quality_name = "Preview"
        self.operation_allowed = lambda: True
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(_BANK_DEBOUNCE_MS)
        self.timer.timeout.connect(self._read)
        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.setObjectName("interactiveCalculationSplitter")
        left, middle = QWidget(), QWidget()
        left.setObjectName("interactiveRangePanel")
        middle.setObjectName("interactiveExcitationPanel")
        middle.setMinimumWidth(280)
        self.splitter.addWidget(left)
        self.splitter.addWidget(middle)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.pages = QTabWidget(self)
        self.pages.setObjectName("liveTuningPages")
        self.calculation_page = QWidget()
        self.calculation_page.setObjectName("liveTuningCalculationPage")
        calculation_layout = QVBoxLayout(self.calculation_page)
        calculation_layout.setContentsMargins(0, 0, 0, 0)
        self.calculation_scroll = QScrollArea()
        self.calculation_scroll.setObjectName("liveTuningCalculationScroll")
        self.calculation_scroll.setWidgetResizable(True)
        self.calculation_scroll.setWidget(self.splitter)
        calculation_layout.addWidget(self.calculation_scroll)
        self.pages.addTab(self.calculation_page, "Calculation")
        layout.addWidget(self.pages)
        form = QVBoxLayout(left)
        self.tuning_quality = _label("")
        self.set_tuning_quality("Preview")
        form.addWidget(self.tuning_quality)
        self.capture = QPushButton("Capture current settings")
        self.capture.clicked.connect(self.capture_requested)
        form.addWidget(self.capture)
        self.capture_info = _label("Capture settings and enter ranges for live tuning. Run a final high-accuracy calculation when ready.")
        form.addWidget(self.capture_info)
        self.choice = QComboBox()
        self.choice.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.choice.setMinimumContentsLength(18)
        add = QPushButton("Add range")
        add.clicked.connect(self._add_range)
        buttons = QHBoxLayout()
        buttons.addWidget(self.choice, 1)
        buttons.addWidget(add)
        form.addLayout(buttons)
        self.ranges = QTableWidget(0, 6)
        self.ranges.setHorizontalHeaderLabels(["Parameter / unit", "Minimum", "Maximum", "Bank samples", "Bank update", "Reference"])
        self.ranges.horizontalHeader().moveSection(5, 1)
        self.ranges.setWordWrap(False)
        self.ranges.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for col in (1, 2, 3, 4, 5):
            self.ranges.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        form.addWidget(self.ranges)
        remove = QPushButton("Remove selected range")
        remove.clicked.connect(self._remove_range)
        form.addWidget(remove)
        self.section_group = QGroupBox("Calculation section (optional)")
        self.section_group.setObjectName("interactiveSectionTuning")
        self.section_group.setCheckable(True)
        self.section_group.setChecked(False)
        self.section_group.setEnabled(False)
        section_layout = QVBoxLayout(self.section_group)
        self.section_body = QWidget()
        section_layout.addWidget(self.section_body)
        section_form = QVBoxLayout(self.section_body)
        section_form.setContentsMargins(0, 0, 0, 0)
        self.section_scope = _label("Particle transport to the selected plane; inserted specimens scatter electrons.")
        section_form.addWidget(self.section_scope)
        self.section_plane = QComboBox()
        self.section_plane.setObjectName("interactiveSectionPlane")
        self.section_plane.addItem("Custom Z", None)
        self.section_z = QDoubleSpinBox()
        self.section_z.setObjectName("interactiveSectionZ")
        self.section_z.setDecimals(6)
        self.section_z.setRange(0., 1e6)
        self.section_z.setSuffix(" mm")
        self.section_z.setSingleStep(1.)
        section_position = QFormLayout()
        section_position.addRow("Target plane", self.section_plane)
        section_position.addRow("Target Z", self.section_z)
        section_form.addLayout(section_position)
        section_form.addWidget(_label("Participating range components"))
        self.section_components = QListWidget()
        self.section_components.setObjectName("interactiveSectionComponents")
        self.section_components.setMaximumHeight(96)
        self.section_components.setToolTip(
            "Select the components whose ranges participate in section tuning. "
            "Other components retain their current settings. Detector ranges belong to Advanced bank.")
        section_form.addWidget(self.section_components)
        self.section_status = _label("Capture settings and choose an end plane. Add ranges only for live tuning.")
        self.section_status.setObjectName("interactiveSectionStatus")
        section_form.addWidget(self.section_status)
        self.section_save = QPushButton("Export result…")
        self.section_save.setObjectName("saveInteractiveSection")
        self.section_save.setEnabled(False)
        self.section_save.setToolTip("Export the displayed calculation, its calculated settings and exact continuation state.")
        self.section_save.clicked.connect(self.section_save_requested)
        self.section_load = QPushButton("Open result…")
        self.section_load.setObjectName("loadInteractiveSection")
        self.section_load.setToolTip("Restore calculated settings and display the saved result without recalculation.")
        self.section_load.clicked.connect(self.section_load_requested)
        self.section_body.hide()
        self.section_group.toggled.connect(self.section_body.setVisible)
        self.section_group.toggled.connect(self._section_options_changed)
        self.section_plane.currentIndexChanged.connect(self._section_plane_selected)
        self.section_z.valueChanged.connect(self._section_z_changed)
        self.section_components.itemChanged.connect(self._section_options_changed)
        form.addWidget(self.section_group)
        archive_group = QGroupBox("Saved result")
        archive_layout = QVBoxLayout(archive_group)
        self.section_archive_status = _label(
            "Completed matching particle calculations are saved automatically. No saved state yet.")
        self.section_archive_status.setObjectName("particleSectionArchiveStatus")
        archive_layout.addWidget(self.section_archive_status)
        result_actions = QHBoxLayout()
        result_actions.addWidget(self.section_load)
        result_actions.addWidget(self.section_save)
        archive_layout.addLayout(result_actions)
        form.addWidget(archive_group)
        self._section_archive_identity = None
        self._section_archive_current = True
        self._section_archive_info = None
        self.live_start = QPushButton("Start live tuning")
        self.live_start.setToolTip("Uses continuous values inside the declared ranges and updates current settings and Ray Diagram. Does not build a high-accuracy bank.")
        self.live_start.clicked.connect(self.start_live_tuning)
        form.addWidget(self.live_start)
        self.final_calculation = QPushButton("Calculate current section (High accuracy)")
        self.final_calculation.setProperty("calculationAction", True)
        self.final_calculation.setToolTip("Execute the selected cutoff and keep its exact continuation state. Without a cutoff, this runs the complete configured calculation.")
        self.final_calculation.clicked.connect(self._request_high_accuracy)
        form.addWidget(self.final_calculation)
        advanced = QGroupBox("Advanced bank (optional)")
        self.advanced_bank = advanced
        advanced.setCheckable(True)
        advanced.setChecked(False)
        advanced_layout = QVBoxLayout(advanced)
        advanced_body = QWidget()
        advanced_form = QVBoxLayout(advanced_body)
        advanced_layout.addWidget(advanced_body)
        advanced_body.hide()
        advanced.toggled.connect(advanced_body.setVisible)
        advanced.toggled.connect(lambda visible: self.ranges.setColumnHidden(3, not visible))
        advanced.toggled.connect(lambda visible: self.ranges.setColumnHidden(4, not visible))
        self.ranges.setColumnHidden(3, True)
        self.ranges.setColumnHidden(4, True)
        form.addWidget(advanced)
        self.budget = QDoubleSpinBox()
        self.budget.setRange(0.25, 20.0)
        self.budget.setValue(6.0)
        self.budget.setSuffix(" GiB")
        budget_layout = QFormLayout()
        budget_layout.addRow("Pinned cache limit", self.budget)
        advanced_form.addLayout(budget_layout)
        self.range_summary = _label("Minimum and maximum are required. Optical samples are exact nodes; readout ranges are continuous.")
        advanced_form.addWidget(self.range_summary)
        self.build = QPushButton("Build high-accuracy bank (advanced)")
        self.build.setToolTip("Uses captured physical settings and the current toolbar compute backend. The backend is fixed for the entire build.")
        self.build.setEnabled(False)
        self.build.clicked.connect(self.build_requested)
        self.cancel = QPushButton("Cancel")
        self.cancel.setEnabled(False)
        self.cancel.clicked.connect(self._cancel)
        actions = QHBoxLayout()
        actions.addWidget(self.build)
        actions.addWidget(self.cancel)
        advanced_form.addLayout(actions)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1000)
        self.progress.setValue(0)
        advanced_form.addWidget(self.progress)
        self.status = _label("No interactive bank. Main-window results are not changed by this page.")
        form.addWidget(self.status)
        self.live_status = _label("")
        form.addWidget(self.live_status)
        self.status.setToolTip("Optical changes use precomputed nodes; post-specimen stops reuse ray coordinates. Completed historical TEM/STEM images can be viewed when available, but new coherent imaging and TEM reprojection are currently unavailable here. Electron beam calculations use their separate workflow. Range edits do not change an existing bank. Capture again after changing the sample or assembly.")
        self.export = QPushButton("Export range plan...")
        self.export.clicked.connect(self._export)
        advanced_form.addWidget(self.export)
        self.live_heading = _label("Excitation / live controls")
        self.live_heading.setParent(middle)
        self.live_heading.move(9, 9)
        self.live_heading.adjustSize()
        self.live_heading.setToolTip("Enter ranges on the left, then start live tuning or build an advanced bank.")
        self.live_table = AlignedControlTable(self.ranges, middle)
        # The main Ray Diagram owns the only live ray plot. This separate
        # widget is reparented into its Cached signals subpage by the workspace.
        self.readout_panel = QWidget(self)
        self.readout_panel.setObjectName("interactiveReadoutPanel")
        self.readout_panel.hide()
        right_layout = QVBoxLayout(self.readout_panel)
        from temsim.gui.calculation_timing_view import CalculationTimingView
        self.calculation_timing = CalculationTimingView()
        right_layout.addWidget(self.calculation_timing)
        self.particle_signal_group = QGroupBox("Current pixel")
        self.particle_signal_group.setObjectName("interactiveParticleSignals")
        pixel_layout = QVBoxLayout(self.particle_signal_group)
        self.particle_signal_status = _label("No completed particle-detector readout.")
        pixel_layout.addWidget(self.particle_signal_status)
        self.particle_signal_table = QTableWidget(0, 4)
        self.particle_signal_table.setObjectName("interactiveParticleSignalTable")
        self.particle_signal_table.setHorizontalHeaderLabels([
            "Detector", "Simulated electrons\n(weighted)", "Electrons/s", "Status",
        ])
        self.particle_signal_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.particle_signal_table.setMaximumHeight(190)
        pixel_layout.addWidget(self.particle_signal_table)
        right_layout.addWidget(self.particle_signal_group)
        self.result_status = _label("No signal readout")
        right_layout.addWidget(self.result_status)
        self.signal_table = QTableWidget(0, 3)
        self.signal_table.setHorizontalHeaderLabels(["Physical detector", "Source fraction", "Current (pA)"])
        self.signal_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        right_layout.addWidget(self.signal_table, 1)
        self.notes = _label("Images: choose Advanced bank in Illuminating Image or Scanning Image.")
        right_layout.addWidget(self.notes)
        self.controller.busy_changed.connect(self._busy)
        self.controller.progress.connect(self._progress)
        self.controller.bank_ready.connect(self._bank_ready)
        self.controller.readout_ready.connect(self._readout_ready)
        self.controller.failed.connect(self.show_error)
        self.splitter.setSizes([460, 340])
        # Old full-page splitters include the now-removed duplicate ray plot.
        saved = QSettings().value(_SPLITTER_SETTINGS_KEY)
        if saved is not None:
            self.splitter.restoreState(saved)
        self.splitter.splitterMoved.connect(lambda *_: QSettings().setValue(
            _SPLITTER_SETTINGS_KEY, self.splitter.saveState()))

    def install_working_points(self, panel):
        """Keep captured records beside the section controls in the same dock."""
        self.pages.addTab(panel, "Working points")

    def _add_control_row(self, control, widget):
        self.live_table.add_control(control, widget)

    def set_particle_signals(self, rows):
        """Publish completed current-pixel counts independently of bank readout."""
        rows = tuple(rows or ())
        self.particle_signal_table.setRowCount(len(rows))
        available = 0
        for row_index, row in enumerate(rows):
            status = str(row.status)
            valid = status == "AVAILABLE"
            available += int(valid)

            def number(value):
                if not valid or value is None or not math.isfinite(float(value)):
                    return "—"
                return f"{float(value):.9g}"

            values = (str(row.name), number(row.simulated_electrons),
                      number(row.electrons_per_second), status.replace("_", " ").capitalize())
            for column, text in enumerate(values):
                item = QTableWidgetItem(text)
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                item.setData(Qt.ItemDataRole.UserRole, str(row.key))
                self.particle_signal_table.setItem(row_index, column, item)
        self.particle_signal_status.setText(
            f"Current pixel | {available} of {len(rows)} detector readouts available."
            if rows else "No completed particle-detector readout.")
        self.particle_signal_status.setToolTip(
            "Weighted simulated electrons describe this particle calculation. "
            "Electrons per second uses the physical source current. A dash means unavailable, not zero.")

    def segment_request(self):
        """Return an explicit section request; ordinary live tuning stays default."""
        if not self.section_group.isChecked():
            return None
        return {
            "target_z_mm": float(self.section_z.value()),
            "component_keys": tuple(
                str(self.section_components.item(row).data(Qt.ItemDataRole.UserRole))
                for row in range(self.section_components.count())
                if self.section_components.item(row).checkState() == Qt.CheckState.Checked
            ),
        }

    def invalidate_section_result(self, message="Section settings changed; calculate again before saving."):
        self._section_result = None
        self.section_save.setEnabled(False)
        self.section_status.setText(message)
        self._section_archive_current = False
        if self._section_archive_info is not None:
            self.set_section_archive_status(self._section_archive_info)

    def expect_section_archive(self, result):
        from temsim.particle_section_io import section_archive_identity
        self._section_archive_identity = section_archive_identity(result)
        self._section_archive_current = True

    def set_section_archive_status(self, info):
        """Only successful IO is described as saved; earlier captures stay labelled."""
        status = info.get("status", "loaded")
        identity = info.get("identity")
        if status in {"loading", "loaded"}:
            self._section_archive_identity = identity
            self._section_archive_current = status == "loaded" and bool(info.get("restored", False))
        elif self._section_archive_identity is not None and identity != self._section_archive_identity:
            return False
        self._section_archive_info = dict(info)
        if status == "loading":
            self.section_archive_status.setText(f"Loading saved particle state from {info.get('path', '')}...")
            return True
        if status == "failed":
            operation = "Loading" if info.get("operation") == "load" else "Saving"
            self.section_archive_status.setText(
                f"{operation} failed: {info.get('error', 'Unknown error')}. The completed calculation remains available.")
            return True
        prefix = ("Saving completed state..." if status == "saving" else "Loaded executed state."
                  if status == "loaded" else "Saved current calculated state." if self._section_archive_current
                  else "Saved earlier calculated state; current settings require a compatibility check.")
        details = [prefix,
            f"{info.get('plane_name', 'Custom plane')} | Z = {float(info['target_z_mm']):.9g} mm | "
            f"{info.get('quality', 'Unknown quality')} | {int(info.get('particle_count', 0))} emitted particles."]
        if info.get("saved_at_utc"):
            details.append(f"Saved at {info['saved_at_utc']}.")
        from temsim.calculation_performance import _seconds
        io_seconds = _seconds(info.get("file_io_seconds"))
        if io_seconds is not None and status in {"loaded", "saved"}:
            operation = {"load": "Load", "save": "Save", "verify_existing": "Existing archive verification"}.get(
                info.get("file_io_operation"), "File")
            if info.get("file_io_reused_measurement"):
                operation = "Previous " + operation.lower()
            details.append(f"{operation} operation: {io_seconds} (excludes queue wait).")
        if info.get("path"):
            details.append(f"File: {info['path']}")
        from temsim.gui.result_files import format_data_size
        if info.get("compressed_size_bytes") is not None:
            details.append(f"File size: {format_data_size(info['compressed_size_bytes'])} (lossless compression).")
        if info.get("unpacked_size_bytes") is not None:
            details.append(f"Unpacked data: {format_data_size(info['unpacked_size_bytes'])}.")
        if info.get("resumable_through_z_mm") is not None:
            details.append(f"Saved axial state reaches Z = {float(info['resumable_through_z_mm']):.9g} mm.")
        if info.get("energy_filter_completed"):
            details.append("Energy-filter calculation completed; bent filter trajectories are recalculated when needed.")
        if info.get("resume_details"):
            details.append(info["resume_details"])
        if info.get("resume_policy"):
            details.append(info["resume_policy"])
        self.section_archive_status.setText("\n".join(details))
        return True

    def set_section_result(self, result):
        """Offer only a completed matching section; the controller checks its inputs."""
        if result is None:
            self.invalidate_section_result("Waiting for a completed section calculation.")
            return False
        request = self.segment_request()
        simulation = getattr(result, "simulation", None)
        metrics = getattr(simulation, "metrics", {})
        target = metrics.get("section_target_z_mm")
        keys = tuple(metrics.get("section_component_keys", ()))
        if (not isinstance(target, (int, float))
                or not math.isfinite(target)
                or (request is not None and (
                    not math.isclose(float(target), request["target_z_mm"], rel_tol=0., abs_tol=5e-7)
                    or sorted(keys) != sorted(request["component_keys"])))):
            return False
        self._section_result = result
        self.section_save.setEnabled(not self.busy)
        details = [f"Completed section at Z = {float(target):.9g} mm."]
        resume = metrics.get("section_resume_z_mm")
        if isinstance(resume, (int, float)) and math.isfinite(resume):
            details.append(
                f"Column state reused through Z = {float(resume):.9g} mm."
                if metrics.get("section_reused_prefix", False)
                else f"Column transport calculated from Z = {float(resume):.9g} mm.")
        if "section_gun_reused" in metrics:
            details.append("Gun calculation reused." if metrics["section_gun_reused"]
                           else "Gun transport calculated from tip emission.")
        if metrics.get("section_reuse_reason"):
            details.append(str(metrics["section_reuse_reason"]))
        if metrics.get("section_vacuum_restart") == "recomputed":
            details.append("Vacuum transport recalculated.")
        elif metrics.get("section_vacuum_restart") == "not_participating":
            details.append("Vacuum scattering disabled.")
        details.append("You can save this completed state or select the next section.")
        self.section_status.setText(" ".join(details))
        return True

    def pause_live_tuning(self):
        """Disarm delayed edits before an explicit result-file operation."""
        self.timer.stop()
        self.controller.cancel()
        self._live_mode = False
        self.live_plan = None
        self.live_widgets = {}
        self.live_table.clear_controls()
        self.live_heading.setText("Excitation / live controls")

    def capture_result_presentation(self):
        """Keep references and small controls for a failed file-open rollback."""
        return {
            "attributes": {key: getattr(self, key) for key in (
                "source_state", "seeds", "controls", "_readout", "_failed",
                "_section_result", "_section_archive_identity", "_section_archive_current",
                "_section_archive_info", "_tuning_quality_name")},
            "ranges": [(self.ranges.item(row, 0).data(Qt.ItemDataRole.UserRole),
                self.ranges.cellWidget(row, 1).text(), self.ranges.cellWidget(row, 2).text(),
                self.ranges.cellWidget(row, 3).value()) for row in range(self.ranges.rowCount())],
            "planes": [(self.section_plane.itemText(i), self.section_plane.itemData(i))
                       for i in range(self.section_plane.count())],
            "plane_index": self.section_plane.currentIndex(),
            "z": (self.section_z.decimals(), self.section_z.minimum(),
                  self.section_z.maximum(), self.section_z.value()),
            "section": self.section_group.isChecked(),
            "components": [self.section_components.item(i).clone()
                           for i in range(self.section_components.count())],
            "labels": [(label, label.text(), label.toolTip()) for label in self.findChildren(QLabel)],
            "timing": (self.calculation_timing.title(), self.calculation_timing.text.toPlainText()),
            "signals": [[self.particle_signal_table.item(r, c).clone()
                         if self.particle_signal_table.item(r, c) else None
                         for c in range(self.particle_signal_table.columnCount())]
                        for r in range(self.particle_signal_table.rowCount())],
        }

    def restore_result_presentation(self, saved):
        """Restore controls/readouts while deliberately keeping live work paused."""
        with QSignalBlocker(self), QSignalBlocker(self.section_group), QSignalBlocker(self.section_z), QSignalBlocker(self.section_components):
            for key, value in saved["attributes"].items():
                setattr(self, key, value)
            with QSignalBlocker(self.choice):
                self.choice.clear()
                for control in self.controls:
                    self.choice.addItem(f"{control.label} ({control.unit})", control)
            self.ranges.setRowCount(0)
            for control, lower, upper, count in saved["ranges"]:
                index = next(i for i, item in enumerate(self.controls) if item.identity == control.identity)
                self.choice.setCurrentIndex(index)
                self._add_range()
                row = self.ranges.rowCount() - 1
                self.ranges.cellWidget(row, 1).setText(lower)
                self.ranges.cellWidget(row, 2).setText(upper)
                self.ranges.cellWidget(row, 3).setValue(count)
            with QSignalBlocker(self.section_plane):
                self.section_plane.clear()
                for text, data in saved["planes"]:
                    self.section_plane.addItem(text, data)
                self.section_plane.setCurrentIndex(saved["plane_index"])
            decimals, lower, upper, value = saved["z"]
            self.section_z.setDecimals(decimals)
            self.section_z.setRange(lower, upper)
            self.section_z.setValue(value)
            self.section_group.setChecked(saved["section"])
            self.section_body.setVisible(saved["section"])
            self.section_components.clear()
            for item in saved["components"]:
                self.section_components.addItem(item)
            # Range rebuilding invalidates the section; restore its provenance last.
            for key, value in saved["attributes"].items():
                setattr(self, key, value)
            self.section_save.setEnabled(self._section_result is not None and not self.busy)
            self.particle_signal_table.setRowCount(len(saved["signals"]))
            for row, items in enumerate(saved["signals"]):
                for column, item in enumerate(items):
                    if item is not None:
                        self.particle_signal_table.setItem(row, column, item)
            for label, text, tooltip in saved["labels"]:
                label.setText(text)
                label.setToolTip(tooltip)
            self.calculation_timing.setTitle(saved["timing"][0])
            self.calculation_timing.text.setPlainText(saved["timing"][1])

    def restore_calculated_result(self, result, info):
        """Restore section controls and saved readouts without emitting edits."""
        from temsim.instrument_snapshot import decode_instrument, encode_instrument
        state = decode_instrument(encode_instrument(result.state_snapshot))
        metrics = result.simulation.metrics
        with (QSignalBlocker(self), QSignalBlocker(self.section_group),
              QSignalBlocker(self.section_plane), QSignalBlocker(self.section_z),
              QSignalBlocker(self.section_components)):
            self.set_source(state)
            self.set_tuning_quality(info["quality"] if info["quality"] in {"Preview", "Medium"} else "Preview")
            self.section_plane.setCurrentIndex(0)
            self.section_z.setDecimals(12)
            self.section_z.setValue(float(info["target_z_mm"]))
            full_path = bool(metrics.get("section_full_path", False))
            self.section_group.setChecked(not full_path)
            self.section_body.setVisible(not full_path)
            self.section_components.clear()
            by_key = {control.key: control.label.rsplit(" / ", 1)[0] for control in self.controls}
            for key in metrics.get("section_component_keys", ()):
                item = QListWidgetItem(by_key.get(key, key))
                item.setData(Qt.ItemDataRole.UserRole, key)
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Checked)
                self.section_components.addItem(item)
            self.set_section_result(result)
            self.expect_section_archive(result)
            self.set_section_archive_status(dict(info, status="loaded", restored=True))
            self.calculation_timing.set_result(result)
            self.set_particle_signals(getattr(result, "particle_signals", None) or ())
        self.live_status.setText("Saved result loaded; live tuning is paused.")
        self.status.setText("Calculated settings restored. Choose a new cutoff or explicitly run a calculation to continue.")

    def _section_options_changed(self, *_):
        self.invalidate_section_result()
        if self._live_mode and self.live_plan is not None:
            request = self.segment_request()
            keys = None if request is None else set(request["component_keys"])
            for axis in self.live_plan.ranges:
                row = self.live_table.control_row(axis.control.identity)
                self.live_table.cellWidget(row, 1).setEnabled(keys is None or axis.control.key in keys)
            if keys is not None and keys - {axis.control.key for axis in self.live_plan.ranges}:
                self.section_status.setText(
                    "Range selection changed; start live tuning to apply the selected components.")
        self.section_changed.emit()

    def _section_plane_selected(self, _index):
        value = self.section_plane.currentData()
        if value is not None:
            self.section_z.blockSignals(True)
            self.section_z.setValue(float(value))
            self.section_z.blockSignals(False)
            self._section_options_changed()

    def _section_z_changed(self, _value):
        current = self.section_plane.currentData()
        if current is not None and not math.isclose(
                float(current), self.section_z.value(), rel_tol=0., abs_tol=5e-7):
            self.section_plane.blockSignals(True)
            self.section_plane.setCurrentIndex(0)
            self.section_plane.blockSignals(False)
        self._section_options_changed()

    def _refresh_section_planes(self, state):
        from temsim.component_names import (
            APERTURE_NAMES, LENS_NAMES, RECORDING_PLANE_NAMES, STIGMATOR_NAMES, DEFLECTOR_NAMES,
        )
        from temsim.physics.particle_sections import section_limits

        minimum, maximum = section_limits(state)
        choices = [("Gun exit", minimum), ("Specimen reference plane", float(state.sample.z_mm))]
        for attribute, names, generic in (
                ("lenses", LENS_NAMES, "Lens"),
                ("apertures", APERTURE_NAMES, "Aperture"),
                ("stigmators", STIGMATOR_NAMES, "Stigmator"),
                ("deflectors", DEFLECTOR_NAMES, "Deflector"),
                ("corrector_elements", {}, "Corrector element"),
                ("recording_planes", RECORDING_PLANE_NAMES, "Recording plane")):
            for index, component in enumerate(getattr(state, attribute, ())):
                if not bool(getattr(component, "installed", True)):
                    continue
                label = names.get(component.key, f"{generic} {index + 1}")
                if attribute == "corrector_elements":
                    label = str(component.name)
                for field, suffix in (("z_mm", ""), ("upper_z_mm", " upper plane"),
                                      ("lower_z_mm", " lower plane")):
                    value = getattr(component, field, None)
                    if value is not None:
                        choices.append((label + suffix, float(value)))
        choices.append(("Last available axial section", maximum))
        self.section_plane.blockSignals(True)
        self.section_z.blockSignals(True)
        self.section_plane.clear()
        self.section_plane.addItem("Custom Z", None)
        for label, value in sorted(choices, key=lambda choice: (choice[1], choice[0])):
            if math.isfinite(value) and minimum <= value <= maximum:
                self.section_plane.addItem(f"{label} | Z = {value:.9g} mm", value)
        self.section_z.setRange(minimum, maximum)
        target = min(max(float(state.sample.z_mm), minimum), maximum)
        self.section_z.setValue(target)
        for index in range(1, self.section_plane.count()):
            if self.section_plane.itemData(index) == target:
                self.section_plane.setCurrentIndex(index)
                break
        self.section_z.setToolTip(
            f"Axial sections from {minimum:.9g} to {maximum:.9g} mm. "
            "When an energy filter is enabled, sections end at its entrance.")
        self.section_z.blockSignals(False)
        self.section_plane.blockSignals(False)

    def _refresh_section_components(self):
        previous = {self.section_components.item(row).data(Qt.ItemDataRole.UserRole):
                    self.section_components.item(row).checkState()
                    for row in range(self.section_components.count())}
        groups = {}
        for row in range(self.ranges.rowCount()):
            control = self.ranges.item(row, 0).data(Qt.ItemDataRole.UserRole)
            if control.group in LIVE_CONTROL_GROUPS:
                groups.setdefault(control.key, []).append(control)
        self.section_components.blockSignals(True)
        self.section_components.clear()
        for key, controls in groups.items():
            label = controls[0].label.rsplit(" / ", 1)[0]
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, key)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(previous.get(key, Qt.CheckState.Checked))
            item.setToolTip("\n".join(control.label for control in controls))
            self.section_components.addItem(item)
        self.section_components.blockSignals(False)
        if self.section_group.isChecked():
            self._section_options_changed()

    @property
    def busy(self):
        return self.controller.busy

    def set_source(self, state, seeds=()):
        if self.busy:
            raise RuntimeError("Cancel the current operation before capturing settings")
        self.timer.stop()
        if self._live_mode:
            self.live_status.clear()
            self._live_mode = False
            self.live_plan = None
            self.live_widgets = {}
            self.live_table.clear_controls()
            self.live_heading.setText("Excitation / live controls")
            self.live_heading.setToolTip("Captured settings: enter new tuning ranges on the left.")
        self.source_state, self.seeds = state, tuple(seeds)
        self.set_tuning_quality(getattr(self,"_tuning_quality_name","Preview"))
        self.controls = available_controls(state)
        self.choice.clear()
        for control in self.controls:
            self.choice.addItem(f"{control.label} ({control.unit})", control)
        self.ranges.setRowCount(0)
        self._refresh_section_planes(state)
        self._refresh_section_components()
        self.section_group.setEnabled(True)
        self.invalidate_section_result("Choose the end plane. Participating range components are optional.")
        self.live_table.sync_draft()
        self.build.setEnabled(True)
        self.capture_info.setText(f"Final calculation: {state.electron_gun.ray_count:,} rays | step {state.step_mm:g} mm. Live tuning uses the Preview or Medium budget selected in the toolbar.")
        self.status.setText("New settings captured. Previous bank remains available until a replacement completes.")
        self._mark_readout_previous("New settings captured")
        # Named planes are refreshed with widget signals blocked. Publish the
        # final selection once so the main ray coverage marker stays in sync.
        self.section_changed.emit()

    def set_tuning_quality(self, quality):
        p = TUNING_PROFILES[quality]
        self._tuning_quality_name = quality
        state = getattr(self,"source_state",None)
        try:
            rays = p.rays if state is None else resolve_tuning_ray_count(state,quality,p.rays)
        except ValueError as error:
            self.tuning_quality.setText(f"Live tuning: {quality} unavailable. {error}")
            return
        self.tuning_quality.setText(f"Live tuning: {quality} ({rays:,} total particles). Change quality in the toolbar.")

    def start_live_tuning(self):
        try:
            if self.busy:
                raise ValueError("Finish or cancel the bank operation first")
            plan = self.plan(precompute=False, live_only=True)
            if not self.operation_allowed():
                raise ValueError("Finish the active calculation before starting live tuning")
            previous_values = ({key: widget.value() for key, widget in self.live_widgets.items()}
                               if self._live_mode and self.section_group.isChecked() else {})
            self.timer.stop()
            self._failed = False
            self.live_plan = plan
            self._live_mode = True
            self.live_heading.setText("Live controls")
            self.live_heading.setToolTip("Live tuning updates current settings and Ray Diagram.")
            self.live_table.clear_controls()
            self.live_widgets = {}
            for axis in plan.ranges:
                row = QWidget()
                row_layout = QHBoxLayout(row)
                row_layout.setContentsMargins(0, 0, 0, 0)
                slider = QSlider(Qt.Orientation.Horizontal)
                slider.setMinimumWidth(90)
                slider.setToolTip(f"{axis.control.label} ({axis.control.unit})")
                slider.setRange(0, 10000)
                slider.setTracking(True)
                slider.sliderReleased.connect(self._flush_live_tuning)
                value = QDoubleSpinBox()
                value.setDecimals(14 if axis.control.group == "source" else 9)
                value.setRange(axis.minimum, axis.maximum)
                value.setSuffix(f" {axis.control.unit}")
                value.setSingleStep((axis.maximum-axis.minimum)/1000)
                initial = previous_values.get(axis.control.identity, axis.control.current)
                value.setValue(min(max(initial, axis.minimum), axis.maximum))
                slider.setValue(round(10000*(value.value()-axis.minimum)/(axis.maximum-axis.minimum)))
                slider.valueChanged.connect(lambda i, w=value, a=axis: w.setValue(
                    a.minimum + i*(a.maximum-a.minimum)/10000))
                def changed(v, s=slider, a=axis):
                    s.blockSignals(True)
                    s.setValue(round(10000*(v-a.minimum)/(a.maximum-a.minimum)))
                    s.blockSignals(False)
                    self._queue_read()
                value.valueChanged.connect(changed)
                row_layout.addWidget(slider, 1)
                row_layout.addWidget(value)
                self.live_widgets[axis.control.identity] = value
                self._add_control_row(axis.control, row)
            self.live_status.setText("Live tuning | waiting for rays")
            self.rays_requested.emit()
            self.status.setText("Live tuning: selected particle controls update current settings and detector readout."
                                + (" Detector rows: Advanced bank only."
                                   if len(plan.ranges) < self.ranges.rowCount() else ""))
            self.timer.start(_LIVE_REFRESH_MS)
        except (ValueError, RuntimeError) as exc:
            self.show_error(str(exc), affects_readout=False)

    def _flush_live_tuning(self):
        # Release submits the final value even inside the current throttle window.
        if self._live_mode and self.timer.isActive():
            self.timer.stop()
            self._read()

    def _request_high_accuracy(self):
        # Flush the final slider value before the explicit single calculation.
        self._flush_live_tuning()
        self.high_accuracy_requested.emit()

    def display_tuning_status(self, result):
        """Report the shared ray frame without drawing or changing cached signals."""
        if self._live_mode:
            metrics = result.simulation.metrics
            detail = ("Particle transport and detector signals updated"
                      if metrics.get("particle_tuning", False)
                      else "rays updated; sample signals not calculated")
            self.live_status.setText(f"{metrics.get('tuning_quality', 'Preview')} | {detail}")

    def _add_range(self):
        control = self.choice.currentData()
        if control is None:
            return
        # The selection list can predate live edits. Read the value when the
        # unit is added; keep this reference distinct from user-entered bounds.
        current = {c.identity: c for c in available_controls(self.current_state())}
        if control.identity not in current:
            self.show_error("This component changed; capture the current settings again", affects_readout=False)
            return
        control = current[control.identity]
        if any(self.ranges.item(i, 0).data(Qt.ItemDataRole.UserRole).identity == control.identity
               for i in range(self.ranges.rowCount())):
            self.show_error("This parameter already has a range", affects_readout=False)
            return
        row = self.ranges.rowCount()
        self.ranges.insertRow(row)
        name = control.label.removesuffix(" / Excitation")
        item = QTableWidgetItem(f"{name} ({control.unit})")
        item.setData(Qt.ItemDataRole.UserRole, control)
        item.setToolTip(f"{control.label}\nReference when added: {control.current:.9g} {control.unit}")
        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        self.ranges.setItem(row, 0, item)
        reference = QTableWidgetItem(f"{control.current:.9g}")
        reference.setFlags(reference.flags() & ~Qt.ItemFlag.ItemIsEditable)
        reference.setToolTip(f"Reference when added: {control.current:.9g} {control.unit}")
        self.ranges.setItem(row, 5, reference)
        reference_display = QLineEdit(reference.text())
        reference_display.setReadOnly(True)
        reference_display.setMaximumWidth(92)
        reference_display.setToolTip(reference.toolTip())
        self.ranges.setCellWidget(row, 5, reference_display)
        for col in (1, 2):
            edit = QLineEdit()
            edit.setPlaceholderText("Required")
            if control.group == "source":
                # Visible editable starting range, never an implicit bank axis.
                edit.setText("0" if col == 1 else f"{max(1e-5, control.current):.12g}")
            edit.setMaximumWidth(96)
            self.ranges.setCellWidget(row, col, edit)
        samples = QSpinBox()
        samples.setRange(2, 129)
        samples.setValue(5)
        samples.setEnabled(control.stage == "optical")
        self.ranges.setCellWidget(row, 3, samples)
        stage = QTableWidgetItem("Precompute" if control.stage == "optical" else "Readout")
        stage.setFlags(stage.flags() & ~Qt.ItemFlag.ItemIsEditable)
        self.ranges.setItem(row, 4, stage)
        self.live_table.sync_draft()
        self._refresh_section_components()

    def _remove_range(self):
        if self.ranges.currentRow() >= 0:
            self.ranges.removeRow(self.ranges.currentRow())
            self.live_table.sync_draft()
            self._refresh_section_components()

    def plan(self, *, precompute=True, live_only=False):
        axes = []
        section = self.segment_request() if live_only else None
        for row in range(self.ranges.rowCount()):
            control = self.ranges.item(row, 0).data(Qt.ItemDataRole.UserRole)
            # Detector geometry belongs to detached bank readout. Its draft
            # endpoints must not prevent unrelated live optical tuning.
            if live_only and control.group == "detector":
                continue
            if section is not None and control.key not in section["component_keys"]:
                continue
            lo, hi = (self.ranges.cellWidget(row, c).text().strip() for c in (1, 2))
            if not lo or not hi:
                raise ValueError(f"Range {row + 1}: minimum and maximum are required")
            axes.append(CalculationRange(control, float(lo), float(hi), self.ranges.cellWidget(row, 3).value()))
        if live_only and not axes:
            raise ValueError("Add and select a physical component range for live tuning. Detector geometry rows use Advanced bank.")
        plan = InteractivePlan(tuple(axes), int(self.budget.value() * 1024**3), precompute)
        if self.source_state is None:
            raise ValueError("Capture the current settings first")
        validate_plan(self.source_state, plan)
        return plan

    def start_build(self):
        try:
            self.timer.stop()
            self._live_mode = False
            plan = self.plan()
            self._failed = False
            self.progress.setValue(0)
            self.progress.setFormat("Preparing range cache")
            self.range_summary.setText(f"{plan.point_count} optical combinations | {self.budget.value():g} GiB cache limit | no lens interpolation")
            self.status.setText("Building independent range cache; previous results retained.")
            self._mark_readout_previous("Building a replacement bank")
            compute_backend = getattr(self.current_state(), "acceleration_backend", "Auto")
            self.controller.build(self.source_state, plan, self.seeds,
                                  compute_backend=compute_backend)
        except (ValueError, RuntimeError, TypeError) as exc:
            self.show_error(str(exc))

    def _busy(self, busy):
        for widget in (self.capture, self.build, self.ranges, self.choice, self.budget,
                       self.live_start, self.final_calculation, self.section_group,
                       self.section_load):
            widget.setEnabled(not busy)
        self.section_group.setEnabled(not busy and self.source_state is not None)
        self.section_save.setEnabled(not busy and self._section_result is not None)
        self.cancel.setEnabled(busy)
        if not busy:
            self.operation_finished.emit()

    def _progress(self, index, count, done, total, stage):
        self.progress.setValue(round(1000 * (index + done / max(total, 1)) / count))
        self.progress.setFormat(f"Point {index + 1}/{count} | {stage}")
        self.progress.setToolTip(
            "Points and stages have equal bar space, not equal execution time. "
            "Any percentage in the label belongs only to the named stage."
        )

    def _bank_ready(self, bank):
        self._live_mode = False
        self.live_status.clear()
        self.live_heading.setText("Cached controls")
        self.live_heading.setToolTip("Explore the completed range, separately from draft ranges and live settings.")
        self.seeds = ()
        self.progress.setValue(1000)
        self.status.setText(f"Ready: {len(bank.points)} optical points | {bank.retained_bytes / 1024**3:.3f} GiB pinned. Main results unchanged.")
        self.live_table.clear_controls()
        self.live_widgets = {}
        for axis in bank.plan.ranges:
            if axis.control.stage == "optical":
                widget = QComboBox()
                for value in axis.values:
                    widget.addItem(f"{value:.9g} {axis.control.unit}", value)
                widget.currentIndexChanged.connect(self._queue_read)
            else:
                widget = QDoubleSpinBox()
                widget.setDecimals(14 if axis.control.group == "source" else 9)
                widget.setRange(axis.minimum, axis.maximum)
                widget.setSingleStep((axis.maximum - axis.minimum) / 100)
                widget.setValue(min(max(axis.control.current, axis.minimum), axis.maximum))
                widget.setSuffix(f" {axis.control.unit}")
                widget.valueChanged.connect(self._queue_read)
            self.live_widgets[axis.control.identity] = widget
            self._add_control_row(axis.control, widget)
        self._mark_readout_previous("New bank ready; preparing readout")
        self.timer.start(_BANK_DEBOUNCE_MS)

    def _queue_read(self, *_):
        if self._live_mode:
            if self.section_group.isChecked():
                self.invalidate_section_result("Live settings changed; waiting for the section calculation.")
            self.live_status.setText("Live tuning | updating rays")
            # Throttle instead of debounce: sustained motion must not postpone
            # every update until the mouse stops. Read the latest values only.
            if not self.timer.isActive():
                self.timer.start(_LIVE_REFRESH_MS)
            return
        self._mark_readout_previous("Bank settings changed; updating")
        self.timer.start(_BANK_DEBOUNCE_MS)

    def _mark_readout_previous(self, reason):
        prefix = "Previous bank readout" if self._readout is not None else "No bank readout"
        message = f"{prefix} | {reason}"
        self.result_status.setText(message)
        self.readout_status_changed.emit(message)

    def _bank_coordinates(self):
        return {key: widget.currentData() if isinstance(widget, QComboBox) else widget.value()
                for key, widget in self.live_widgets.items()}

    def _read(self):
        if not self.live_widgets:
            return
        if self._live_mode:
            section = self.segment_request()
            values = tuple((axis, self.live_widgets[axis.control.identity].value())
                           for axis in self.live_plan.ranges
                           if section is None or axis.control.key in section["component_keys"])
            if values:
                self.tuning_changed.emit(values)
            return
        if not self.operation_allowed():
            self.show_error("Finish the main calculation or alignment before reading the interactive bank")
            return
        coordinates = self._bank_coordinates()
        try:
            self._mark_readout_previous("Updating selected bank settings")
            self.controller.read(coordinates)
        except (ValueError, RuntimeError) as exc:
            self.show_error(str(exc))

    def _readout_ready(self, result):
        # A slider can change while a readout finishes, before the debounce
        # timer submits its replacement. Never label that older setting ready.
        if not self._live_mode and self.live_widgets and self._bank_coordinates() != dict(result.coordinates):
            return
        self._readout = result
        self.result_status.setText("Advanced bank | readout ready")
        self.result_status.setToolTip("\n".join(f"{key}: {value:.9g}" for key, value in result.coordinates.items()))
        self.signal_table.setRowCount(len(result.detector_fractions))
        for row, (key, fraction) in enumerate(result.detector_fractions.items()):
            for col, text in enumerate((key, f"{fraction:.9g}", f"{result.detector_current_pa[key]:.9g}")):
                item = QTableWidgetItem(text)
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.signal_table.setItem(row, col, item)
        self.notes.setText("TEM: " + ("available" if result.wave is not None else "unavailable")
                           + " | STEM: " + ("available" if result.stem is not None else "unavailable")
                           + ". Images: choose Advanced bank in Illuminating Image or Scanning Image.")
        self.notes.setMaximumHeight(60)
        self.notes.setToolTip("\n".join(result.notes))
        # This event is the only successful bank-image publication. A later
        # busy=False notification must not mark the completed image pending.
        self.readout_updated.emit(result)

    def _cancel(self):
        self.controller.cancel()
        self.status.setText("Cancellation requested; previous complete bank retained.")
        if not self._live_mode:
            self._mark_readout_previous("Bank operation cancelled")

    def show_error(self, message, *, affects_readout=True):
        self._failed = True
        self.status.setText(str(message))
        self.progress.setFormat("Stopped: " + str(message))
        if affects_readout and not self._live_mode:
            self._mark_readout_previous("No new result; " + str(message))

    def _export(self):
        try:
            plan = self.plan()
            path, _ = QFileDialog.getSaveFileName(self, "Export range plan", "", "JSON (*.json)")
            if path:
                data = {"schema": "interactive-range-v1", "cache_budget_bytes": plan.cache_budget_bytes,
                        "optical_points": plan.point_count, "ranges": [
                            {"control": r.control.identity, "unit": r.control.unit, "minimum": r.minimum,
                             "maximum": r.maximum, "points": r.points, "stage": r.control.stage} for r in plan.ranges]}
                Path(path).write_text(json.dumps(data, indent=2, allow_nan=False), encoding="utf-8")
        except (OSError, ValueError) as exc:
            self.show_error(str(exc), affects_readout=False)

    def shutdown(self):
        self.timer.stop()
        return self.controller.shutdown()
