"""Cached-plane analysis controls for the right-hand beam panel.

Particle views are bounded display samples. Flux maps, angular histograms and
interaction tables instead use every weighted ray reaching the selected plane.
None of these views is a wave image or a detector readout.
"""

from __future__ import annotations

from html import escape
import math

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import QObject, QRectF, Qt, QTimer, Slot
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QHBoxLayout, QHeaderView, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from temsim.gui.input_policy import WheelSafeComboBox
from temsim.gui.emission_source_data import EmissionSourceData
from temsim.gui.beam_colours import emission_colour
from temsim.gui.filter_plane_data import sample_filter_plane
from temsim.gui.beam_plane_data import (
    sample_beam_plane, angular_histogram,
)
from temsim.gui.beam_spot_data import rasterize_beam_spot
from temsim.gui.transverse_projection import (
    transverse_view_coordinates, projection_axis_name, orthogonal_axis_name,
)


class BeamAnalysisControls(QObject):
    """Presentation-only companion of TransverseBeamView; one plane cache."""

    MODES = (
        ("Position X-Y", "position"),
        ("Angular X-Y", "angular"),
        ("Angle distribution", "angle_histogram"),
        ("Beam intensity", "intensity"),
        ("Interaction breakdown", "interactions"),
        ("Phase space U / θU", "phase_u"),
        ("Phase space V / θV", "phase_v"),
    )
    POINT_MODES = {"position", "angular", "phase_u", "phase_v"}
    CENTRED_MODES = {"angular", "intensity", "phase_u", "phase_v"}
    EQUAL_UNIT_MODES = {"position", "angular", "intensity"}
    BINS = 64
    COLOUR_MODES = (("Source position", "source"),
                   ("Emission direction (azimuth)", "emission_direction"),
                   ("Emission angle to normal", "emission_angle"),
                   ("Time of flight", "tof"),
                   ("Interaction type", "interaction"))
    # A tracking selection defines both coordinates and colour. Independent
    # combinations belong only to the explicitly selected diagnostics view.
    TRACKING_PRESETS = {
        "source": ("Source position → position X-Y", "position", "source"),
        "emission_direction": (
            "Emission direction → angular X-Y", "angular", "emission_direction"),
        "tof": ("Time of flight → position X-Y", "position", "tof"),
    }

    def __init__(self, owner):
        # Qt must disconnect view/menu signals when their owning panel dies,
        # even if Python references keep this companion alive until cyclic GC.
        super().__init__(owner)
        self.owner = owner
        self.mode = "position"
        self.wave = None
        from temsim.gui.beam_tof_analysis import BeamTimeOfFlight
        self.tof = BeamTimeOfFlight(self)
        self._cache = None
        self._cache_key = None
        self._filter_cache = None
        self._filter_cache_key = None
        self._source_data = None
        self._source_has_positions = False
        self._source_brush_cache = {}
        self._source_plot_key = None
        self._advanced = False
        self._published_colour = None
        self._ranges = {}
        self._hover_payload = None
        self._drawing = False
        self._particle_mode = "position"
        self._spot_cache_key = None
        self._spot_raster = None
        self._spot_scale_by_unit = {}
        self._spot_colour_unit = None
        self._spot_colour_maximum = None
        self._spot_current_maximum = None
        self._spot_image = pg.ImageItem(axisOrder="row-major")
        self._spot_image.setLookupTable(pg.colormap.get("viridis").getLookupTable(nPts=256))
        self.mode_combo = WheelSafeComboBox()
        self.mode_combo.setObjectName("beamAnalysisMode")
        for label, key in self.MODES:
            self.mode_combo.addItem(label, key)
        self.mode_combo.setToolTip(
            "Analyse cached rays at the selected Z. Intensity and distributions "
            "use physical weights, not the displayed point count. No retracing."
        )
        self.tracking_combo = WheelSafeComboBox()
        self.tracking_combo.setObjectName("beamTrackingPreset")
        for key, (label, _mode, _colour) in self.TRACKING_PRESETS.items():
            self.tracking_combo.addItem(label, key)
        self.tracking_combo.addItem("Advanced diagnostics", "advanced")
        self.tracking_combo.setItemData(2,
            "Cumulative arrival time at the selected plane, since simultaneous tip emission. "
            "Incomplete or historical path clocks remain grey. This is not wave phase.", Qt.ItemDataRole.ToolTipRole)
        self.tracking_combo.setToolTip(
            "One selection sets both plots. Source position: position below, fixed launch-position colour. "
            "Emission direction: angles below, fixed launch-azimuth colour. "
            "Time of flight: position below, the same arrival-time colour in both plots and Ray Diagram. "
            "The upper axes always show actual tip emission positions. "
            "Advanced diagnostics exposes separate analysis controls. No retracing."
        )
        preset_row = QHBoxLayout()
        preset_row.addWidget(QLabel("Plot"))
        preset_row.addWidget(self.tracking_combo, 1)
        owner.initial_beam_panel.layout().insertLayout(0, preset_row)
        self.colour_combo = WheelSafeComboBox()
        self.colour_combo.setObjectName("beamAnalysisColourBy")
        for label, key in self.COLOUR_MODES:
            self.colour_combo.addItem(label, key)
        self.colour_combo.setToolTip(
            "Source position and emission angles are fixed at actual launch, before extraction. "
            "Emission azimuth is about +Z; emission angle is relative to the local surface normal. "
            "Grey means unavailable launch or timing data. TOF follows saved path clocks; "
            "interaction colour follows the recorded channel."
        )
        self.legend = QLabel()
        self.legend.setWordWrap(True)
        self.readout = QLabel()
        self.readout.setWordWrap(True)
        for label in (self.legend, self.readout):
            label.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextSelectableByMouse
                | Qt.TextInteractionFlag.TextSelectableByKeyboard
            )
            label.setStyleSheet("color: #94a3b8;")
        self.table = QTableWidget(0, 3)
        self.table.setObjectName("beamInteractionBreakdown")
        self.table.setHorizontalHeaderLabels(("Interaction", "Source (%)", "Current (pA)"))
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().hide()
        self.table.setMinimumHeight(250)
        self.table.setMaximumHeight(360)
        self.table.setWordWrap(True)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for column in (1, 2):
            self.table.horizontalHeader().setSectionResizeMode(column, QHeaderView.ResizeMode.ResizeToContents)
        self.table.hide()
        self.view_label = QLabel("View")
        self.view_label.setWordWrap(True)
        self.view_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
            | Qt.TextInteractionFlag.TextSelectableByKeyboard
        )
        controls = QHBoxLayout()
        controls.addWidget(self.view_label)
        controls.addWidget(self.mode_combo, 1)
        colours = QHBoxLayout()
        self.colour_label = QLabel("Colour by")
        colours.addWidget(self.colour_label)
        colours.addWidget(self.colour_combo, 1)
        layout = owner.section_beam_panel.layout()
        layout.insertLayout(1, controls)
        layout.insertLayout(2, colours)
        layout.insertWidget(4, self.table)
        layout.insertWidget(5, self.legend)
        layout.insertWidget(6, self.readout)
        self._create_spot_controls(layout)
        self.mode_combo.currentIndexChanged.connect(self._mode_changed)
        self.colour_combo.currentIndexChanged.connect(self._colour_changed)
        self.tracking_combo.currentIndexChanged.connect(self._tracking_changed)
        owner.plot.scene().sigMouseMoved.connect(self._mouse_moved)
        self._resize_timer = QTimer(self)
        self._resize_timer.setSingleShot(True)
        self._resize_timer.timeout.connect(self._refresh_view_geometry)
        owner.plot.getViewBox().sigResized.connect(self._queue_geometry_refresh)
        self._update_controls()

    def _create_spot_controls(self, layout):
        self.display_controls = QWidget()
        row = QHBoxLayout(self.display_controls)
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(QLabel("Display"))
        self.display_combo = WheelSafeComboBox()
        self.display_combo.setObjectName("beamSectionDisplay")
        self.display_combo.addItem("Particles", "particles")
        self.display_combo.addItem("Spot", "spot")
        self.display_combo.setPlaceholderText("Diagnostic view")
        self.display_combo.setToolTip(
            "Particles show sampled trajectories. Spot shows the weighted spatial flux "
            "of all rays reaching this plane. Neither option changes propagation."
        )
        row.addWidget(self.display_combo, 1)
        self.spot_controls = QWidget()
        rows = QVBoxLayout(self.spot_controls)
        rows.setContentsMargins(0, 0, 0, 0)
        grid_row = QHBoxLayout()
        grid_row.addWidget(QLabel("Grid"))
        self.spot_grid_combo = WheelSafeComboBox()
        self.spot_grid_combo.setObjectName("beamSpotGrid")
        for bins in (32, 64, 128, 256, 512):
            self.spot_grid_combo.addItem(f"{bins} × {bins}", bins)
        self.spot_grid_combo.setCurrentIndex(self.spot_grid_combo.findData(128))
        self.spot_grid_combo.setToolTip(
            "Display grid only. Subpixel deposition conserves source weights; increasing "
            "the grid does not create more particles or improve transport sampling."
        )
        grid_row.addWidget(self.spot_grid_combo, 1)
        grid_row.addWidget(QLabel("Display smoothing"))
        self.spot_smoothing_combo = WheelSafeComboBox()
        self.spot_smoothing_combo.setObjectName("beamSpotSmoothing")
        for label, sigma in (("Off", 0.), ("0.5 px", .5), ("1 px", 1.), ("2 px", 2.), ("3 px", 3.)):
            self.spot_smoothing_combo.addItem(label, sigma)
        self.spot_smoothing_combo.setToolTip(
            "Optional Gaussian display kernel, in grid pixels. Raw deposition, total flux "
            "and centroid remain unchanged. This is not a detector PSF or coherent diffraction. "
            "Smoothing outside the visible field is cropped, never renormalised."
        )
        grid_row.addWidget(self.spot_smoothing_combo, 1)
        rows.addLayout(grid_row)
        colour_row = QHBoxLayout()
        self.spot_fixed_colour = QCheckBox("Fixed colour scale")
        self.spot_fixed_colour.setObjectName("beamSpotFixedColour")
        self.spot_fixed_colour.setChecked(True)
        self.spot_fixed_colour.setToolTip(
            "Retain the first nonzero density maximum across planes, parameters and grids. "
            "Separate scales are retained for current density and source-fraction density."
        )
        self.spot_rescale = QPushButton("Use current maximum")
        self.spot_rescale.setObjectName("beamSpotRescale")
        self.spot_rescale.setToolTip("Replace the fixed colour maximum with the current spot maximum.")
        colour_row.addWidget(self.spot_fixed_colour)
        colour_row.addWidget(self.spot_rescale, 1)
        rows.addLayout(colour_row)
        layout.insertWidget(1, self.display_controls)
        layout.insertWidget(2, self.spot_controls)
        self.display_combo.currentIndexChanged.connect(self._display_changed)
        self.spot_grid_combo.currentIndexChanged.connect(self._spot_settings_changed)
        self.spot_smoothing_combo.currentIndexChanged.connect(self._spot_settings_changed)
        self.spot_fixed_colour.toggled.connect(self._spot_lock_changed)
        self.spot_rescale.clicked.connect(self._spot_use_current_maximum)

    def set_wave_visibility(self, active):
        """Wave observations have their own observables and display controls."""
        self.display_controls.setVisible(not active)
        self.spot_controls.setVisible(not active and self.mode == "intensity")

    @Slot()
    def _display_changed(self):
        if self.wave is not None:
            return
        selected = self.display_combo.currentData()
        if selected not in {"particles", "spot"}:
            return
        if selected == "spot":
            if self.mode in self.POINT_MODES:
                self._particle_mode = self.mode
            target = "intensity"
        else:
            target = self._particle_mode
        if target == self.mode:
            return
        # The quick switch compares the same spatial field; diagnostic modes
        # continue to retain their own independent ranges.
        if {target, self.mode} == {"position", "intensity"}:
            bounds = self.owner.plot.viewRange()
            self._ranges["intensity"] = bounds
            self.owner._view_ranges = tuple(tuple(axis) for axis in bounds)
            self.owner._view_scale_initialized = True
        self.mode_combo.setCurrentIndex(self.mode_combo.findData(target))

    @Slot()
    def _spot_settings_changed(self):
        if self.wave is None and self.mode == "intensity":
            self.redraw()

    @Slot()
    def _spot_lock_changed(self):
        if self.spot_fixed_colour.isChecked():
            # Turning the lock on is an explicit capture of the current image.
            if self._spot_colour_unit and self._spot_current_maximum is not None:
                if self._spot_current_maximum > 0:
                    self._spot_scale_by_unit[self._spot_colour_unit] = self._spot_current_maximum
                else:
                    self._spot_scale_by_unit.pop(self._spot_colour_unit, None)
        self._spot_settings_changed()

    @Slot()
    def _spot_use_current_maximum(self):
        if self._spot_colour_unit and self._spot_current_maximum is not None:
            if self._spot_current_maximum > 0:
                self._spot_scale_by_unit[self._spot_colour_unit] = self._spot_current_maximum
            else:
                self._spot_scale_by_unit.pop(self._spot_colour_unit, None)
        self._spot_settings_changed()

    @Slot()
    def _queue_geometry_refresh(self, *_args):
        if (self.wave is None and not self._drawing and self.mode == "intensity"
                and self.owner.isVisible()):
            self._resize_timer.start(0)

    @Slot()
    def _refresh_view_geometry(self):
        # The classical mode and result remain cached while a wave owns this
        # canvas. A queued resize must not restore Spot or replace its range.
        if (self.wave is None and self.mode == "intensity"
                and self.owner._result is not None and self.owner.isVisible()):
            # An equal-aspect plot can acquire a wider field when its panel
            # is resized. Rebin that visible field using the same plane cache.
            self._ranges[self.mode] = self.owner.plot.viewRange()
            self.redraw()

    def invalidate(self):
        self.tof.invalidate()
        self._cache_key = None
        self._cache = None
        self._filter_cache = None
        self._filter_cache_key = None
        self._source_data = None
        self._source_has_positions = False
        self._source_brush_cache.clear()
        self._source_plot_key = None
        self._spot_cache_key = None
        self._spot_raster = None

    def source_data(self):
        """One immutable launch lookup per publication, independent of Z."""
        if self._source_data is None and self.owner._result is not None:
            self._source_data = EmissionSourceData.from_simulation(self.owner._result.simulation)
            self._source_has_positions = bool(np.any(np.all(np.isfinite(self._source_data.position_m), axis=1)))
        return self._source_data

    @Slot()
    def _tracking_changed(self):
        key = self.tracking_combo.currentData()
        if key == "advanced":
            self._advanced = True
            self._update_controls(advanced=True)
            return
        self._advanced = False
        _label, mode, colour = self.TRACKING_PRESETS[key]
        self._particle_mode = mode
        if self.mode == "intensity":
            mode = "intensity"
        for combo in (self.mode_combo, self.colour_combo):
            combo.blockSignals(True)
        self.mode_combo.setCurrentIndex(self.mode_combo.findData(mode))
        self.colour_combo.setCurrentIndex(self.colour_combo.findData(colour))
        for combo in (self.mode_combo, self.colour_combo):
            combo.blockSignals(False)
        self._mode_changed()

    def set_colour_quantity(self, quantity):
        """Apply a Ray Diagram choice through the same plot controls."""
        if self.wave is not None or self.colour_combo.currentData() == quantity:
            return
        if quantity in self.TRACKING_PRESETS:
            self.tracking_combo.setCurrentIndex(self.tracking_combo.findData(quantity))
        else:
            self._advanced = True
            self.colour_combo.setCurrentIndex(self.colour_combo.findData(quantity))

    def refresh_source_plot(self):
        """Draw actual launch positions, never downstream survivors or a colour wheel."""
        colour = self.colour_combo.currentData()
        if self.mode not in self.POINT_MODES | {"intensity"} or colour not in {"source", "emission_direction", "emission_angle"}:
            return
        data = self.source_data()
        key = (id(data), colour, self.owner._projection_angle_deg)
        if key == self._source_plot_key:
            return
        self._source_plot_key = key
        if data is None or not self._source_has_positions:
            self.owner.source_plot.clear("Original emission positions are unavailable in this result.")
            self.owner.source_plot.summary.setToolTip(data.status if data is not None else "No result")
            return
        selected = data.display_indices(self.owner.MAX_DISPLAY_RAYS)
        self.owner.source_plot.set_projection_angle(self.owner._projection_angle_deg)
        self.owner.source_plot.set_source(
            ids=data.source_ids[selected], position_m=data.position_m[selected],
            brushes=self.source_brushes(data.source_ids[selected]),
            azimuth_rad=data.direction_azimuth_rad[selected],
            angle_to_normal_rad=data.angle_to_normal_rad[selected],
            status=(f"of {len(data.source_ids):,} emitted. " +
                ("Colour: launch azimuth (0–360°). " if colour == "emission_direction" else
                 "Colour: angle to local normal (0–90°). " if colour == "emission_angle" else
                 "Colour: source-position azimuth (0–360°). ")),
        )
        self.owner.source_plot.summary.setToolTip(
            "All source samples remain eligible, including those later blocked. "
            "Grey means the selected launch quantity is undefined or unavailable. "
            + ("Colour shows the launch angle to the local normal. " if colour == "emission_angle" else
               "Hue encodes original azimuth only. Hover shows the launch angle to the local normal. ") +
            "The lower coordinates describe the selected plane, with the same original emission colours. "
            "Coincident emission positions are retained without artificial offsets. " + data.status)

    def _plane_key(self):
        return (id(self.owner._result), self.owner._plane_z_mm, self.owner._focused_component_key)

    def filter_plane_data(self):
        """Resolve named physical crossings independently of observable choice."""
        key = self._plane_key()
        if key != self._filter_cache_key:
            self._filter_cache = (sample_filter_plane(
                self.owner._result, self.owner._plane_z_mm, self.owner._focused_component_key)
                if self.owner._result is not None and self.owner._plane_z_mm is not None else None)
            self._filter_cache_key = key
        return self._filter_cache

    def plane_data(self):
        key = self._plane_key()
        if key != self._cache_key:
            filtered = self.filter_plane_data()
            self._cache = (sample_beam_plane(self.owner._result, self.owner._plane_z_mm)
                           if filtered is None else filtered)
            self._cache_key = key
        return self._cache

    @Slot()
    def _mode_changed(self):
        if self.wave is not None:
            self.wave.selection_changed()
            return
        if self.mode != "position" and self.mode != "interactions":
            self._ranges[self.mode] = self.owner.plot.viewRange()
        self.mode = self.mode_combo.currentData()
        self._hover_payload = None
        self.readout.clear()
        self.owner.plot.setAspectLocked(self.mode in self.EQUAL_UNIT_MODES, ratio=1.0)
        self._update_controls()
        if self.mode == "position":
            self.owner._update_projection_labels()
        self.owner._redraw()

    @Slot()
    def _colour_changed(self):
        if self.wave is not None:
            self.wave.selection_changed()
            return
        self._update_controls()
        self.owner._redraw()

    def _update_controls(self, *, advanced=False):
        points = self.mode in self.POINT_MODES
        colour = self.colour_combo.currentData()
        preset = next((key for key, (_label, mode, quantity) in self.TRACKING_PRESETS.items()
                       if (self.mode, colour) == (mode, quantity)
                       or self.mode == "intensity" and colour == quantity), None)
        advanced = advanced or self._advanced or preset is None
        self._advanced = advanced
        self.tracking_combo.blockSignals(True)
        self.tracking_combo.setCurrentIndex(self.tracking_combo.findData("advanced" if advanced else preset))
        self.tracking_combo.blockSignals(False)
        self.mode_combo.setVisible(advanced)
        self.display_combo.blockSignals(True)
        self.display_combo.setCurrentIndex(self.display_combo.findData(
            "spot" if self.mode == "intensity" else "particles" if points else None))
        self.display_combo.blockSignals(False)
        self.set_wave_visibility(self.wave is not None)
        self.view_label.setText("Diagnostic view" if advanced else
                               f"Selected plane: {self.mode_combo.currentText()}")
        self.colour_combo.setVisible(points and advanced)
        self.colour_label.setVisible(points and advanced)
        self.owner.initial_beam_panel.show()
        source_visible = (points and colour in {"source", "emission_direction", "emission_angle", "tof"}
                          or self.mode == "intensity" and colour in {"source", "emission_direction", "emission_angle"})
        self.owner.source_plot.setVisible(source_visible)
        self.owner.initial_beam_heading.setVisible(source_visible)
        wheel_visible = source_visible and colour not in {"emission_angle", "tof"}
        self.owner.colour_legend_toggle.setVisible(wheel_visible)
        self.owner.angle_colour_wheel.setVisible(wheel_visible and self.owner.colour_legend_toggle.isChecked())
        self.owner.initial_beam_heading.setText(
            "Emission positions · arrival time at selected plane" if colour == "tof" else
            "Emission direction colour · actual source positions" if colour == "emission_direction" else
            "Emission angle to normal · actual source positions" if colour == "emission_angle" else
            "Source position colour · actual source positions")
        self.owner.angle_colour_wheel.set_colour_quantity(colour)
        if colour != self._published_colour:
            self._published_colour = colour
            self.owner.colour_quantity_changed.emit(colour)
        self.owner.plot.setVisible(self.mode != "interactions")
        self.table.setVisible(self.mode == "interactions")
        self.owner.fit_beam.setEnabled(self.mode != "interactions")
        self.owner.fit_beam.setToolTip(
            "Fit this view to all cached reaching rays. Other view ranges are retained."
        )
        self.legend.clear()
        self.readout.clear()
        self.legend.setVisible(colour in {"interaction", "emission_angle", "tof"} or not points)
        if colour == "emission_angle" and points:
            self._emission_angle_legend()
        self.readout.setVisible(self.mode in {"intensity", "angle_histogram"} or colour == "tof")

    def update_labels(self, data=None):
        u = projection_axis_name(self.owner._projection_angle_deg)
        v = orthogonal_axis_name(self.owner._projection_angle_deg)
        local = data is not None and data.coordinate_frame == "sector_exit_local"
        if local:
            u = "Dispersive U (rotated)" if self.owner._projection_angle_deg else "Dispersive"
            v = "Non-dispersive V (rotated)" if self.owner._projection_angle_deg else "Non-dispersive"
        if self.mode == "position":
            labels = ((f"{u} displacement", "µm"), (f"{v} displacement", "µm"))
        elif self.mode == "angular":
            labels = ((f"θ {u}", "mrad"), (f"θ {v}", "mrad"))
        elif self.mode in {"phase_u", "phase_v"}:
            axis = u if self.mode == "phase_u" else v
            labels = ((f"{axis} displacement", "µm"), (f"θ {axis}", "mrad"))
        elif self.mode == "intensity":
            labels = ((f"{u} displacement", "µm"), (f"{v} displacement", "µm"))
        else:
            labels = (("Polar angle to outgoing axis" if local else "Polar angle to +Z", "mrad"),
                      ("Flux per bin", ""))
        for axis, (text, unit) in zip(("bottom", "left"), labels):
            self.owner.plot.getAxis(axis).enableAutoSIPrefix(False)
            self.owner.plot.getAxis(axis).setLabel(text, units=unit, siPrefixEnableRanges=())
        self.owner.plot.setToolTip(
            "Executed crossing in the filter exit frame: dispersive/non-dispersive coordinates. "
            "Angles are atan of slopes along the outgoing axis, not global +Z. "
            "The selected rotation is within this local transverse plane. "
            "Incident rays at this plane, before detector response." if local else
            "U/V follow the Ray Diagram projection. Angles are atan of the "
            "projected ray slopes relative to +Z; polar angle is atan(hypot(tx, ty)). "
            "Geometric ray transport, not a diffraction pattern or detector image."
        )

    def finish_position(self, styles):
        """Add interaction symbols without changing existing XY sampling."""
        self._hover_payload = None
        self._annotate_emission(self.owner._display_source_ids)
        if self.colour_combo.currentData() in {"emission_direction", "emission_angle"}:
            self.owner.summary.setToolTip(
                "Colours follow original tip emission, not the current propagation angle. "
                "Extraction, focusing and scattering preserve this label. Grey: launch data unavailable.")
            if self.colour_combo.currentData() == "emission_angle":
                self._emission_angle_legend()
            return
        if self.colour_combo.currentData() != "interaction":
            self.legend.clear()
            return
        scatter = self.owner._scatter
        if scatter is not None and styles:
            scatter.setBrush([pg.mkBrush(*row[2]) for row in styles])
            scatter.setSymbol([row[3] for row in styles])
            scatter.setSize(8)
        self.owner.summary.setToolTip(
            "Colours and symbols identify recorded interaction channels; "
            "focusing does not reset them. Hover over a point for source lineage. "
            "The displayed point count is not a weighted intensity."
        )
        self._interaction_legend(styles)

    def _emission_angle_legend(self):
        self.legend.setText('0° <span style="color:#440154">■</span> · angle to normal · '
                            '<span style="color:#fde725">■</span> 90°')
        self.legend.setToolTip("Fixed 0–90 degree scale at emission; not rescaled to surviving rays. Grey: unavailable.")

    def source_brushes(self, ids, source_azimuth=None):
        mode = self.colour_combo.currentData()
        if mode == "interaction":
            mode = "source"  # Replaced by recorded interaction style after drawing.
        data = self.source_data()
        # Preserve historical lower-plane colours when original launch data are
        # absent. The upper panel never substitutes those later coordinates.
        angles = (source_azimuth if mode == "source" and source_azimuth is not None
                  and not self._source_has_positions else
                  data.values(ids, mode) if data is not None else np.full(len(ids), np.nan))
        result = []
        for ray_id, angle in zip(ids, angles):
            key = (mode, float(angle) if ray_id >= 0 and np.isfinite(angle) else None)
            cached = self._source_brush_cache.get(key)
            if cached is not None:
                result.append(cached)
                continue
            colour = emission_colour(mode, float(angle), int(ray_id))
            brush = pg.mkBrush(colour)
            self._source_brush_cache[key] = brush
            result.append(brush)
        return result

    def _annotate_emission(self, ids):
        """Keep detailed launch values in hover text, not another text box."""
        scatter = self.owner._scatter
        if scatter is None or self.owner._result is None:
            return
        data = self.source_data()
        azimuth = data.values(ids, "emission_direction")
        polar = data.values(ids, "emission_angle")
        for spot, phi, theta in zip(scatter.points(), azimuth, polar):
            if np.isfinite(theta) or np.isfinite(phi):
                phi_text = f"{math.degrees(phi):.5g}°" if np.isfinite(phi) else "undefined/unavailable"
                theta_text = f"{math.degrees(theta):.5g}°" if np.isfinite(theta) else "unavailable"
                spot.setData({**spot.data(), "emission":
                    f"Launch azimuth {phi_text} | angle to local normal {theta_text}"})

    def _interaction_legend(self, styles):
        unique = {row[0]: row for row in styles}
        symbols = {"o": "●", "t": "▲", "d": "◆", "star": "★", "x": "×"}
        shown = list(unique.values())[:4]
        compact = " · ".join(
            f'<span style="color:rgb{tuple(map(int, rgb))}">{symbols.get(symbol, "●")}</span> {escape(label)}'
            for _key, label, rgb, symbol in shown
        )
        if len(unique) > len(shown):
            compact += f" · +{len(unique)-len(shown)} more (hover)"
        self.legend.setText(compact)
        self.legend.setToolTip(
            "\n".join(row[1] for row in unique.values())
            + "\nCategories come from recorded model channels, not final focus or angle. "
            "Mixed elastic + inelastic groups use the existing independent-channel "
            "coupling approximation. They do not identify unmodelled channeling events."
        )

    def capture_manual_range(self):
        if self._drawing or self.mode == "interactions":
            return
        bounds = self.owner.plot.viewRange()
        if self.mode in self.CENTRED_MODES:
            bounds = [(-abs(high-low)/2, abs(high-low)/2) for low, high in bounds]
        self._ranges[self.mode] = bounds
        self.redraw()

    def fit(self):
        self._ranges.pop(self.mode, None)
        self.redraw()

    def _set_ranges(self, bounds):
        self.owner.plot.setRange(xRange=bounds[0], yRange=bounds[1], padding=0, disableAutoRange=True)
        self._ranges[self.mode] = self.owner.plot.viewRange()

    @staticmethod
    def _point_bounds(x, y):
        def half(values):
            finite = np.asarray(values)[np.isfinite(values)]
            value = float(np.max(np.abs(finite))) * 1.08 if finite.size else 1.0
            return value if value > 1e-9 else 1.0
        return [(-half(x), half(x)), (-half(y), half(y))]

    @staticmethod
    def _flux_units(data):
        if data.source_current_pa is not None:
            return data.source_current_pa, "pA / bin"
        return 100.0, "% source / bin"

    def _summary(self, data, extra=""):
        fraction = data.total_source_fraction
        total = "Flux unavailable" if fraction is None else f"{100*fraction:.6g}% of source"
        if data.current_pa is not None:
            total += f" | {data.current_pa:.6g} pA"
        self.owner.summary.setText(f"{data.provenance} | {total}" + extra)
        self.owner.summary.setToolTip(
            "Uses all weighted rays crossing this plane, including an exact interception plane. "
            "This is incident flux at the plane before its detector response, not detected counts "
            "or coherent TEM/STEM image intensity. " + " ".join(data.diagnostics)
        )

    def redraw(self):
        owner = self.owner
        self._drawing = True
        self._spot_current_maximum = None
        self.spot_rescale.setEnabled(False)
        data = None
        try:
            owner.plot.clear()
            owner._scatter = None
            owner._point_spread_image = owner._point_spread_response = None
            owner._fit_coordinates = None
            owner._display_source_ids = np.empty(0, dtype=np.int64)
            self._hover_payload = None
            self.legend.clear()
            self.readout.clear()
            self.table.setRowCount(0)
            self.update_labels()
            label = dict((key, name) for name, key in self.MODES)[self.mode]
            if owner._result is None or owner._plane_z_mm is None:
                self._spot_raster = None
                self._spot_cache_key = None
                owner.heading.setText(label)
                owner.summary.setText("No cached beam result")
                return
            owner.heading.setText(f"{label} | Z {owner._plane_z_mm:.6g} mm")
            data = self.plane_data()
            self.update_labels(data)
            if data.coordinate_frame == "sector_exit_local":
                owner.heading.setText(f"{label} | Filter exit frame")
            if data.status == "Unavailable":
                self._spot_raster = None
                self._spot_cache_key = None
                self._summary(data)
                self.readout.setText(" ".join(data.diagnostics))
                self.readout.setVisible(True)
                if self.colour_combo.currentData() == "tof":
                    self.tof.draw(data)
                return
            self.readout.setVisible(self.mode in {"intensity", "angle_histogram"}
                                    or self.colour_combo.currentData() == "tof")
            if self.mode == "interactions":
                self._draw_interactions(data)
            elif self.mode in self.POINT_MODES:
                if self.colour_combo.currentData() == "tof":
                    self.tof.draw(data)
                else:
                    self._draw_points(data)
            elif self.mode == "intensity":
                self._draw_intensity(data)
            elif self.mode == "angle_histogram":
                self._draw_angles(data)
        except ValueError as exc:
            self._spot_raster = None
            self._spot_cache_key = None
            owner.summary.setText("Analysis unavailable")
            owner.summary.setToolTip(str(exc))
            self.readout.setText("Cached ray data are incomplete; hover for details.")
            self.readout.setToolTip(str(exc))
        finally:
            self._drawing = False
            self.owner.hardware.redraw(data)

    def _draw_points(self, data):
        owner = self.owner
        u, v = transverse_view_coordinates(data.x_m, data.y_m, owner._projection_angle_deg)
        tu, tv = transverse_view_coordinates(data.tx, data.ty, owner._projection_angle_deg)
        au, av = np.arctan(tu)*1e3, np.arctan(tv)*1e3
        x, y = ((u*1e6, v*1e6) if self.mode == "position" else (au, av) if self.mode == "angular" else
                (u*1e6, au) if self.mode == "phase_u" else (v*1e6, av))
        pool = np.unique(np.linspace(0, data.total_column_count-1,
            min(data.total_column_count, owner.MAX_DISPLAY_RAYS), dtype=int))
        selected = np.isin(data.column_index, pool) & np.isfinite(x) & np.isfinite(y)
        brushes, symbols = [], []
        source_brushes = (self.source_brushes(data.source_ray_id[selected], data.source_azimuth_rad[selected])
                          if self.colour_combo.currentData() != "interaction" else None)
        for display_index, index in enumerate(np.flatnonzero(selected)):
            if self.colour_combo.currentData() == "interaction":
                brushes.append(pg.mkBrush(*map(int, data.interaction_rgb[index])))
                symbols.append(str(data.interaction_symbol[index]))
            else:
                brushes.append(source_brushes[display_index]); symbols.append("o")
        owner._display_source_ids = data.source_ray_id[selected]
        axis_x = owner.plot.getAxis("bottom").labelText
        axis_y = owner.plot.getAxis("left").labelText
        xunit = "mrad" if self.mode == "angular" else "µm"
        yunit = "µm" if self.mode == "position" else "mrad"
        owner._scatter = pg.ScatterPlotItem(
            x=x[selected], y=y[selected], brush=brushes, symbol=symbols,
            size=8 if self.colour_combo.currentData() == "interaction" else 5,
            pen=pg.mkPen(None), hoverable=True,
            data=[{"source_ray_id": int(data.source_ray_id[index]),
                   "interaction": str(data.interaction_label[index])} for index in np.flatnonzero(selected)],
            tip=lambda px, py, info: f"Source {info['source_ray_id']} | {info['interaction']}\n"
                f"{axis_x} {px:.6g} {xunit} | {axis_y} {py:.6g} {yunit}"
                + ("\n"+info["emission"] if "emission" in info else ""),
        )
        self._annotate_emission(owner._display_source_ids)
        owner.plot.addItem(owner._scatter)
        owner.plot.addLine(x=0, pen=pg.mkPen("#94a3b8", width=.8))
        owner.plot.addLine(y=0, pen=pg.mkPen("#94a3b8", width=.8))
        if self.mode == "position":
            owner._fit_coordinates = (x, y)
            owner._settle_panel_layout()
            if owner._view_scale_initialized:
                owner._restore_centered_view_ranges()
            else:
                owner._fit_beam_view()
        else:
            self._set_ranges(self._ranges.get(self.mode, self._point_bounds(x, y)))
        if self.colour_combo.currentData() == "interaction":
            self._interaction_legend(list(zip(data.interaction_key, data.interaction_label,
                map(tuple, data.interaction_rgb), data.interaction_symbol)))
        elif self.colour_combo.currentData() == "emission_angle":
            self._emission_angle_legend()
        self._summary(data, f" | {np.count_nonzero(selected):,} shown")

    def _draw_intensity(self, data):
        bins = int(self.spot_grid_combo.currentData())
        sigma = float(self.spot_smoothing_combo.currentData())
        bounds = self._ranges.get(self.mode)
        if bounds is None:
            # Explicit Fit includes deposition and display-kernel support. An
            # existing viewport stays unchanged when display settings change,
            # so cropping remains visible instead of being renormalised away.
            fitted = rasterize_beam_spot(data, bins=bins,
                projection_angle_deg=self.owner._projection_angle_deg,
                smoothing_sigma_px=sigma)
            bounds = [(edges[0]*1e6, edges[-1]*1e6)
                      for edges in (fitted.x_edges_m, fitted.y_edges_m)]
        self._set_ranges(bounds)
        bounds = self._ranges[self.mode]
        range_m = tuple(tuple(value*1e-6 for value in pair) for pair in bounds)
        key = (id(data), bins, sigma, self.owner._projection_angle_deg, range_m)
        if key != self._spot_cache_key:
            self._spot_raster = rasterize_beam_spot(data, bins=bins,
                projection_angle_deg=self.owner._projection_angle_deg,
                range_m=range_m, smoothing_sigma_px=sigma)
            self._spot_cache_key = key
        raster = self._spot_raster
        xe, ye = raster.x_edges_m, raster.y_edges_m
        scale = data.source_current_pa if data.source_current_pa is not None else 100.
        unit = "pA / µm²" if data.source_current_pa is not None else "% source / µm²"
        values = raster.display_fraction * (scale / (raster.pixel_area_m2 * 1e12))
        maximum = float(np.max(values)) if values.size else 0.
        unit_changed = self._spot_colour_unit is not None and self._spot_colour_unit != unit
        self._spot_colour_unit = unit
        self._spot_current_maximum = maximum
        fixed = self.spot_fixed_colour.isChecked()
        if fixed and unit not in self._spot_scale_by_unit and maximum > 0:
            self._spot_scale_by_unit[unit] = maximum
        colour_maximum = self._spot_scale_by_unit.get(unit) if fixed else maximum
        self._spot_colour_maximum = colour_maximum
        upper = colour_maximum if colour_maximum is not None and colour_maximum > 0 else 1.
        self._spot_image.setImage(values, autoLevels=False, levels=(0, upper))
        self._spot_image.setRect(QRectF(xe[0]*1e6, ye[0]*1e6, np.ptp(xe)*1e6, np.ptp(ye)*1e6))
        self.owner.plot.addItem(self._spot_image)
        self.owner.plot.addLine(x=0, pen=pg.mkPen("#94a3b8", width=.8))
        self.owner.plot.addLine(y=0, pen=pg.mkPen("#94a3b8", width=.8))
        # Hover payload retains the shared X/Y indexing used by other analysis
        # views, while the image and immutable raster use row-major Y/X.
        self._hover_payload = ("intensity", values.T, xe*1e6, ye*1e6, unit)
        colours = ("#440154", "#3b528b", "#21918c", "#5ec962", "#fde725")
        scale_text = "fixed" if fixed else "auto"
        if fixed and colour_maximum is None:
            scale_text = "fixed · awaiting nonzero flux"
        elif unit_changed:
            scale_text += " · scale for these units"
        elif maximum > upper:
            scale_text += " · peak exceeds colour maximum"
        self.legend.setText("0 " + "".join(f'<span style="color:{colour}">■</span>' for colour in colours)
            + f" {upper:.6g} {unit} · {scale_text}")
        self.legend.setToolTip(
            "Colour shows source-weighted spatial density per square micrometre, so grid changes "
            "do not change its units. Fixed scale retains its maximum across planes and results; "
            "Use current maximum explicitly resets it. Values are never normalised to surviving rays. "
            "Optional smoothing changes this display only, not the raw raster, total flux or centroid. "
            "Viewport losses include cropped subpixel and smoothing tails; no edge reflection or renormalisation."
        )
        self.spot_rescale.setEnabled(fixed and maximum > 0)
        smoothing_text = f"display smoothing σ {sigma:g} px" if sigma else "display smoothing off"
        self.readout.setText(f"Hover for position and density | {bins} × {bins} | {smoothing_text}")
        self.readout.setToolTip("Hover reports the displayed density; the raw weighted centroid and flux are listed below.")
        if raster.centroid_m is None:
            centroid = " | centroid unavailable"
        else:
            cx, cy = raster.centroid_m
            centroid = (f" | centroid ({cx*1e6:.6g}, {cy*1e6:.6g}) µm"
                        if np.isfinite(cx) and np.isfinite(cy) else " | centroid unavailable")
        self._summary(data,
            f" | visible {raster.display_visible_fraction*100:.6g}% of source"
            f" | {raster.ray_count:,} rays (effective {raster.effective_ray_count:.6g})" + centroid)
        self.owner.summary.setToolTip(self.owner.summary.toolTip() +
            f" Hit centres inside viewport: {raster.viewport_source_fraction*100:.6g}% of source; "
            f"raw deposited visible flux: {raster.raw_visible_fraction*100:.6g}%; "
            f"displayed visible flux: {raster.display_visible_fraction*100:.6g}%. "
            "Centroid uses all reaching weighted rays, including those outside the viewport. "
            "A smooth appearance does not establish sufficient particle sampling.")
        self.refresh_source_plot()

    def _draw_angles(self, data):
        if self.mode not in self._ranges:
            hist, edges = angular_histogram(data, bins=self.BINS)
            scale, unit = self._flux_units(data)
            upper = max(float(np.max(hist))*scale*1.1, 1e-12)
            self._set_ranges(((edges[0], edges[-1]), (0., upper)))
        bounds = self._ranges[self.mode]
        hist, edges = angular_histogram(data, bins=self.BINS, range_mrad=tuple(bounds[0]))
        scale, unit = self._flux_units(data)
        values = hist*scale
        self.owner.plot.plot(edges, values, stepMode="center", fillLevel=0,
            brush=pg.mkBrush(56, 189, 248, 65), pen=pg.mkPen("#38bdf8", width=1.5))
        self.owner.plot.getAxis("left").setLabel(unit, siPrefixEnableRanges=())
        self._set_ranges(bounds)
        self._hover_payload = ("angle", values, edges, None, unit)
        self.readout.setText("Hover for angle and bin flux")
        self._summary(data, f" | visible {float(np.sum(hist))*100:.6g}% of source")

    def _draw_interactions(self, data):
        keys = list(dict.fromkeys(data.interaction_key))
        self.table.setRowCount(len(keys))
        for row, key in enumerate(keys):
            mask = data.interaction_key == key
            first = int(np.flatnonzero(mask)[0])
            label = str(data.interaction_label[first])
            fraction = float(np.sum(data.source_fraction[mask])) if data.weights_valid else None
            current = (fraction*data.source_current_pa
                if fraction is not None and data.source_current_pa is not None else None)
            for column, text in enumerate((label, "Unavailable" if fraction is None else f"{100*fraction:.6g}",
                                           "Unavailable" if current is None else f"{current:.6g}")):
                item = QTableWidgetItem(text)
                item.setToolTip(label + " | Weighted flux reaching the selected plane, not event counts.")
                if column == 0:
                    item.setForeground(QColor(*map(int, data.interaction_rgb[first])))
                self.table.setItem(row, column, item)
        self.table.resizeRowsToContents()
        self.legend.setText("All reaching weighted rays · not collision counts")
        self._summary(data)

    @Slot(object)
    def _mouse_moved(self, position):
        if self.wave is not None:
            self.wave.mouse_moved(position)
            return
        if self._hover_payload is None or not self.owner.plot.sceneBoundingRect().contains(position):
            return
        point = self.owner.plot.getViewBox().mapSceneToView(position)
        kind, values, xedges, yedges, unit = self._hover_payload
        ix = int(np.searchsorted(xedges, point.x(), side="right")-1)
        if not 0 <= ix < len(xedges)-1:
            self.readout.clear(); return
        if kind == "angle":
            self.readout.setText(f"θ {point.x():.6g} mrad | {values[ix]:.6g} {unit}")
        else:
            iy = int(np.searchsorted(yedges, point.y(), side="right")-1)
            if 0 <= iy < len(yedges)-1:
                self.readout.setText(f"U {point.x():.6g} µm | V {point.y():.6g} µm | {values[ix, iy]:.6g} {unit}")
            else:
                self.readout.clear()
