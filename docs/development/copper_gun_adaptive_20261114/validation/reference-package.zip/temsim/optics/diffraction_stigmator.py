"""Independent topology-aware Diffraction Stigmator."""

from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar

from temsim.optics.component_position import (
    InstallationReferencedPosition, STANDALONE_INSTALLATION, IMAGE_CORRECTED_INSTALLATION,
)

import numpy as np

from temsim import module_manifest
from temsim.component_keys import (
    DIFFRACTION_STIGMATOR,
    SELECTED_AREA_APERTURE,
)
from temsim.optics.model import Stigmator
from temsim.optics.selected_area_aperture import (
    SELECTED_AREA_APERTURE_DEFINITION,
)
from temsim.optics.selected_area_downstream import downstream_offset_mm


_DEFAULT_MANIFEST_PART = module_manifest.part_data(
    "project_and_recording_system/NoEnergyFilter.toml",
    DIFFRACTION_STIGMATOR,
)


@dataclass(frozen=True)
class DiffractionStigmatorGeometry:
    installation: str
    mechanical_center_below_sample_mm: float
    mechanical_length_mm: float
    mechanical_outer_diameter_mm: float
    mechanical_clear_bore_diameter_mm: float
    optical_reference_z_mm: float
    owner: str = "diffraction"


@dataclass(frozen=True)
class DiffractionStigmatorDefinition:
    key: str = DIFFRACTION_STIGMATOR
    label: str = "Diffraction Stigmator"
    anchor_key: str = SELECTED_AREA_APERTURE
    mechanical_center_downstream_of_anchor_mm: float = downstream_offset_mm(
        DIFFRACTION_STIGMATOR
    )
    optical_reference_downstream_of_anchor_mm: float = downstream_offset_mm(
        DIFFRACTION_STIGMATOR
    )
    standalone_mechanical_center_below_sample_mm: float = (
        SELECTED_AREA_APERTURE_DEFINITION
        .standalone_mechanical_center_below_sample_mm
        + downstream_offset_mm(DIFFRACTION_STIGMATOR)
    )
    image_corrected_mechanical_center_below_sample_mm: float = (
        SELECTED_AREA_APERTURE_DEFINITION
        .image_corrected_mechanical_center_below_sample_mm
        + downstream_offset_mm(DIFFRACTION_STIGMATOR)
    )
    mechanical_length_mm: float = float(
        _DEFAULT_MANIFEST_PART["length_mm"]
    )
    mechanical_outer_diameter_mm: float = float(
        _DEFAULT_MANIFEST_PART["mechanical_outer_diameter_mm"]
    )
    mechanical_clear_bore_diameter_mm: float = float(
        _DEFAULT_MANIFEST_PART["mechanical_clear_bore_diameter_mm"]
    )
    standalone_optical_reference_z_mm: float = (
        SELECTED_AREA_APERTURE_DEFINITION
        .standalone_optical_reference_z_mm
        + downstream_offset_mm(DIFFRACTION_STIGMATOR)
    )
    image_corrected_optical_reference_z_mm: float = (
        SELECTED_AREA_APERTURE_DEFINITION
        .image_corrected_optical_reference_z_mm
        + downstream_offset_mm(DIFFRACTION_STIGMATOR)
    )
    effective_length_mm: float = float(
        _DEFAULT_MANIFEST_PART["effective_length_mm"]
    )
    maximum_strength_m2: float = 300.0
    colour: str = "#fb8c00"
    owner: str = "diffraction"
    kind: str = "stigmator"
    shape_profile: str = "quadrupole_body"
    interaction_kind: str = "distributed_quadrupole_field"

    @property
    def name(self):
        return self.label

    @property
    def effective_aperture_radius_mm(self):
        return self.mechanical_clear_bore_diameter_mm / 2.0

    def geometry_for(self, installation):
        if installation not in {
            STANDALONE_INSTALLATION,
            IMAGE_CORRECTED_INSTALLATION,
        }:
            raise ValueError(
                f"Unsupported Diffraction Stigmator installation: "
                f"{installation}"
            )
        return DiffractionStigmatorGeometry(
            installation=installation,
            mechanical_center_below_sample_mm=getattr(
                self,
                f"{installation}_mechanical_center_below_sample_mm",
            ),
            mechanical_length_mm=self.mechanical_length_mm,
            mechanical_outer_diameter_mm=(
                self.mechanical_outer_diameter_mm
            ),
            mechanical_clear_bore_diameter_mm=(
                self.mechanical_clear_bore_diameter_mm
            ),
            optical_reference_z_mm=getattr(
                self, f"{installation}_optical_reference_z_mm"
            ),
        )

    def create_component(self):
        return DiffractionStigmatorComponent(
            name=self.label,
            key=self.key,
            z_mm=self.standalone_optical_reference_z_mm,
            length_mm=self.effective_length_mm,
            max_strength_m2=self.maximum_strength_m2,
            strength_x_percent=0.0,
            strength_y_percent=0.0,
            enabled=True,
            colour=self.colour,
            anchor_key=self.anchor_key,
            mechanical_center_downstream_of_anchor_mm=(
                self.mechanical_center_downstream_of_anchor_mm
            ),
            optical_reference_downstream_of_anchor_mm=(
                self.optical_reference_downstream_of_anchor_mm
            ),
            standalone_mechanical_center_below_sample_mm=(
                self.standalone_mechanical_center_below_sample_mm
            ),
            image_corrected_mechanical_center_below_sample_mm=(
                self.image_corrected_mechanical_center_below_sample_mm
            ),
            mechanical_length_mm=self.mechanical_length_mm,
            mechanical_outer_diameter_mm=(
                self.mechanical_outer_diameter_mm
            ),
            mechanical_clear_bore_diameter_mm=(
                self.mechanical_clear_bore_diameter_mm
            ),
            standalone_optical_reference_z_mm=(
                self.standalone_optical_reference_z_mm
            ),
            image_corrected_optical_reference_z_mm=(
                self.image_corrected_optical_reference_z_mm
            ),
            active_installation=STANDALONE_INSTALLATION,
            corrector=self.owner,
        )


@dataclass
class DiffractionStigmatorComponent(InstallationReferencedPosition, Stigmator):
    anchor_key: str = SELECTED_AREA_APERTURE
    mechanical_center_downstream_of_anchor_mm: float = downstream_offset_mm(
        DIFFRACTION_STIGMATOR
    )
    optical_reference_downstream_of_anchor_mm: float = downstream_offset_mm(
        DIFFRACTION_STIGMATOR
    )
    standalone_mechanical_center_below_sample_mm: float = (
        SELECTED_AREA_APERTURE_DEFINITION
        .standalone_mechanical_center_below_sample_mm
        + downstream_offset_mm(DIFFRACTION_STIGMATOR)
    )
    image_corrected_mechanical_center_below_sample_mm: float = (
        SELECTED_AREA_APERTURE_DEFINITION
        .image_corrected_mechanical_center_below_sample_mm
        + downstream_offset_mm(DIFFRACTION_STIGMATOR)
    )
    mechanical_length_mm: float = float(
        _DEFAULT_MANIFEST_PART["length_mm"]
    )
    mechanical_outer_diameter_mm: float = float(
        _DEFAULT_MANIFEST_PART["mechanical_outer_diameter_mm"]
    )
    mechanical_clear_bore_diameter_mm: float = float(
        _DEFAULT_MANIFEST_PART["mechanical_clear_bore_diameter_mm"]
    )
    standalone_optical_reference_z_mm: float = (
        SELECTED_AREA_APERTURE_DEFINITION
        .standalone_optical_reference_z_mm
        + downstream_offset_mm(DIFFRACTION_STIGMATOR)
    )
    image_corrected_optical_reference_z_mm: float = (
        SELECTED_AREA_APERTURE_DEFINITION
        .image_corrected_optical_reference_z_mm
        + downstream_offset_mm(DIFFRACTION_STIGMATOR)
    )
    active_installation: str = STANDALONE_INSTALLATION
    corrector: str = "diffraction"

    EXPECTED_KEY: ClassVar[str] = DIFFRACTION_STIGMATOR
    KIND: ClassVar[str] = "stigmator"
    SHAPE_PROFILE: ClassVar[str] = "quadrupole_body"
    INTERACTION_KIND: ClassVar[str] = "distributed_quadrupole_field"

    @property
    def owner(self):
        return self.corrector

    @property
    def kind(self):
        return self.KIND

    @property
    def shape_profile(self):
        return self.SHAPE_PROFILE

    @property
    def interaction_kind(self):
        return self.INTERACTION_KIND

    @property
    def optical_active(self):
        return bool(self.enabled)

    @property
    def effective_aperture_radius_mm(self):
        return self.mechanical_clear_bore_diameter_mm / 2.0

    @property
    def mechanical_center_below_sample_mm(self):
        return getattr(
            self,
            f"{self.active_installation}"
            "_mechanical_center_below_sample_mm",
        )

    @mechanical_center_below_sample_mm.setter
    def mechanical_center_below_sample_mm(self, value):
        setattr(
            self,
            f"{self.active_installation}"
            "_mechanical_center_below_sample_mm",
            float(value),
        )

    @property
    def optical_reference_z_mm(self):
        return getattr(
            self,
            f"{self.active_installation}_optical_reference_z_mm",
        )

    @optical_reference_z_mm.setter
    def optical_reference_z_mm(self, value):
        setattr(
            self,
            f"{self.active_installation}_optical_reference_z_mm",
            float(value),
        )

    @property
    def strength_x_m2(self):
        return (
            float(self.max_strength_m2)
            * float(self.strength_x_percent)
            / 100.0
        )

    @property
    def strength_y_m2(self):
        return (
            float(self.max_strength_m2)
            * float(self.strength_y_percent)
            / 100.0
        )

    def geometry_for(self, installation):
        if installation not in {
            STANDALONE_INSTALLATION,
            IMAGE_CORRECTED_INSTALLATION,
        }:
            raise ValueError(
                f"Unsupported Diffraction Stigmator installation: "
                f"{installation}"
            )
        return DiffractionStigmatorGeometry(
            installation=installation,
            mechanical_center_below_sample_mm=getattr(
                self,
                f"{installation}_mechanical_center_below_sample_mm",
            ),
            mechanical_length_mm=self.mechanical_length_mm,
            mechanical_outer_diameter_mm=(
                self.mechanical_outer_diameter_mm
            ),
            mechanical_clear_bore_diameter_mm=(
                self.mechanical_clear_bore_diameter_mm
            ),
            optical_reference_z_mm=getattr(
                self, f"{installation}_optical_reference_z_mm"
            ),
        )

    def validate(self):
        from temsim.optics.stigmator_field import validate_stigmator_field
        validate_stigmator_field(self)
        if self.key != self.EXPECTED_KEY:
            raise ValueError(
                "Diffraction Stigmator key is not canonical."
            )
        if self.anchor_key != SELECTED_AREA_APERTURE:
            raise ValueError(
                "Diffraction Stigmator must follow the "
                "Selected Area Aperture."
            )
        for installation in (
            STANDALONE_INSTALLATION,
            IMAGE_CORRECTED_INSTALLATION,
        ):
            if (
                self.geometry_for(
                    installation
                ).mechanical_center_below_sample_mm
                <= 0.0
            ):
                raise ValueError(
                    "Diffraction Stigmator must remain below the sample."
                )
        if self.mechanical_length_mm <= 0.0:
            raise ValueError(
                "Diffraction Stigmator mechanical length must be positive."
            )
        if not (
            0.0
            < self.mechanical_clear_bore_diameter_mm
            < self.mechanical_outer_diameter_mm
        ):
            raise ValueError(
                "Diffraction Stigmator bore must fit inside its body."
            )
        if not 0.0 < self.length_mm <= self.mechanical_length_mm:
            raise ValueError(
                "Diffraction Stigmator field length must fit its body."
            )
        if self.max_strength_m2 <= 0.0:
            raise ValueError(
                "Diffraction Stigmator maximum strength must be positive."
            )
        return self

    def quadrupole_strengths_m2(self, z_mm):
        """Diagonal entries; transport also consumes quadrupole_tensor_m2."""
        xx, yy, _ = self.quadrupole_tensor_m2(z_mm)
        return xx, yy

    def draw_layout(self):
        geometry = self.geometry_for(self.active_installation)
        return {
            "key": self.key,
            "installation": geometry.installation,
            "mechanical_center_below_sample_mm": (
                geometry.mechanical_center_below_sample_mm
            ),
            "mechanical_length_mm": geometry.mechanical_length_mm,
            "mechanical_outer_diameter_mm": (
                geometry.mechanical_outer_diameter_mm
            ),
            "mechanical_clear_bore_diameter_mm": (
                geometry.mechanical_clear_bore_diameter_mm
            ),
            "shape_profile": self.shape_profile,
        }

    def draw_ray_overlay(self):
        return {
            "key": self.key,
            "optical_reference_z_mm": self.z_mm,
            "effective_length_mm": self.length_mm,
            "strength_x_m2": self.strength_x_m2,
            "strength_y_m2": self.strength_y_m2,
            "enabled": self.enabled,
        }


DIFFRACTION_STIGMATOR_DEFINITION = DiffractionStigmatorDefinition()


def create_diffraction_stigmator():
    return DIFFRACTION_STIGMATOR_DEFINITION.create_component().validate()


def diffraction_stigmator_from_dict(
    data,
    active_installation=None,
    *, defer_geometry_validation=False,
):
    values = dict(data)
    if values.get("key") != DIFFRACTION_STIGMATOR:
        raise ValueError(f"Diffraction stigmator requires component key {DIFFRACTION_STIGMATOR!r}")
    if values.get("field_model") != "normal_skew":
        raise ValueError("Diffraction stigmator record requires field_model='normal_skew'")
    # Current instrument files store operating controls. Mechanical stations
    # come from the selected TOML module, not a missing-field migration.
    component = create_diffraction_stigmator()
    allowed = component.__dataclass_fields__
    object.__setattr__(component, "_position_coupling_ready", False)
    for attribute, value in values.items():
        if attribute in allowed:
            object.__setattr__(component, attribute, value)
    object.__setattr__(component, "_position_coupling_ready", True)
    component.key = DIFFRACTION_STIGMATOR
    component.name = "Diffraction Stigmator"
    component.anchor_key = SELECTED_AREA_APERTURE
    component.mechanical_center_downstream_of_anchor_mm = (
        downstream_offset_mm(DIFFRACTION_STIGMATOR)
    )
    component.optical_reference_downstream_of_anchor_mm = (
        downstream_offset_mm(DIFFRACTION_STIGMATOR)
    )
    component.corrector = DIFFRACTION_STIGMATOR_DEFINITION.owner
    component.select_installation(
        active_installation
        or values.get("active_installation", STANDALONE_INSTALLATION)
    )
    if defer_geometry_validation:
        from temsim.optics.stigmator_field import validate_stigmator_field
        validate_stigmator_field(component)
        return component
    return component.validate()
