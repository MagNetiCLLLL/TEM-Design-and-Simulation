"""Transactional edits at the tip; no propagation or downstream source."""
from copy import copy


def prepare_tip_model_sampling(emitter, previous, *, explicit_sampling=False, reset_default=False):
    """Switch only the default sampling plan during an explicit model edit.

    Historical planar records retain their sampling on ordinary edits. Explicit
    tables and Sobol plans remain subject to the normal mutual-exclusion checks.
    """
    from .emitter import EmissionSampling, HALTON_PREFIX_SAMPLING_SCHEMA

    if explicit_sampling:
        return
    plan = emitter.sampling
    other_model = emitter.surface_model is not None or emitter.coherence is not None
    previous_other_model = previous.surface_model is not None or previous.coherence is not None
    if other_model and (reset_default or not previous_other_model):
        if plan is not None and plan.schema == HALTON_PREFIX_SAMPLING_SCHEMA:
            emitter.sampling = None
    elif not other_model and (reset_default or previous_other_model):
        if plan is None and emitter.quadrature is None and emitter.cdf_quadrature is None:
            emitter.sampling = EmissionSampling(schema=HALTON_PREFIX_SAMPLING_SCHEMA, seed=0)


def candidate_tip_edit(gun, values):
    """Validate the entire gun before publishing a source/model change."""
    if gun.type_key != "cold_feg":
        raise ValueError("Tip emission editing requires a cold FEG")
    candidate = copy(gun)
    candidate.emitter = copy(gun.emitter)
    candidate.c1_aperture = copy(gun.c1_aperture)
    allowed = set(gun.emitter.__dataclass_fields__) | {
        "coherence", "surface_model", "curvature_nm_inv", "curvature_model",
        "sampling", "quadrature", "cdf_quadrature"}
    if set(values) - allowed:
        raise ValueError("Only tip emission inputs may be edited here")
    for name, value in values.items():
        setattr(candidate.emitter, name, value)
    prepare_tip_model_sampling(candidate.emitter, gun.emitter, explicit_sampling="sampling" in values)
    candidate.source_representation = "classical_particles"
    candidate._trace_cache = candidate._trace_cache_key = None
    candidate.validate()
    if candidate.emitter.surface_model is None and candidate.emitter.coherence is not None:
        # Apply the same existing particle-domain admission to every editing
        # entry point. Defining a complex boundary alone does not admit its
        # Wigner/geometric representation as forward physical particles.
        from temsim.optics.electron_gun.tip_coherence import tip_covariance
        from temsim.optics.electron_gun.tip_source_domain import validate_tip_particle_domain
        tip_covariance(candidate.emitter, candidate.emitter.emission_energy_ev)
        validate_tip_particle_domain(candidate.emitter)
    return candidate


def tip_model_label(gun):
    model = getattr(gun.emitter, "surface_model", None)
    if model is not None:
        return ("Curved tip · emitting apex cap "
                f"{model.emission.cap_half_angle_deg:g}° · {model.current_na:g} nA")
    k = getattr(gun.emitter, "curvature_nm_inv", 0.0)
    geometry = f"Curved tip · curvature {k:g} nm^-1 · R {1/k:g} nm" if k else "Flat tip · curvature 0"
    scope = "centre Z = 0; edges bend upstream"
    field = ("coupled electrode field" if gun.uses_geometry_electric_field
             else "analytic gun field")
    source = " · Gaussian-Schell emission" if gun.emitter.coherence is not None else ""
    return f"{geometry} · {scope} · {field} · {gun.emitted_current_a*1e9:g} nA{source}"
