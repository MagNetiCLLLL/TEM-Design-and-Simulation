"""Native two-axis steering windings, independent of optical field strength.

The four closed saddle-loop envelopes are an explicitly approximate mechanical
reconstruction. They are not a winding diagram or CAD model of a CEOS product.
Coordinates are module-local millimetres, matching the other part meshes.
"""

from dataclasses import replace
import math
from numbers import Real

import numpy as np
from temsim.mechanical_profiles import DEFLECTOR_COIL_INSERT, DEFLECTOR_COIL_PROFILES


PROFILE = DEFLECTOR_COIL_INSERT
WINDING_DIMENSIONS = ("winding_layer_thickness_mm", "winding_angular_span_deg", "winding_band_width_mm")
DESCRIPTION = (
    "Generic two-axis winding reconstruction; not OEM winding/CAD; "
    "field strength from linked DPH/DP channel, not mesh."
)


def winding_axial_extent(part):
    """Copper extent inside its allocated field/installation envelope, in mm.

    An effective finite field need not end at the copper ends. An explicitly
    shorter winding therefore changes only material geometry, never the
    channel's effective_thickness_mm or axial field support.
    """
    start, end = (float(part[name]) for name in ("local_start_z_mm", "local_end_z_mm"))
    value = part.get("winding_axial_length_mm", end - start)
    if (isinstance(value, bool) or not isinstance(value, Real)
            or not math.isfinite(value) or not 0.0 < value <= end - start + 1e-9):
        raise ValueError(f"{part.get('key', 'winding')}: copper length must fit its allocated axial envelope")
    centre = (start + end) / 2.0
    return centre - float(value) / 2.0, centre + float(value) / 2.0


def winding_dimensions(part):
    """Validate native dimensions; only the old profile supplies legacy defaults.

    The return value is (radial layer thickness, full angular span, band width).
    All linear dimensions use mm, like the normal component editor. These are
    reconstruction dimensions, not a current/field or manufacturer calibration.
    """
    key = str(part.get("key", "winding"))
    if part.get("mechanical_profile") not in DEFLECTOR_COIL_PROFILES:
        raise ValueError(f"{key}: unsupported winding profile")

    def number(field, fallback=None):
        value = part.get(field, fallback)
        if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value):
            raise ValueError(f"{key}.{field} must be a finite number")
        return float(value)

    inner = number("mechanical_inner_diameter_mm") / 2.0
    outer = number("mechanical_outer_diameter_mm") / 2.0
    start, end = winding_axial_extent(part)
    length = end - start
    if not (0.0 < inner < outer and length > 0.0):
        raise ValueError(f"{key}: windings require an open bore and positive radial/axial thickness")
    legacy = part.get("mechanical_profile") != PROFILE
    layer = number(WINDING_DIMENSIONS[0], 0.4 * (outer - inner) if legacy else None)
    span = number(WINDING_DIMENSIONS[1], 120.0 if legacy else None)
    band = number(WINDING_DIMENSIONS[2], min(0.08 * length, 0.2 * inner) if legacy else None)
    if not 0.0 < layer < (outer - inner) / 2.0:
        raise ValueError(f"{key}: winding layer thickness must leave separation between both radial layers")
    if not 0.0 < span < 180.0:
        raise ValueError(f"{key}: winding angular span must be between 0 and 180 degrees")
    if not 0.0 < band < min(length / 2.0, math.radians(span / 2.0) * (inner + layer / 2.0)):
        raise ValueError(f"{key}: winding band width must leave an open axial and angular window")
    return layer, span, band


def validate_deflector_coil_part(part):
    # A replacement base owns its geometry. Retain the native recipe for an
    # eventual restore, but do not constrain that base with inactive windings.
    if part.get("model_3d", {}).get("base", {}).get("kind", "existing") != "existing":
        return
    if part.get("mechanical_profile") in DEFLECTOR_COIL_PROFILES:
        winding_dimensions(part)
    from temsim.deflector_support_geometry import deflector_support_dimensions
    deflector_support_dimensions(part)


def _saddle_loop(*, key, region, inner, outer, start, end, angle, count, color,
                 half_angle, band):
    """Extrude a rectangular frame in cylindrical coordinates into one solid.

    Long sides follow the axis and the end bands follow circular arcs. Shared
    faces are removed so the loop has a single closed, consistently wound
    surface, including its open central window.
    """
    from temsim.part_model_3d import _mesh

    window_half_angle = half_angle - band / ((inner + outer) / 2.0)
    # Polygonal inner arcs must also stay outside the declared inner radius.
    # Bound their chord sagitta before placing the inner vertices outward.
    sagitta = 0.25 * (outer - inner)
    maximum_step = 4.0 * math.asin(math.sqrt(sagitta / (2.0 * (inner + sagitta))))
    requested_intervals = max(32, math.ceil(count * half_angle / math.pi))
    maximum_step = min(maximum_step, 2.0 * half_angle / requested_intervals)
    # Subdivide both solid side bands as well as the open middle window. A
    # single wide side-band chord otherwise determines the radial correction
    # at every vertex, thinning or eliminating an otherwise valid winding.
    side_intervals = max(1, math.ceil((half_angle - window_half_angle) / maximum_step))
    window_intervals = max(1, math.ceil(2.0 * window_half_angle / maximum_step))
    if 2 * side_intervals + window_intervals > 4096:
        raise ValueError(f"{key}: winding radial thickness is too small to mesh")
    angles = np.r_[np.linspace(-half_angle, -window_half_angle, side_intervals + 1)[:-1],
                   np.linspace(-window_half_angle, window_half_angle, window_intervals + 1)[:-1],
                   np.linspace(window_half_angle, half_angle, side_intervals + 1)] + angle
    step = float(np.diff(angles).max())
    inner_vertex_radius = inner / math.cos(step / 2.0)
    if not inner_vertex_radius < outer:
        raise ValueError(f"{key}: winding bands cannot fit their radial envelope")
    radial = (inner_vertex_radius, outer)
    axial = (start, start + band, end - band, end)
    vertices, lookup, boundary = [], {}, {}

    def vertex(index):
        if index not in lookup:
            r, t, z = index
            lookup[index] = len(vertices)
            vertices.append((radial[r] * math.cos(angles[t]),
                             radial[r] * math.sin(angles[t]), axial[z]))
        return lookup[index]

    # Outward vertex order for each face of a (r, theta, z) cell.
    sides = (
        ((0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0)),
        ((1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1)),
        ((0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1)),
        ((0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0)),
        ((0, 0, 0), (0, 1, 0), (1, 1, 0), (1, 0, 0)),
        ((0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)),
    )
    for t in range(len(angles) - 1):
        for z in range(3):
            if z == 1 and side_intervals <= t < side_intervals + window_intervals:
                continue
            for side in sides:
                quad = tuple(vertex((r, t + dt, z + dz)) for r, dt, dz in side)
                identity = tuple(sorted(quad))
                if identity in boundary:
                    del boundary[identity]
                else:
                    boundary[identity] = quad
    faces = [(a, b, c) for a, b, c, _ in boundary.values()]
    faces += [(a, c, d) for a, _, c, d in boundary.values()]
    mesh = _mesh(vertices, faces, key, region, "copper_winding", False, DESCRIPTION)
    return replace(mesh, color=color)


def _conductor_gap_mesh(spec, copper_meshes, count):
    """Subtract the displayed copper tessellation without rebuilding that copper.

    STEP subtracts the analytic winding solids; here the same material boundary
    follows the existing native saddle tessellation exactly. Independent angular
    grids would otherwise leave thin insulation/copper interpenetrations.
    """
    import manifold3d as m
    from temsim.cad_mesh import _manifold
    from temsim.part_model_3d import _mesh

    solid = _manifold(spec.shape["base"], count)
    regions = set(spec.parameters["subtracted_winding_regions"])
    for mesh in copper_meshes:
        if mesh.region in regions:
            solid -= m.Manifold(m.Mesh64(mesh.vertices.copy(), mesh.faces.astype(np.uint64)))
    if solid.status() != m.Error.NoError or solid.is_empty() or solid.volume() <= 0:
        raise ValueError(f"{spec.key}/{spec.region}: invalid conductor-gap insulation mesh")
    raw = solid.to_mesh64()
    result = _mesh(np.asarray(raw.vert_properties)[:, :3], np.asarray(raw.tri_verts),
                   spec.key, spec.region, spec.material, False, spec.note)
    return replace(result, color=spec.color)


def deflector_coil_meshes(part, angular_segments=32, *, drive_key=None):
    """Return two orthogonal pairs within the declared annular envelope.

    The material bore and axial extent come from the part. The subdivision into
    two winding layers is a display construction, never an excitation model.
    """
    from temsim.part_model_3d import _extent, _number, _segments
    from temsim.deflector_support_geometry import (
        GAP_REGIONS, annotate_support_mesh, deflector_support_solids, full_material_axial_extent,
        support_mesh_segments,
    )

    key = str(part["key"])
    layer, span, band = winding_dimensions(part)
    support_solids = deflector_support_solids(part)
    count = _segments(angular_segments)
    start, end = winding_axial_extent(part)
    inner = _number(part["mechanical_inner_diameter_mm"], "mechanical_inner_diameter_mm") / 2.0
    outer = _number(part["mechanical_outer_diameter_mm"], "mechanical_outer_diameter_mm") / 2.0
    if not (0.0 < inner < outer and end > start):
        raise ValueError(f"{key}: windings require an open bore and positive radial/axial thickness")
    layers = ((inner, inner + layer), (outer - layer, outer))
    colors = ((0.94, 0.46, 0.18, 1.0), (0.24, 0.70, 0.87, 1.0))
    meshes = []
    for axis, (lower, upper) in enumerate(layers):
        # Old files chose this proportion separately for each radial layer.
        # Explicit native dimensions instead define the same material band on
        # both axes, and never change silently when another dimension is edited.
        layer_band = (min(0.08 * (end - start), 0.2 * lower)
                      if part.get("mechanical_profile") != PROFILE
                      and "winding_band_width_mm" not in part else band)
        for side in range(2):
            meshes.append(_saddle_loop(
                key=key, region=f"{'xy'[axis]}_winding_{side + 1}",
                inner=lower, outer=upper, start=start, end=end,
                angle=axis * math.pi / 2.0 + side * math.pi,
                count=count, color=colors[axis],
                half_angle=math.radians(span / 2.0), band=layer_band,
            ))
    if support_solids:
        from temsim.cad_mesh import meshes_from_solids
        support_count = support_mesh_segments(support_solids, count)
        copper_meshes = tuple(meshes)
        for spec in support_solids:
            mesh = (_conductor_gap_mesh(spec, copper_meshes, support_count)
                    if spec.region in GAP_REGIONS else meshes_from_solids((spec,), support_count)[0])
            meshes.append(annotate_support_mesh(mesh, part))
    linked = str(drive_key or "declared DPH/DP channel")
    notes = (
        f"{key}: {DESCRIPTION} Linked field source: {linked}.",
        str(part.get("axial_relation_note", "")),
        str(part.get("radial_relation_note", "")),
        f"Copper axial length {end-start:g} mm; finite field length remains "
        f"{part.get('effective_thickness_mm', 'unspecified')} mm independently.",
        f"Display construction: each winding layer is {layer:g} mm thick; "
        f"opposing loops span {span:g} degrees, with the second pair "
        f"rotated by 90 degrees. End/side band width is {band:g} mm. "
        "These are reconstruction dimensions, not "
        "manufacturer dimensions, wire gauge, turn count or a current calibration.",
        ("Legacy file: unspecified end/side bands retain the old per-layer minimum of "
         "8% axial extent and 20% layer inner radius."
         if part.get("mechanical_profile") != PROFILE and "winding_band_width_mm" not in part else ""),
    )
    support_notes = tuple(dict.fromkeys(solid.note for solid in support_solids))
    material_start, material_end = full_material_axial_extent(part)
    if material_start < start or material_end > end:
        notes += (f"Passive laminate material extends from {material_start:g} to {material_end:g} mm "
                  "local Z, including explicitly declared axial edge covers; copper and optical "
                  "allocation remain unchanged.",)
    return tuple(meshes), tuple(note for note in notes if note) + support_notes


# Public Python entry point retained for callers of the initial implementation.
corrector_deflector_meshes = deflector_coil_meshes
