"""Transactional drafts of existing TOML dimensions and material regions."""

from collections.abc import Mapping
from copy import deepcopy
import math
from numbers import Real
from pathlib import Path
from temsim import input_io
import tomllib

from temsim import module_manifest
from temsim.manifest_editor import resized_part_axial_coordinates
from temsim.component_representation import SHARED_DEFLECTOR_HOSTS, shared_deflector_field_owner
from temsim.optics.field_hardware_binding import bound_field_owner, resolve_field_hardware_parts
from temsim.component_operations import (
    PartChangeSet, added_component_document, placed_component_document,
    copied_component_document, validate_component_graph, CUSTOM_COMPONENT_ROLES,
    resized_copied_axial_fields,
)


def _validate_internal_details(parts, geometry=None):
    """Validate the final material draft before publishing it or its history."""
    from temsim.cad_auxiliary import validate_gun_electrode_geometry
    from temsim.pole_geometry import validate_pole_face_land_geometry
    from temsim.cad_recording_planes import validate_detector_footprint
    from temsim.cad_detectors import validate_detector_material_geometry
    from temsim.cad_gun_stigmator import gun_stigmator_dimensions
    from temsim.cad_condenser_cartridge import validate_cartridge_geometry
    from temsim.cad_stigmator_support import stigmator_support_dimensions
    from temsim.cad_aperture_support import validate_aperture_support
    from temsim.cad_c3_lens_hardware import validate_c3_lens_hardware
    from temsim.cad_adapter_lens_hardware import validate_adapter_lens_hardware
    from temsim.cad_probe_transfer_lens_hardware import validate_probe_transfer_lens_hardware
    from temsim.cad_tl22_lens_hardware import validate_tl22_lens_hardware
    from temsim.cad_objective_upper_hardware import validate_objective_upper_hardware
    from temsim.cad_probe_hexapole_support import validate_hexapole_support
    from temsim.gun_rear_geometry import rear_part_dimensions
    by_key = {part["key"]: part for part in parts}
    for part in parts:
        rear_part_dimensions(part)
        validate_gun_electrode_geometry(part)
        validate_pole_face_land_geometry(part)
        validate_detector_footprint(part)
        validate_detector_material_geometry(part, by_key)
        gun_stigmator_dimensions(part)
        validate_cartridge_geometry(part, by_key)
        stigmator_support_dimensions(part)
        validate_aperture_support(part, by_key, geometry)
        validate_c3_lens_hardware(part, by_key)
        validate_adapter_lens_hardware(part, by_key)
        validate_tl22_lens_hardware(part, by_key)
        validate_objective_upper_hardware(part, by_key)
        validate_probe_transfer_lens_hardware(part, by_key)
        validate_hexapole_support(part)


class PartModelDocument:
    """A file-backed draft shared by every selected part in the 3D editor."""

    def __init__(self, path):
        self._new_document = False
        self.path = Path(path).resolve()
        self._source_bytes = input_io.read_bytes(self.path)
        self._archive_identity = input_io.active_archive().identity if input_io.active_archive() is not None else None
        from temsim.shared_tip import materialized_text, dependencies
        self._dependency_bytes = dependencies(self.path)
        self._editable_text = materialized_text(self._source_bytes.decode("utf-8-sig"), self.path)
        self._baseline = resolve_field_hardware_parts(tomllib.loads(self._editable_text))
        if not isinstance(self._baseline.get("parts"), list) or not self._baseline["parts"]:
            raise ValueError("Open an instrument module TOML containing [[parts]] definitions")
        keys = [part.get("key") for part in self._baseline["parts"]]
        if any(not isinstance(key, str) or not key for key in keys) or len(keys) != len(set(keys)):
            raise ValueError("Every part must have a unique non-empty key")
        from temsim.probe_hexapole_geometry import validate_probe_hexapole_geometry
        from temsim.corrector_model_3d import validate_deflector_coil_part
        from temsim.ordinary_deflector_geometry import validate_ordinary_deflector_part
        for part in self._baseline["parts"]:
            validate_probe_hexapole_geometry(part)
            validate_deflector_coil_part(part)
            validate_ordinary_deflector_part(part)
        _validate_internal_details(self._baseline["parts"], self._baseline.get("geometry"))
        from temsim.deflector_support_geometry import validate_support_installations
        validate_support_installations(self._baseline["parts"])
        by_key = {part["key"]: part for part in self._baseline["parts"]}
        for key in keys:
            seen = set()
            ancestor = key
            while ancestor in by_key:
                if ancestor in seen:
                    raise ValueError("Component ownership must not contain a cycle")
                seen.add(ancestor)
                ancestor = by_key[ancestor].get("parent_key")
        self.document = deepcopy(self._baseline)
        from temsim.subassemblies import ownership
        self._subassembly_owners = ownership(self._baseline, self.path)
        self._history = [deepcopy(self.document)]
        self._history_index = 0

    @property
    def dirty(self):
        return getattr(self, "_new_document", False) or self.document != self._baseline

    @classmethod
    def from_step_asset(cls, asset, path, *, key=None, name=None):
        """Create an unsaved independent mechanical module, without a temp file."""
        import tomli_w
        from temsim.step_assets import base_from_asset
        base_from_asset(asset)
        result = cls.__new__(cls)
        result.path = Path(path).resolve()
        if result.path.exists():
            raise ValueError("Choose a new TOML path; existing definitions are not replaced by import")
        result._new_document = True
        result._source_bytes = b""
        result._archive_identity = None
        result._dependency_bytes = {}
        result._subassembly_owners = {}
        result._baseline = {"format_version": 1, "coordinate_system": "module_local_z_mm",
                            "module": {"key": "mechanical:step", "type": "mechanical", "name": "Imported STEP"},
                            "geometry": {"length_mm": 1.0}, "parts": []}
        result._editable_text = tomli_w.dumps({k: v for k, v in result._baseline.items() if k != "parts"})
        result.document = deepcopy(result._baseline)
        result._history = [deepcopy(result.document)]
        result._history_index = 0
        result.import_step_asset(asset, key=key, name=name)
        return result

    def import_step_asset(self, asset, *, mode="add", target_key=None,
                          registration="preserve", key=None, name=None):
        """Atomically bind imported material; optical definitions remain intact.

        New components preserve STEP module coordinates. Replacement can centre
        the imported bounding box on the existing part reference; this is an
        explicit registration, never a recovered optical datum from STEP.
        """
        import numpy as np
        from temsim.step_assets import base_from_asset, asset_bounds
        from temsim.part_model_features import default_model_3d, validate_model_3d
        from temsim.component_operations import make_component
        if mode not in {"add", "replace"} or registration not in {"preserve", "center"}:
            raise ValueError("Choose add/replace and preserve/center registration")
        base = base_from_asset(asset)
        center, size = asset_bounds(asset)
        if mode == "add":
            if key is None:
                used = {p["key"] for p in self.document["parts"]}
                index = 1
                while f"step_import_{index}" in used:
                    index += 1
                key = f"step_import_{index}"
            target = make_component(key=key, name=name or asset.get("source", {}).get("filename", key), shape="box",
                                    center_z_mm=float(center[2]), length_mm=float(size[2]),
                                    width_mm=float(size[0]), height_mm=float(size[1]))
            model = default_model_3d(target)
            model["base"] = base
            model["transform"]["offset_mm"] = [float(center[0]), float(center[1]), 0.]
            target["model_3d"] = model
            validate_model_3d(target)
            return self.add_component(target)
        if target_key is None:
            raise ValueError("Select the material component to replace")
        from temsim.component_representation import non_material_role
        target = deepcopy(self.part(target_key))
        if non_material_role(target) or any(p.get("parent_key") == target_key and not non_material_role(p)
                                             for p in self.document["parts"]):
            raise ValueError("Replace a material leaf, not an optical channel or an assembly with child parts")
        model = default_model_3d(target)
        model["base"] = base
        if registration == "preserve":
            from temsim.lens_pose import mechanical_part_transform_mm, supports_physical_lens_pose
            from temsim.energy_filter_model_3d import supports_energy_filter_part
            rotation, offset = mechanical_part_transform_mm(target, {p["key"]: p for p in self.document["parts"]})
            if (supports_physical_lens_pose(target) or supports_energy_filter_part(target)
                    or not np.allclose(rotation, np.eye(3), atol=1e-14, rtol=0)
                    or not np.allclose(offset, np.zeros(3), atol=1e-14, rtol=0)):
                raise ValueError("This component has an optical or branch placement. Choose explicit centre registration to retain that datum")
            model["transform"]["offset_mm"] = [float(center[0]), float(center[1]),
                                                     float(center[2]) - float(target["local_center_z_mm"])]
        # Preserve legacy optical pose before installing new shape-only CAD.
        from temsim.lens_pose import supports_physical_lens_pose, migrate_legacy_lens_pose
        if supports_physical_lens_pose(target):
            migrate_legacy_lens_pose(target)
        target["model_3d"] = model
        validate_model_3d(target)
        self._synchronize_custom_base_length(target)
        self._commit_part(target_key, target)
        return target_key

    def reset_model_geometry(self, key):
        """Restore the imported source size and clear cuts, retaining placement."""
        from temsim.step_assets import read_asset, base_from_asset
        model = deepcopy(self.part(key).get("model_3d", {}))
        if model.get("base", {}).get("kind") != "step":
            self.set_model_3d(key, None)
            return
        model["base"] = base_from_asset(read_asset(model["base"]["asset_json"]))
        model["features"] = []
        model["transform"]["scale_xy"] = [1., 1.]
        self.set_model_3d(key, model)

    @property
    def can_undo(self):
        return self._history_index > 0

    @property
    def can_redo(self):
        return self._history_index + 1 < len(self._history)

    def part(self, key):
        return next(part for part in self.document["parts"] if part["key"] == key)

    def _remember(self):
        if self.document == self._history[self._history_index]:
            return
        self._history = self._history[:self._history_index + 1]
        self._history.append(deepcopy(self.document))
        if len(self._history) > 100:
            self._history.pop(0)
        self._history_index = len(self._history) - 1

    def _commit_part(self, key, candidate):
        from temsim.ordinary_deflector_geometry import validate_ordinary_deflector_part
        from temsim.optics.electron_gun.tip_assembly import complete_tip_updates, validate_tip_part
        from temsim.corrector_model_3d import validate_deflector_coil_part
        from temsim.probe_hexapole_geometry import validate_probe_hexapole_geometry
        previous = self.part(key)
        updates = {("parts", key, field): value for field, value in candidate.items()
                   if previous.get(field) != value}
        for path, value in complete_tip_updates(self.document, updates).items():
            candidate[path[2]] = value
        validate_tip_part(candidate)
        validate_ordinary_deflector_part(candidate)
        validate_deflector_coil_part(candidate)
        validate_probe_hexapole_geometry(candidate)
        for index, part in enumerate(self.document["parts"]):
            if part["key"] == key:
                updated = deepcopy(self.document)
                updated["parts"][index] = candidate
                from temsim.mechanical_dimension_bindings import FIELDS, synchronize_dimension_edit
                for field in FIELDS:
                    if field in part and field in candidate and candidate[field] != part[field]:
                        synchronize_dimension_edit(updated, key, field, part[field])
                from temsim.deflector_support_geometry import validate_support_installations
                validate_support_installations(updated["parts"])
                from temsim.subassemblies import reflow
                candidate_document = reflow(self.document, updated, self.path, owners=self._subassembly_owners)
                candidate_document = resolve_field_hardware_parts(candidate_document)
                _validate_internal_details(candidate_document["parts"], candidate_document.get("geometry"))
                from temsim.gun_rear_geometry import validate_rear_gun_document
                validate_rear_gun_document(candidate_document)
                self.document = candidate_document
                self._remember()
                return
        raise ValueError(f"Unknown part: {key}")

    def _commit_component_operation(self, candidate):
        # Structural edits must be valid before replacing any part of the
        # current draft; validation failure preserves both draft and history.
        from temsim.subassemblies import reflow
        candidate = reflow(self.document, candidate, self.path, owners=self._subassembly_owners)
        validate_component_graph(candidate)
        module_manifest.validate_document(candidate)
        self.document = resolve_field_hardware_parts(candidate)
        self._remember()

    def place_subassembly(self, key, placement):
        """Save a fixed origin or a persistent component anchor in the draft."""
        candidate = deepcopy(self.document)
        for entry in candidate.get("subassemblies", ()):
            if entry["key"] == key:
                entry["placement"] = deepcopy(placement)
                self._commit_component_operation(candidate)
                return
        raise ValueError(f"Unknown subassembly: {key}")

    def add_component(self, part):
        """Insert an independent mechanical part as one undoable operation."""
        candidate, key = added_component_document(self.document, part)
        self._commit_component_operation(candidate)
        return key

    def place_component(self, key, center_z_mm, include_children=True, *, physical_pose=None):
        """Translate module-local axial coordinates, optionally with children."""
        if key in SHARED_DEFLECTOR_HOSTS:
            raise ValueError(f"{key} uses shared hardware; place {SHARED_DEFLECTOR_HOSTS[key]} instead")
        host = bound_field_owner(self.part(key), "local_center_z_mm")
        if host:
            raise ValueError(f"{key} follows {host}; place its host or edit the coil optical reference offset")
        candidate, keys = placed_component_document(
            self.document, key, center_z_mm, include_children=include_children,
        )
        if physical_pose is not None:
            part = next(part for part in candidate["parts"] if part["key"] == key)
            self._set_physical_pose_values(part, physical_pose)
        self._commit_component_operation(candidate)
        return keys

    @classmethod
    def _set_physical_pose_values(cls, part, values):
        from temsim.lens_pose import (
            PHYSICAL_POSE_FIELDS, migrate_legacy_lens_pose,
            supports_physical_lens_pose, validate_physical_lens_pose,
        )
        if not supports_physical_lens_pose(part):
            raise ValueError("Edit a supported main-column component, or the physical host of a shared channel")
        if not isinstance(values, Mapping) or set(values) - set(PHYSICAL_POSE_FIELDS):
            raise ValueError("Choose component offsets in mm, azimuths in degrees or optical tilts in mrad")
        values = {field: cls._finite_dimension(value) for field, value in values.items()}
        migrate_legacy_lens_pose(part)
        part.update(values)
        validate_physical_lens_pose(part)

    def set_physical_pose(self, key, values):
        """Stage one main-column component pose without changing excitation."""
        part = deepcopy(self.part(key))
        self._set_physical_pose_values(part, values)
        self._commit_part(key, part)

    def copy_component_from(self, source, key, new_key, center_z_mm,
                            parent_key=None, include_children=True, *, name=None):
        """Make an independent mechanical copy without adding optical controls."""
        if key in SHARED_DEFLECTOR_HOSTS:
            raise ValueError(f"{key} is a control channel on {SHARED_DEFLECTOR_HOSTS[key]}, not independent hardware")
        candidate, new_key = copied_component_document(
            self.document, source, key, new_key, center_z_mm,
            parent_key=parent_key, include_children=include_children, name=name,
        )
        self._commit_component_operation(candidate)
        return new_key

    @staticmethod
    def _finite_dimension(value):
        try:
            if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value):
                raise ValueError("A dimension must be a finite number")
            return float(value)
        except (OverflowError, TypeError) as exc:
            raise ValueError("A dimension must be a finite number") from exc

    @staticmethod
    def _numeric_target(root, path):
        if not path:
            raise ValueError("Choose an existing numeric dimension")
        current = root
        try:
            for segment in path[:-1]:
                if isinstance(current, list) and (
                    isinstance(segment, bool) or not isinstance(segment, int) or segment < 0
                ):
                    raise ValueError("Choose an existing array element")
                current = current[segment]
            final = path[-1]
            if isinstance(current, list) and (
                isinstance(final, bool) or not isinstance(final, int) or final < 0
            ):
                raise ValueError("Choose an existing array element")
            previous = current[final]
        except (KeyError, IndexError, TypeError) as exc:
            raise ValueError("Choose an existing dimension path") from exc
        if isinstance(previous, bool) or not isinstance(previous, Real):
            raise ValueError("Choose an existing numeric dimension")
        return current, final

    @staticmethod
    def _resize_copied_axial_geometry(part, length):
        part.update(resized_copied_axial_fields(part, length))

    @staticmethod
    def _synchronize_custom_base_length(part):
        base = part.get("model_3d", {}).get("base", {})
        if (part.get("mechanical_part_role") in CUSTOM_COMPONENT_ROLES
                and base.get("kind", "existing") != "existing"):
            length = float(base["length_mm"])
            PartModelDocument._resize_copied_axial_geometry(part, length)
            part.update(resized_part_axial_coordinates(part, length))
            part["length_mm"] = length

    def set_dimension(self, path, value):
        path = tuple(path)
        value = self._finite_dimension(value)
        if len(path) < 3 or path[0] != "parts":
            raise ValueError("Only existing part dimensions can be edited")
        host = (shared_deflector_field_owner(path[1], path[2])
                or bound_field_owner(self.part(path[1]), path[2]))
        if host:
            raise ValueError(f"{path[1]} uses shared hardware; edit {host} to change its structure")
        part = deepcopy(self.part(path[1]))
        field = path[2]
        from temsim.dimension_edit_policy import dimension_reference_reason
        if reason := dimension_reference_reason(part, field):
            raise ValueError(reason)
        from temsim.lens_pose import PHYSICAL_POSE_FIELDS, supports_physical_lens_pose
        if len(path) == 3 and field in PHYSICAL_POSE_FIELDS and supports_physical_lens_pose(part):
            self.set_physical_pose(path[1], {field: value})
            return
        from temsim.part_model_apertures import has_optional_plate_thickness, validate_optional_plate_thickness
        if len(path) == 3 and field == "plate_thickness_mm" and has_optional_plate_thickness(part):
            part[field] = value
            validate_optional_plate_thickness(part)
            self._commit_part(path[1], part)
            return
        if field == "model_3d":
            from temsim.part_model_features import validate_model_3d

            current, final = self._numeric_target(part, path[2:])
            current[final] = value
            validate_model_3d(part)
            if path[2:] == ("model_3d", "base", "length_mm"):
                self._synchronize_custom_base_length(part)
            self._commit_part(path[1], part)
            return
        if field not in part or not field.endswith(("_mm", "_um", "_nm", "_deg", "_mrad")):
            raise ValueError("Choose an existing dimension in mm, µm, nm, degrees or mrad")
        from temsim.optics.electron_gun.tip_assembly import is_tip_part
        if is_tip_part(part) and len(path) == 3:
            if isinstance(part[field], bool) or not isinstance(part[field], Real):
                raise ValueError("Choose a numeric dimension")
            part[field] = value
            self._commit_part(path[1], part)
            return
        if field == "local_center_z_mm":
            raise ValueError("The axial centre is fixed; edit the existing length or endpoints")
        if len(path) == 3:
            if isinstance(part[field], bool) or not isinstance(part[field], Real):
                raise ValueError("Choose a numeric dimension")
            if field == "length_mm":
                endpoints = resized_part_axial_coordinates(part, value)
                self._resize_copied_axial_geometry(part, value)
                part.update(endpoints)
                base = part.get("model_3d", {}).get("base", {})
                if (part.get("mechanical_part_role") in CUSTOM_COMPONENT_ROLES
                        and base.get("kind", "existing") != "existing"):
                    base["length_mm"] = value
            part[field] = float(value)
            if field in {"local_start_z_mm", "local_end_z_mm"}:
                part["length_mm"] = float(part["local_end_z_mm"]) - float(part["local_start_z_mm"])
        else:
            current, index = self._numeric_target(part[field], path[3:])
            current[index] = float(value)
        self._commit_part(path[1], part)

    def set_model_3d(self, key, configuration):
        """Replace one mechanical CAD configuration, or remove it with None.

        Schema errors are rejected atomically. A schema-valid boolean operation
        may remain a draft until complete geometry is validated on Save.
        Existing physical dimensions and solver parameters are left unchanged.
        """
        from temsim.part_model_features import validate_model_3d

        host = bound_field_owner(self.part(key), "model_3d")
        if host:
            raise ValueError(f"{key} is a control channel; edit {host} to change its structure")
        candidate = deepcopy(self.part(key))
        if configuration is None:
            candidate.pop("model_3d", None)
        elif isinstance(configuration, Mapping):
            candidate["model_3d"] = deepcopy(dict(configuration))
        else:
            raise ValueError("model_3d must be a table or None")
        validate_model_3d(candidate)
        self._synchronize_custom_base_length(candidate)
        self._commit_part(key, candidate)

    def update_model_3d(self, key, updates):
        """Merge nested tables in one undo step; replace supplied collections."""
        from temsim.part_model_features import default_model_3d

        if not isinstance(updates, Mapping):
            raise ValueError("model_3d updates must be a table")
        part = self.part(key)
        configuration = deepcopy(part.get("model_3d", default_model_3d(part)))

        def merge(target, values):
            for field, value in values.items():
                if isinstance(value, Mapping) and isinstance(target.get(field), dict):
                    merge(target[field], value)
                else:
                    target[field] = deepcopy(value)

        merge(configuration, updates)
        self.set_model_3d(key, configuration)

    def upsert_model_feature(self, key, feature):
        """Add or replace a stable feature id without changing other features."""
        from temsim.part_model_features import default_model_3d

        if not isinstance(feature, Mapping) or not isinstance(feature.get("id"), str) or not feature["id"]:
            raise ValueError("A feature needs a non-empty stable id")
        part = self.part(key)
        configuration = deepcopy(part.get("model_3d", default_model_3d(part)))
        features = configuration.setdefault("features", [])
        for index, previous in enumerate(features):
            if previous.get("id") == feature["id"]:
                features[index] = deepcopy(dict(feature))
                break
        else:
            features.append(deepcopy(dict(feature)))
        self.set_model_3d(key, configuration)

    def remove_model_feature(self, key, feature_id):
        configuration = deepcopy(self.part(key).get("model_3d", {"schema_version": 1}))
        features = configuration.get("features", [])
        if not any(feature.get("id") == feature_id for feature in features):
            raise ValueError(f"Unknown model feature: {feature_id}")
        configuration["features"] = [feature for feature in features if feature.get("id") != feature_id]
        self.set_model_3d(key, configuration)

    def assign_material(self, key, material_key, region="body"):
        from temsim.part_materials import part_material_updates
        updates = part_material_updates(self.part(key), material_key, region=region)
        for path, value in updates.items():
            if tuple(path[:2]) != ("parts", key) or len(path) != 3:
                raise ValueError("Invalid material assignment path")
            self.part(key)[path[2]] = deepcopy(value)
        self._remember()

    def undo(self):
        if self.can_undo:
            self._history_index -= 1
            self.document = deepcopy(self._history[self._history_index])

    def redo(self):
        if self.can_redo:
            self._history_index += 1
            self.document = deepcopy(self._history[self._history_index])

    def revert(self):
        self.document = deepcopy(self._baseline)
        self._history = [deepcopy(self.document)]
        self._history_index = 0

    def updates(self):
        originals = {part["key"]: part for part in self._baseline["parts"]}
        updates = {}
        additions = []
        for part in self.document["parts"]:
            if part["key"] not in originals:
                additions.append(deepcopy(part))
                continue
            original = originals[part["key"]]
            for field, value in part.items():
                if bound_field_owner(part, field):
                    # Persist the authoritative host edit only. Derived
                    # coordinates are resolved again on load, never competing
                    # writes to the control channel or its anchored insert.
                    continue
                if field not in original or value != original[field]:
                    updates[("parts", part["key"], field)] = deepcopy(value)
            if "material_regions" in original and "material_regions" not in part:
                updates[("parts", part["key"], "material_regions")] = {}
            if "model_3d" in original and "model_3d" not in part:
                updates[("parts", part["key"], "model_3d")] = None
        current_keys = {part["key"] for part in self.document["parts"]}
        removed = tuple(key for key in originals if key not in current_keys)
        previous = {entry["key"]: entry["placement"] for entry in self._baseline.get("subassemblies", ())}
        placements = {entry["key"]: deepcopy(entry["placement"])
                      for entry in self.document.get("subassemblies", ())
                      if previous.get(entry["key"]) != entry["placement"]}
        return PartChangeSet(updates, tuple(additions), removed, self._source_bytes,
                             dict(self._dependency_bytes), placements, True)

    def reload(self):
        """Read an external source revision only after this draft is resolved."""
        if self.dirty:
            raise ValueError("Save a copy or Revert the current draft before reloading")
        candidate = type(self)(self.path)
        self._source_bytes = candidate._source_bytes
        self._dependency_bytes = candidate._dependency_bytes
        self._subassembly_owners = candidate._subassembly_owners
        self._editable_text = candidate._editable_text
        self._baseline = candidate._baseline
        self.document = candidate.document
        self._history = candidate._history
        self._history_index = 0

    def validate(self):
        validate_component_graph(self.document)
        module_manifest.validate_document(self.document)

    def assert_source_current(self):
        if self._archive_identity is not None:
            raise ValueError("Archived structure is read-only; load a live assembly before saving structural edits")
        if getattr(self, "_new_document", False):
            if self.path.exists():
                raise ValueError("The new destination now exists; Save copy to avoid replacing it")
            return
        if self.path.read_bytes() != self._source_bytes:
            raise ValueError("The source file changed outside this editor. Save a copy or reopen it before saving.")
        from temsim.shared_tip import dependencies
        if dependencies(self.path) != self._dependency_bytes:
            raise ValueError("An assembly dependency changed outside this editor. Save a copy or reopen it before saving.")

    def save(self, *, project_save=None):
        self.assert_source_current()
        self.validate()
        if getattr(self, "_new_document", False):
            staged = self.independent_copy_text()
            self.path.parent.mkdir(parents=True, exist_ok=True)
            # Exclusive creation protects a new definition from a concurrent
            # file appearing after the destination was chosen in the dialog.
            with self.path.open("x", encoding="utf-8", newline="") as stream:
                stream.write(staged)
            self._accept_saved_file(self.path, expected=tomllib.loads(staged))
            return
        updates = self.updates()
        if not updates:
            return
        staged = module_manifest.stage_manifest_text(
            self._editable_text, updates
        )
        # Schema, Boolean and catalog preparation may take time. Recheck the
        # source before either persistence route can write the staged edit.
        self.assert_source_current()
        if project_save is not None:
            if project_save(self.path, updates) is False:
                raise ValueError("The project did not save the model draft")
        else:
            from temsim.shared_tip import catalog_root_for, catalog_definitions
            root = catalog_root_for(self.path)
            if root is not None and (self._dependency_bytes or self.path in catalog_definitions(root)):
                from temsim.component_persistence import save_component_changes
                import os
                save_component_changes(root, os.path.relpath(self.path, root), updates, None)
            else:
                if self.document.get("subassemblies"):
                    raise ValueError("Save a composed assembly inside its catalog, or use Save copy for an independent file")
                module_manifest._atomic_write_text(self.path, staged)
        self._accept_saved_file(self.path, expected=tomllib.loads(staged))

    def save_copy(self, path):
        destination = Path(path).resolve()
        if destination == self.path:
            raise ValueError("Use Save for the current file")
        from temsim.shared_tip import catalog_root_for, catalog_definitions
        root = catalog_root_for(destination)
        if root is not None and destination in catalog_definitions(root):
            raise ValueError("Use Save to edit a linked physical definition; choose an independent destination for a copy")
        staged = self.independent_copy_text()
        module_manifest._atomic_write_text(destination, staged)
        self._accept_saved_file(destination, expected=tomllib.loads(staged))

    def independent_copy_text(self):
        """Validated, materialized candidate definition without filesystem edits."""
        self.validate()
        staged = module_manifest.stage_manifest_text(
            self._editable_text, self.updates()
        )
        # Save copy is explicitly independent, including a module with shared
        # sources. Resolve its values before removing the source link.
        parsed = tomllib.loads(staged)
        if parsed.get("subassemblies") or any("tip_definition_file" in part for part in parsed["parts"]):
            import tomli_w
            parsed.pop("subassemblies", None)
            for part in parsed["parts"]:
                part.pop("tip_definition_file", None)
            staged = tomli_w.dumps(parsed)
        return staged

    def _accept_saved_file(self, path, *, expected):
        source = path.read_bytes()
        from temsim.shared_tip import materialized_text
        parsed = tomllib.loads(materialized_text(source.decode("utf-8-sig"), path))
        if parsed != expected:
            raise ValueError("The saved file does not match the draft. The draft is retained; inspect the source before saving again.")
        self.path = path
        self._new_document = False
        self._source_bytes = source
        from temsim.shared_tip import materialized_text, dependencies
        self._dependency_bytes = dependencies(path)
        self._editable_text = materialized_text(source.decode("utf-8-sig"), path)
        self._baseline = resolve_field_hardware_parts(tomllib.loads(self._editable_text))
        self.document = deepcopy(self._baseline)
        from temsim.subassemblies import ownership
        self._subassembly_owners = ownership(self._baseline, self.path)
        self._history[self._history_index] = deepcopy(self.document)
