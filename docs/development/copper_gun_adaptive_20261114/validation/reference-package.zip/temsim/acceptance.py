"""Fail-closed, namespaced software evidence; never physical qualification."""
from collections import Counter

from temsim.acceptance_gpu import is_complete_skip, is_gpu_hardware_test, is_gpu_unavailable_reason


CLASSICAL_CRITERIA = {
    "product-usability/AT-01": ("Physical source admission", ("tests/test_source_admission.py",)),
    "product-usability/AT-13": ("Shared particle/wave tip edits and captured source ownership", (
        "tests/test_shared_tip_workflow.py", "tests/test_coherent_inputs.py",
        "tests/test_shared_surface_source.py")),
    "product-usability/AT-02": ("Complete captured instrument", ("tests/test_working_point_contract.py", "tests/test_input_assets.py",
        "tests/test_component_position_contract.py", "tests/test_component_persistence.py", "tests/test_shared_tip.py",
        "tests/test_current_profile_contract.py")),
    "product-usability/AT-06": ("Transactional alignment", ("tests/test_alignment_transactions.py",)),
    "product-usability/AT-12": ("Unknown-input and opt-in vacuum invalidation", ("tests/test_parameter_registry.py", "tests/test_vacuum_opt_in.py")),
    "round2/R2-AT-03": ("Explicit classical acceptance", ("tests/test_classical_acceptance.py",)),
    "round2/R2-AT-04": ("Legacy blockers preserved", ("tests/test_development_acceptance.py",)),
    "round2/R2-AT-05": ("Namespaced, fail-closed receipts", ("tests/test_classical_acceptance.py",)),
    "round2/R2-AT-06": ("Worker entry and transition evidence", ("tests/test_job_lifecycle.py",)),
    "round2/R2-AT-07": ("Captured inputs and latest live work", ("tests/test_background_calculation_requests.py", "tests/test_background_preview_gui.py", "tests/test_calculation_controller.py")),
    "round2/R2-AT-08": ("Exactly-once terminal ownership", ("tests/test_job_lifecycle.py", "tests/test_job_coordination.py")),
    "round2/R2-AT-09": ("Independent High and experiment ownership", ("tests/test_job_coordination_gui.py", "tests/test_result_readout.py")),
    "round2/R2-AT-10": ("Backend absence/resource policy and available-GPU selection", (
        "tests/test_compute_backend.py", "tests/test_ray_gpu_policy.py",
        "tests/test_coherent_cuda_policy.py", "tests/test_coherent_cli_policy.py",
        "tests/test_coherent_cuda_unified_merge.py",
        "tests/test_backend_failure_semantics.py", "tests/test_gui_backend_discovery.py",
        "tests/test_cpu_backend_isolation.py", "tests/test_lazy_cuda_kernels.py")),
    "round2/R2-AT-11": ("Original non-retryable failures", ("tests/test_backend_failure_semantics.py",)),
    "round2/R2-AT-12": ("Stage reporting and device ownership fixtures", ("tests/test_backend_failure_semantics.py", "tests/test_ray_device_residency.py", "tests/test_calculation_performance.py")),
}
CLASSICAL_TESTS = tuple(sorted({path for _, paths in CLASSICAL_CRITERIA.values() for path in paths}))


ACCEPTANCE_SCOPES = {
    "classical": {
        "description": "Existing classical particle software contracts",
        "evidence_kind": "software-contracts-with-offscreen-ui",
        "criteria": CLASSICAL_CRITERIA,
    },
    "gun-fields": {
        "description": "Classical tip geometry and bounded electrostatic field checks",
        "evidence_kind": "bounded-numerical-and-software-checks",
        "criteria": {
            "gun-fields/GF-01": ("Conductor geometry, field boundaries and exact field cache", (
                "tests/test_closed_gun_field.py", "tests/test_axisymmetric_cut_field.py",
                "tests/test_analytic_gun_field.py",
                "tests/test_small_bore_electrode_mesh.py", "tests/test_tip_model_switch_validation.py")),
            "gun-fields/GF-02": ("Continuous tip and thermionic emission, transport and saved inputs", (
                "tests/test_continuous_tip_curvature.py", "tests/test_tip_curvature_comparison.py",
                "tests/test_geometry_gun_cache.py", "tests/test_geometry_gun_implicit_tolerance.py",
                "tests/test_gun_transverse_adaptive.py", "tests/test_thermionic_source_validation.py")),
            "gun-fields/GF-03": ("Exact field identity, conservative reuse and domain comparison metrics", (
                "tests/test_diagnostic_field_identity.py", "tests/test_grounded_field_identity.py",
                "tests/test_diagnostic_gun_domains.py")),
            "gun-fields/GF-04": ("Grounded instrument coverage and installed filter axial handoff", (
                "tests/test_instrument_electric.py", "tests/test_recording_vacuum_endpoint.py")),
            "gun-fields/GF-05": ("Captured emission CDF measure, prefix stability and persistence", (
                "tests/test_nested_emission_sampling.py", "tests/test_explicit_emission_cdf.py")),
            "gun-fields/GF-06": ("Conditional quadrature and unrenormalised source probability", (
                "tests/test_source_radial_quadrature.py", "tests/test_source_azimuth_orbit.py",
                "tests/test_source_energy_strata.py")),
            "gun-fields/GF-07": ("Offline conditional-source evidence and archive contracts, not propagation qualification", (
                "tests/test_conditional_source_analysis.py", "tests/test_conditional_source_validation.py",
                "tests/test_conditional_energy_analysis.py", "tests/test_conditional_energy_measure.py",
                "tests/test_conditional_energy_source_validation.py", "tests/test_conditional_energy_transport_contract.py")),
        },
    },
    "electron-execution": {
        "description": "Virtual electron electromagnetic transport and isolated execution",
        "evidence_kind": "bounded-numerical-and-real-process-checks",
        "criteria": {
            "electron-execution/EE-01": ("Independent electromagnetic references and supported scene", (
                "tests/test_magnetic_test_particle.py", "tests/test_test_electron_scene.py")),
            "electron-execution/EE-02": ("Compiled field and trajectory parity with complete hardware stops", (
                "tests/test_closed_gun_execution.py", "tests/test_test_electron_compiled.py",
                "tests/test_test_electron_intercepts.py", "tests/test_test_electron_performance.py")),
            "electron-execution/EE-08": ("Shared production column and virtual-electron transport", (
                "tests/test_shared_electron_column.py",)),
            "electron-execution/EE-03": ("Owned real process, cancellation and accepted progress", (
                "tests/test_test_electron_execution.py",)),
            "electron-execution/EE-04": ("Code-bound native caches without deleting historical evidence", (
                "tests/test_numba_cache.py",)),
            "electron-execution/EE-05": ("Captured field and execution identity through real metadata boundaries", (
                "tests/test_diagnostic_scene_identity.py", "tests/test_diagnostic_execution_identity.py")),
            "electron-execution/EE-06": ("Bounded failure recovery and retained worker diagnostics", (
                "tests/test_electron_execution_faults.py", "tests/test_electron_execution_diagnostics.py",
                "tests/test_electron_execution_protocol.py", "tests/test_electron_resource_cleanup.py",
                "tests/test_cpu_resources.py")),
            "electron-execution/EE-07": ("Safe independent diagnostic history archives and source rejection", (
                "tests/test_electron_diagnostic_session.py",)),
        },
    },
    "field-ui": {
        "description": "Combined magnetic fields, virtual electron interaction and hardware editing",
        "evidence_kind": "offscreen-ui-and-bounded-field-checks",
        "criteria": {
            "field-ui/FU-01": ("Combined field support and direction-aware field-line geometry", (
                "tests/test_magnetic_field_scene.py", "tests/test_magnetic_field_lines.py",
                "tests/test_field_display_regions.py",
                "tests/test_field_vector_scene.py", "tests/test_field_vector_production.py")),
            "field-ui/FU-02": ("Cached field rendering and physical display-range linkage", (
                "tests/test_magnetic_field_3d.py", "tests/test_magnetic_field_canvas.py",
                "tests/test_field_vector_page.py",
                "tests/test_field_vector_lod.py", "tests/test_field_vector_viewport.py",
                "tests/test_field_section_sampling.py", "tests/test_field_vector_readability.py",
                "tests/test_field_density_texture.py", "tests/test_field_density_canvas.py",
                "tests/test_field_density_page.py",
                "tests/test_magnetic_profile_lod.py",
                "tests/test_field_vector_geometry.py", "tests/test_field_vector_mesh_canvas.py",
                "tests/test_field_vector_overlay_page.py",
                "tests/test_field_component_inspection.py", "tests/test_magnetic_component_navigation.py",
                "tests/test_incremental_magnetic_scene.py", "tests/test_magnetic_navigation_link.py")),
            "field-ui/FU-03": ("Latest electron edits, continuous progress and dock lifetime", (
                "tests/test_magnetic_test_electron_gui.py", "tests/test_continuous_electron_gui.py",
                "tests/test_gui_signal_receiver_lifetime.py", "tests/test_qt_test_cleanup.py",
                "tests/test_workspace_lifetime.py",
                "tests/test_gui_backend_discovery.py",
                "tests/test_cpu_backend_isolation.py",
                "tests/test_virtual_electron_dock.py")),
            "field-ui/FU-04": ("In-place actual hardware bindings and transactional edits", (
                "tests/test_stigmator_hardware.py",
                "tests/test_hardware_tuning_bindings.py", "tests/test_hardware_tuning_gui.py",
                "tests/test_hardware_tuning_feedback.py", "tests/test_corrector_channel_gui.py",
                "tests/test_corrector_parameter_validation.py")),
            "field-ui/FU-05": ("Captured magnetic identities and equivalent deflector reference response", (
                "tests/test_magnetic_field_identity.py",)),
            "field-ui/FU-06": ("Explicit diagnostic retry and rejection of late failure signals", (
                "tests/test_electron_failure_gui.py",)),
            "field-ui/FU-07": ("Historical sessions and centralized diagnostic record ownership", (
                "tests/test_electron_session_gui.py", "tests/test_diagnostic_electron_record.py")),
            "field-ui/FU-08": ("Explicit assembly selection, configuration and working-point restoration", (
                "tests/test_assembly_selection_state.py", "tests/test_assembly_navigation.py",
                "tests/test_instrument_configuration.py", "tests/test_working_point_restore_gui.py")),
            "field-ui/FU-09": ("Captured-optics selected-Z conjugacy and latest cached plane readout", (
                "tests/test_selected_plane.py", "tests/test_selected_plane_gui.py",
                "tests/test_conjugate_planes.py", "tests/test_conjugate_plane_gui.py",
                "tests/test_conjugate_plane_workspace.py")),
            "field-ui/FU-11": ("Selected-plane upstream hardware projections, recorded interceptions and beam views", (
                "tests/test_plane_hardware_geometry.py", "tests/test_plane_hardware_overlay.py",
                "tests/test_plane_cutoff_events.py", "tests/test_lazy_ray_panels.py",
                "tests/test_ray_extent_workspace.py", "tests/test_incremental_ray_scene.py",
                "tests/test_beam_analysis_modes.py", "tests/test_transverse_source_tracking.py",
                "tests/test_beam_spot_gui.py", "tests/test_beam_plane_data.py",
                "tests/test_filter_plane_analysis.py", "tests/test_ray_flight_time_colours.py",
                "tests/test_transverse_plot_sizes.py", "tests/test_transverse_plot_size_persistence.py")),
            "field-ui/FU-10": ("Tip controls, coherent sessions and continuous latest-Z interaction", (
                "tests/test_coherent_beam_gui.py", "tests/test_shared_tip_workflow.py",
                "tests/test_electron_beam_observation.py", "tests/test_wave_beam_analysis.py",
                "tests/test_wavefront_comparison_gui.py",
                "tests/test_coherent_state_list.py", "tests/test_coherent_state_controller.py",
                "tests/test_coherent_state_set.py",
                "tests/test_tip_source_gui.py", "tests/test_beam_comparison.py",
                "tests/test_particle_energy_handoff.py")),
            "field-ui/FU-12": ("Shared filter mechanics, assembled 3D geometry and workspace views", (
                "tests/test_energy_filter_mechanical_clipping.py", "tests/test_energy_filter_model_3d.py",
                "tests/test_energy_filter_workspace_views.py")),
            "field-ui/FU-13": ("Settled live edits and latest particle frame gate coherent refresh", (
                "tests/test_live_beam_refresh.py", "tests/test_calculation_progress.py",
                "tests/test_calculation_progress_gui.py")),
            "field-ui/FU-14": ("Physical assembly sections, vacuum services and bounded workspace presentation", (
                "tests/test_assembly_section.py", "tests/test_assembly_section_page.py",
                "tests/test_current_page_tabs.py", "tests/test_ray_compact_layout.py",
                "tests/test_vacuum_pumping.py", "tests/test_vacuum_pumping_gui.py",
                "tests/test_vacuum_pumping_overlay.py")),
            "field-ui/FU-15": ("Fixed-magnitude signed CM modes and bounded combined-field scan design", (
                "tests/test_mini_condenser_modes.py", "tests/test_assembly_illumination.py",
                "tests/test_condenser_objective_design.py", "tests/test_scan_coil_design.py",
                "tests/test_condenser_scan_design_gui.py", "tests/test_finite_scan_response.py",
                "tests/test_projector_mode_switch.py", "tests/test_nanoprobe_range_gui.py",
                "tests/test_descan_phase_space.py", "tests/test_descan_phase_integration.py",
                "tests/test_descan_study_protocol.py", "tests/test_operating_mode_input_archive.py")),
            "field-ui/FU-16": ("Declared corrector winding ownership, geometry and edit persistence", (
                "tests/test_corrector_deflector_coils.py", "tests/test_corrector_hardware_editing.py")),
            "field-ui/FU-17": ("Explicit reference-plane steering and captured actual-probe diagnostics", (
                "tests/test_beam_steering_gui.py", "tests/test_actual_probe_diagnostics.py")),
            "field-ui/FU-18": ("Analytic CAD construction and native display/export lifecycle", (
                "tests/test_objective_electronics_sleeves.py",
                "tests/test_cad_round_lenses.py", "tests/test_cad_multipoles.py",
                "tests/test_cad_auxiliary.py", "tests/test_cad_export_gui.py",
                "tests/test_gun_model_details.py", "tests/test_cad_recording_planes.py",
                "tests/test_column_model_audit.py",
                "tests/test_internal_detail_contract.py",
                "tests/test_gun_stigmator_geometry.py", "tests/test_cad_condenser_cartridge.py",
                "tests/test_continuous_tube_bore_contract.py",
                "tests/test_c2_aperture_support.py", "tests/test_condenser_stigmator_support.py",
                "tests/test_cad_c3_lens_hardware.py",
                "tests/test_c3_aperture_support.py", "tests/test_beam_deflector_registration.py",
                "tests/test_cad_adapter_lens_hardware.py",
                "tests/test_dph2_end_insulation.py", "tests/test_probe_hexapole_support.py",
                "tests/test_cad_tl22_lens_hardware.py",
                "tests/test_cad_probe_transfer_lens_hardware.py",
                "tests/test_ac_scan_structure.py", "tests/test_cad_objective_upper_hardware.py",
                "tests/test_objective_upper_integration.py",
                "tests/test_probe_hp1_support.py", "tests/test_probe_lower_deflector_details.py",
                "tests/test_copied_axial_dimension_sync.py",
                "tests/test_compare_cad_assembly.py", "tests/test_cad_stage_holder.py",
                "tests/test_stage_holder_manifest.py", "tests/test_export_resolved_cad_assembly.py",
                "tests/test_cad_vacuum_tube.py", "tests/test_cad_detectors.py",
                "tests/test_cad_editing_contract.py", "tests/test_cad_optical_binding.py",
                "tests/test_step_editing.py", "tests/test_step_import_gui.py",
                "tests/test_cad_assembly_edit.py", "tests/test_component_datums.py",
                "tests/test_ray_marker_pose_sync.py")),
            "field-ui/FU-19": ("CETCOR/B-COR identity, assembly and common-coordinate diagnostics", (
                  "tests/test_image_corrector_topology.py", "tests/test_image_corrector_channel_hardware.py",
                  "tests/test_bcor_runtime.py", "tests/test_bcor_hardware.py", "tests/test_bcor_selection.py",
                  "tests/test_bcor_nanoprobe_modes.py", "tests/test_bcor_nanoprobe_integration.py")),
            "field-ui/FU-20": ("GPU and CPU retained CAD rendering, selection and optical material filter", (
                "tests/test_assembly_optical_visibility.py", "tests/test_assembly_optical_view.py",
                "tests/test_part_model_view_performance.py", "tests/test_mesh_annotation_performance.py",
                "tests/test_part_model_gpu_view.py",
                "tests/test_part_model_view.py", "tests/test_physical_layout_modes.py")),
            "field-ui/FU-21": ("Physical coil supports, hexapole structure and atomic geometry edits", (
                "tests/test_deflector_support_geometry.py", "tests/test_ordinary_deflector_structure.py",
                "tests/test_probe_hexapole_geometry.py", "tests/test_probe_hexapole_document_validation.py",
                "tests/test_deflector_winding_length_contract.py", "tests/test_pole_face_land_geometry.py",
                "tests/test_component_replacement_recipes.py", "tests/test_dimension_edit_policy.py",
                "tests/test_envelope_dimension_policy.py", "tests/test_manifest_dimension_bindings.py",
                "tests/test_mechanical_dimension_bindings.py", "tests/test_mechanical_overlap_async.py",
                "tests/test_mechanical_overlap_editor.py")),
            "field-ui/FU-22": ("Complete recording observation and current field-value tooltips", (
                "tests/test_recording_field_observation.py", "tests/test_field_tooltip_lifecycle.py")),
        },
    },
    "cad-export": {
        "description": "Optional isolated OpenCascade STEP export and round-trip",
        "evidence_kind": "analytic-solid-and-step-metadata-round-trip",
        "criteria": {
            "cad-export/CAD-01": ("Analytic primitives, editable solids, material labels and placements", (
                "tests/test_cad_step.py", "tests/test_cad_assembly_validation.py",
                "tests/test_cad_kernel.py")),
        },
    },
    "lens-geometry": {
        "description": "Captured lens placement, rigid field registration and physical interception",
        "evidence_kind": "bounded-numerical-and-offscreen-geometry-checks",
        "criteria": {
            "lens-geometry/LG-01": ("Physical lens placement survives capture and renders consistently", (
                "tests/test_lens_pose_capture.py", "tests/test_lens_pose_rendering.py")),
            "lens-geometry/LG-02": ("Posed field registration, transport and mechanical interception", (
                "tests/test_lens_pose_clipping.py", "tests/test_lens_pose_transport.py",
                "tests/test_rigid_lens_field_registration.py")),
            "lens-geometry/LG-03": ("Assembled material sections and linear/nonlinear FEM coordinates", (
                "tests/test_material_interval_validation.py", "tests/test_nonlinear_magnetostatics.py")),
            "lens-geometry/LG-04": ("Retained native potentials, immutable source coverage and explicit validity domains", (
                "tests/test_axisymmetric_potential.py", "tests/test_electric_potential_snapshot.py",
                "tests/test_analytic_potential.py", "tests/test_potential_snapshot.py",
                "tests/test_potential_capture.py", "tests/test_potential_fem_qualification.py",
                "tests/test_analytic_potential_domain.py", "tests/test_gun_magnetic_potential.py",
                "tests/test_potential_capabilities.py", "tests/test_potential_native_sampler.py",
                "tests/test_potential_plane_sampler.py")),
            "lens-geometry/LG-05": ("Independent high-order round-lens fields and natural aberration benchmarks", (
                "tests/test_high_order_round_lens.py", "tests/test_round_lens_aberration_benchmark.py",
                "tests/test_regular_axisymmetric_magnetic_potential.py", "tests/test_potential_fem_aberrations.py")),
            "lens-geometry/LG-06": ("Bounded potential wave operator, gauge covariance and flux accounting", (
                "tests/test_potential_wave.py", "tests/test_potential_wave_mode.py",
                "tests/test_potential_wave_carrier.py", "tests/test_potential_wave_carrier_reference.py",
                "tests/test_potential_wave_support.py", "tests/test_potential_phase_budget.py")),
            "lens-geometry/LG-07": ("Shared-potential Lorentz rays, static electric energy and explicit stop losses", (
                "tests/test_potential_ray.py", "tests/test_potential_aberrations.py")),
            "lens-geometry/LG-08": ("Explicit thin optical events, seven-column ownership and resume boundaries", (
                "tests/test_thin_optics.py", "tests/test_thin_direct_alignment.py",
                "tests/test_thin_specimen_transport.py")),
            "lens-geometry/LG-09": ("Controlled C3 and Probe potential pilots and existing checkpoint/readout bridges", (
                "tests/test_potential_probe_pilot.py", "tests/test_potential_probe_wave_pilot.py",
                "tests/test_potential_wave_observation.py")),
            "lens-geometry/LG-10": ("Qualified quadratic field interval reductions with explicit support and ownership", (
                "tests/test_qualified_field_reduction.py", "tests/test_bounded_optical_design.py")),
            "lens-geometry/LG-11": ("Finite mechanical boundaries and actual conditional material-to-detector handoff", (
                "tests/test_potential_geometry.py", "tests/test_potential_support_lineage.py",
                "tests/test_potential_material_phase_budget.py",
                "tests/test_potential_specimen_transport.py", "tests/test_potential_field_vector_scene.py")),
            "lens-geometry/LG-12": ("GUI-routed shared potentials, actual-source execution and explicit support gates", (
                "tests/test_finite_field_operating_defaults.py",
                "tests/test_unified_field_runtime.py", "tests/test_unified_field_particle.py",
                "tests/test_unified_gun_exit.py",
                "tests/test_unified_beam_path_audit.py",
                "tests/test_finite_field_nanoprobe_qualification.py",
                "tests/test_finite_field_probe_size_gate.py",
                "tests/test_electric_potential_acceleration.py",
                "tests/test_finite_waist_regions.py", "tests/test_finite_region_consumers.py",
                "tests/test_pupil_acceptance.py", "tests/test_gun_diagnostic_rays.py",
                "tests/test_crossover_acceptance.py",
                "tests/test_gun_exact_observations.py", "tests/test_particle_count_convergence.py",
                "tests/test_downstream_crossovers.py",
                "tests/test_unified_particle_optimization.py", "tests/test_unified_particle_prefix.py",
                "tests/test_unified_scan_response_cache.py", "tests/test_unified_scan_persistence.py",
                "tests/test_unified_scan_parallel.py", "tests/test_unified_surface_probe_focus.py",
                "tests/test_unified_projected_stem.py", "tests/test_unified_projected_downstream.py",
                "tests/test_unified_projected_trajectory_reuse.py",
                "tests/test_unified_stem_workflow.py",
                "tests/test_unified_wave_runtime.py", "tests/test_unified_direct_alignment.py",
                "tests/test_unified_scan_calibration.py", "tests/test_unified_scan_controls.py",
                "tests/test_scan_calibration_background.py",
                "tests/test_dynamic_potential.py",
                "tests/test_electric_wave_reference.py", "tests/test_retarded_wave.py",
                "tests/test_gaussian_remote_domain.py", "tests/test_potential_wave_carrier_fft.py",
                "tests/test_potential_wave_action_factorization.py",
                "tests/test_potential_axial_resource_retry.py",
                "tests/test_canonical_chart_resources.py",
                "tests/test_potential_wave_boundary_windows.py",
                "tests/test_potential_wave_spatial_pressure.py",
                "tests/test_residual_exponential_allowance.py",
                "tests/test_exploratory_column_budgets.py",
                "tests/test_exploratory_budget_controls.py",
                "tests/test_immutable_wave_checks.py",
                "tests/test_potential_segment_resampling.py",
                "tests/test_preview_segment_resampling.py",
                "tests/test_preview_segment_resampling_gui.py",
                "tests/test_preview_segment_carrier.py",
                "tests/test_potential_kinetic_expansion.py", "tests/test_potential_wave_device.py",
                "tests/test_potential_wave_chebyshev.py", "tests/test_potential_wave_carrier_chebyshev.py",
                "tests/test_potential_wave_policy.py", "tests/test_potential_wave_resampling.py",
                "tests/test_potential_wave_residual_memory.py",
                "tests/test_potential_wave_coefficient_memory.py",
                "tests/test_captured_phi_reuse.py",
                "tests/test_potential_representation_estimates.py",
                "tests/test_phase_segment_resampling.py",
                "tests/test_preview_phase_carrier.py",
                "tests/test_preview_phase_reselection.py",
                "tests/test_preview_phase_reselection_gui.py",
                "tests/test_nominal_energy_source.py",
                "tests/test_nominal_energy_preview_pipeline.py",
                "tests/test_nominal_energy_preview_gui.py",
                "tests/test_potential_wave_chebyshev_memory.py",
                "tests/test_wave_resource_preparation.py",
                "tests/test_wave_device_reuse.py",
                "tests/test_unified_exploratory_preview.py",
                "tests/test_coherent_result_labels.py",
                "tests/test_completed_wave_planes.py",
                "tests/test_potential_weighted_resampling.py", "tests/test_potential_column_segments.py",
                "tests/test_unified_weighted_resampling.py", "tests/test_coherent_weighted_resampling_gui.py")),
        },
    },
    "probe-diagnostics": {
        "description": "Bounded joint-probe search, field audit and native-waist evidence contracts",
        "evidence_kind": "synthetic-and-mocked-probe-diagnostics-not-optical-qualification",
        "criteria": {
            "probe-diagnostics/PD-01": ("Physical control proposals and independent native-waist evidence", (
                "tests/test_joint_probe_field_audit.py", "tests/test_joint_probe_solver.py",
                "tests/test_validate_joint_probe.py", "tests/test_measure_probe_waist.py",
                "tests/test_probe_waist_solver.py")),
        },
    },
    "instrument-regressions": {
        "description": "FEG geometry, coupled controls and hybrid calculation regressions",
        "evidence_kind": "geometry-operator-and-software-contracts",
        "criteria": {
            "instrument-regressions/IR-01": ("Physical gun, shared coil limits, pose and request handling", (
                "tests/test_feg_geometry.py", "tests/test_ac_dp12_shared_limits.py",
                "tests/test_column_azimuth.py", "tests/test_high_accuracy_step_policy.py",
                "tests/test_unified_sampled_history.py", "tests/test_tuning_source_budget.py")),
            "instrument-regressions/IR-02": ("Probe response, beam statistics and assembly studies", (
                "tests/test_assembly_error_study.py", "tests/test_assembly_error_study_gui.py",
                "tests/test_beam_quantile_boundary.py", "tests/test_crossover_aberrations.py",
                "tests/test_joint_probe_search.py", "tests/test_joint_si110_angular_screen.py",
                "tests/test_physical_a5_calibration.py", "tests/test_probe_baseline_reproduction.py",
                "tests/test_probe_channel_response.py", "tests/test_probe_service.py")),
            "instrument-regressions/IR-03": ("Hybrid admission, diffraction and projected specimen density", (
                "tests/test_hybrid_exit.py", "tests/test_hybrid_pipeline.py",
                "tests/test_hybrid_semiclassical.py", "tests/test_projected_gaussian_density.py")),
        },
    },
    "column-field-pilot": {
        "description": "Actual static C3 and Probe canonical response qualification",
        "evidence_kind": "controlled-canonical-pupil-and-frozen-field-convergence",
        "criteria": {
            "column-field-pilot/CF-01": ("Independent field, energy and trajectory refinement with physical drive responses", (
                "tests/test_potential_probe_canonical.py",)),
        },
    },
    "column-wave-qualification": {
        "description": "Long controlled full-interval coherent C3 and Probe qualification",
        "evidence_kind": "controlled-complex-wave-window-step-and-response-convergence",
        "criteria": {
            "column-wave-qualification/CW-01": ("Full Normal and Large Angle static wave paths and raw phase responses", (
                "tests/test_potential_probe_whole_wave.py",)),
        },
    },
    "receiver-imaging": {
        "description": "Physical screen and Camera imaging, scan capture and playback",
        "evidence_kind": "bounded-particle-and-offscreen-receiver-checks",
        "criteria": {
            "receiver-imaging/RI-01": ("Receiver signals and scans retain their executed upstream inputs", (
                "tests/test_receiver_image.py", "tests/test_receiver_scan.py",
                "tests/test_receiver_scan_link.py", "tests/test_receiver_transport_integration.py")),
            "receiver-imaging/RI-02": ("Receiver controls, immutable captured scans and playback lifecycle", (
                "tests/test_receiver_imaging_gui.py", "tests/test_receiver_playback_gui.py")),
            "receiver-imaging/RI-03": ("Pixel-integrated receiver response and convergence evidence contracts", (
                "tests/test_compact_gaussian_response.py", "tests/test_image_intensity_analysis.py",
                "tests/test_image_intensity_validation.py", "tests/test_gaussian_pixel_response.py")),
            "receiver-imaging/RI-04": ("Physical receiver conjugacy and transactional asynchronous projection", (
                "tests/test_image_receiver_focus.py", "tests/test_projector_preset_controller.py",
                "tests/test_equivalent_image_energy.py")),
        },
    },
    "particle-continuation": {
        "description": "Executed classical checkpoints, material reuse and exact result archives",
        "evidence_kind": "software-and-bounded-particle-persistence-checks",
        "criteria": {
            "particle-continuation/PC-01": ("Executed optical checkpoints and full-calculation continuation", (
                "tests/test_particle_sections.py", "tests/test_completed_particle_sections.py")),
            "particle-continuation/PC-02": ("Material continuation with incident-state dependency checks", (
                "tests/test_material_particle_sections.py", "tests/test_material_section_resume.py",
                "tests/test_particle_section_eds_reuse.py")),
            "particle-continuation/PC-03": ("Exact saved records and lossless compact continuation", (
                "tests/test_particle_section_io.py", "tests/test_particle_archive_compression.py",
                "tests/test_particle_section_eds_archive.py")),
            "particle-continuation/PC-04": ("Archive identity and latest file-request ownership", (
                "tests/test_section_archive_identity.py", "tests/test_result_file_request_routing.py",
                "tests/test_result_files_gui.py", "tests/test_automatic_result.py",
                "tests/test_automatic_result_worker.py", "tests/test_automatic_result_gui.py")),
            "particle-continuation/PC-05": ("Specimen downstream handoff, branch weights and executed flight times", (
                "tests/test_downstream_transport.py", "tests/test_specimen_time_of_flight.py",
                "tests/test_objective_chromatic_kick.py", "tests/test_shared_chromatic_screens.py")),
            "particle-continuation/PC-06": ("Measured corrector waists, nonlinear source correction and current preset seeds", (
                "tests/test_corrector_crossover_measurement.py",
                "tests/test_probe_corrector_calibration.py", "tests/test_direct_alignment_precalibration.py",
                "tests/test_surface_probe_focus.py")),
            "particle-continuation/PC-07": ("Bound corrector finite dipoles and independent response reference", (
                "tests/test_corrector_deflector_binding.py", "tests/test_corrector_deflector_validation.py")),
            "particle-continuation/PC-08": ("DPH changes the centered HP response in parameterised optics", (
                "tests/test_dph_aberration_response.py", "tests/test_corrector_aberration_events.py")),
            "particle-continuation/PC-09": ("Finite entrance-pair local calibration and verified four-drive commit", (
                "tests/test_beam_steering_calibration.py",)),
            "particle-continuation/PC-10": ("Normal and Large-angle Nanoprobe topology, mode persistence and independent focus acceptance", (
                "tests/test_condenser_topology.py", "tests/test_nanoprobe_topology_alignment.py",
                "tests/test_direct_focus_topology.py",
                "tests/test_validate_nanoprobe_condenser.py", "tests/test_nanoprobe_ranges.py",
                "tests/test_bcor_nanoprobe_integration.py", "tests/test_supplemental_crossover.py")),
            "particle-continuation/PC-11": ("Shared physical scene, effect ownership and seven-column numerical compatibility", (
                "tests/test_physical_scene.py", "tests/test_interaction_registry.py",
                "tests/test_plan_physics_contract.py", "tests/test_physics_contract_persistence.py")),
        },
    },
    "performance-observation": {
        "description": "Opt-in performance receipts and bounded benchmark admissions",
        "evidence_kind": "software-measurement-contract-checks-not-performance-qualification",
        "criteria": {
            "performance-observation/PO-01": ("Actual child execution observations preserve unprofiled results", (
                "tests/test_electron_execution_performance.py",)),
            "performance-observation/PO-02": ("Declared diagnostic cases, reference checks and executed-result reuse", (
                "tests/test_electron_response_benchmark.py",)),
            "performance-observation/PO-03": ("Input-to-painted-result latency and exact GUI cache accounting", (
                "tests/test_continuous_electron_response_benchmark.py",)),
            "performance-observation/PO-04": ("Particle identity, executed prefixes and bounded benchmark ownership", (
                "tests/test_particle_benchmark.py",)),
            "performance-observation/PO-05": ("Retained-plane accuracy, reproducible benchmarks and resumable experiment records", (
                "tests/test_performance_accuracy.py", "tests/test_benchmark_suite.py",
                "tests/test_benchmark_comparison.py", "tests/test_experiment_cli.py")),
        },
    },
    "acceptance-policy": {
        "description": "Declared acceptance scopes and bounded fail-closed evidence collection",
        "evidence_kind": "synthetic-and-real-child-software-policy-checks",
        "criteria": {
            "acceptance-policy/AP-01": ("Explicit scope selection and complete mandatory receipts", (
                "tests/test_acceptance_scopes.py",)),
            "acceptance-policy/AP-02": ("Runner records failures, missing tests, empty collection and timeout", (
                "tests/test_acceptance_runner.py",)),
            "acceptance-policy/AP-03": ("Bounded owned process cleanup and explicit cleanup failure", (
                "tests/test_validation_process.py",)),
            "acceptance-policy/AP-04": ("Installer compatibility, environment ownership and offline wheel resolution", (
                "tests/test_setup_env.py",)),
        },
    },
    "coherent-development": {
        "description": "Bounded tip-only coherent inputs and exact post-gun observation workflow",
        "evidence_kind": "development-operators-and-offscreen-software-checks-not-full-chain-qualification",
        "criteria": {
            "coherent-development/CW-01": ("Explicit tip boundary, domain preflight and preserved source inputs", (
                "tests/test_coherent_inputs.py", "tests/test_tip_coherent_emission.py",
                "tests/test_shared_tip_workflow.py", "tests/test_shared_surface_source.py",
                "tests/test_surface_wave_integration.py", "tests/test_radial_phase_fem.py")),
            "coherent-development/CW-02": ("Executed upstream waves, exact plane routing and physical absorption", (
                "tests/test_tip_wave_pipeline.py", "tests/test_column_wave_transport.py", "tests/test_scan_preparation.py",
                "tests/test_first_order_column_reference.py", "tests/test_ideal_reference_pipeline.py",
                "tests/test_wave_checkpoint_publication.py",
                "tests/test_plane_wave_storage.py", "tests/test_radial_device_residency.py",
                "tests/test_column_wave_electric.py", "tests/test_tip_gun_wave.py",
                "tests/test_electrostatic_column_transport.py", "tests/test_wave_grid.py", "tests/test_wave_device.py",
                "tests/test_wave_support.py", "tests/test_column_support_budget.py",
                "tests/test_wave_domain_support.py",
                "tests/test_column_acceptance_window.py", "tests/test_acceptance_aperture_sampling.py", "tests/test_wave_aperture_edge.py",
                "tests/test_wave_aperture_sampling.py", "tests/test_multipole_wave.py",
                "tests/test_wave_grid_low_memory.py", "tests/test_phase_carrier_moments.py",
                "tests/test_corrector_memory_integration.py",
                "tests/test_cpu_angular_spectrum.py",
                "tests/test_cartesian_radial_handoff.py", "tests/test_radial_cartesian_handoff.py",
                "tests/test_cartesian_round_route.py",
                "tests/test_round_column_electric.py",
                "tests/test_round_column_checkpoint.py", "tests/test_radial_memory_budget.py",
                "tests/test_radial_fftlog.py", "tests/test_radial_column_wave.py",
                "tests/test_tip_gun_shared_fields.py", "tests/test_canonical_action.py")),
            "coherent-development/CW-06": ("Driven near-tip boundary and gun continuation; not full microscope qualification", (
                "tests/test_planar_tip_boundary.py", "tests/test_driven_tip_gun.py",
                "tests/test_gun_output_sampling.py", "tests/test_accelerating_tip_sampling.py")),
            "coherent-development/CW-03": ("Captured wave sessions, latest Z, resource ownership and bounded display", (
                "tests/test_coherent_beam_gui.py", "tests/test_beam_comparison.py",
                "tests/test_wave_read_session.py",
                "tests/test_electron_detection.py", "tests/test_electron_beam_observation.py",
                "tests/test_wave_beam_analysis.py", "tests/test_wave_plane_observables.py",
                "tests/test_wavefront_comparison.py", "tests/test_wavefront_comparison_gui.py",
                "tests/test_coherent_state_list.py", "tests/test_coherent_state_controller.py",
                "tests/test_coherent_state_set.py")),
            "coherent-development/CW-04": ("Vacuum electrostatic boundaries do not depend on prescribed source phase", (
                "tests/test_planar_gun_field.py",)),
            "coherent-development/CW-05": ("Conditional material waves, exact deterministic reuse and slice continuation", (
                "tests/test_inelastic_wave.py", "tests/test_galerkin_potential.py", "tests/test_galerkin_specimen.py")),
            "coherent-development/CW-07": ("Shared device policy and bounded local TEM/STEM operators", (
                "tests/test_multislice.py", "tests/test_wave_fft.py", "tests/test_tem_flux_contract.py",
                "tests/test_stem_cuda_pipeline.py", "tests/test_gpu_capture_contract.py",
                "tests/test_execution_migration_contract.py")),
            "coherent-development/CW-08": ("Posed main-column fields, finite aperture absorption and matched ray/wave checkpoints", (
                "tests/test_posed_lens_wave.py", "tests/test_posed_wave_hardware.py",
                "tests/test_tilted_column_wave.py", "tests/test_wave_magnetic_residual.py",
                "tests/test_main_column_pose.py", "tests/test_dpa_plate_thickness.py", "tests/test_posed_column_fields.py",
                "tests/test_direct_alignment_pose.py",
                "tests/test_posed_multipole_wave.py", "tests/test_tilted_multipole_column.py",
                "tests/test_posed_wave_aperture.py", "tests/test_tilted_aperture_column.py",
                "tests/test_posed_aberration_wave.py", "tests/test_tilted_spherical_column.py")),
            "coherent-development/CW-09": ("Lens intrinsic actions share ray/wave definitions and preserve checkpoint ownership", (
                "tests/test_intrinsic_aberration_operator.py",
                "tests/test_chromatic_column_wave.py",
                "tests/test_intrinsic_aberration_integration.py",
                "tests/test_intrinsic_ray_device.py",
                "tests/test_particle_gpu_reference.py",
                "tests/test_intrinsic_gpu_segments.py",
                "tests/test_intrinsic_particle_backend.py",
                "tests/test_intrinsic_archive_radial.py",
                "tests/test_intrinsic_legacy_boundaries.py",
                "tests/test_lens_aberration_editor.py",
                "tests/test_system_residual_aberrations.py")),
            "coherent-development/CW-10": ("B-COR third-hexapole shared action and real CPU/CUDA parity", (
                "tests/test_bcor_propagation.py",)),
            "coherent-development/CW-11": ("Experimental Gaussian packet operators and bounded readout; not production or full-chain qualification", (
                "tests/test_experimental_gaussian_beamlets.py",
                "tests/test_gaussian_quadratic_paths.py",
                "tests/test_gaussian_precision_validation.py",
                "tests/test_experimental_gaussian_gram.py",)),
            "coherent-development/CW-12": ("Local physical A1/A2 channels, finite hexapole thickness and retained wave phase", (
                "tests/test_corrector_channels.py", "tests/test_hexapole_thickness_response.py",
                "tests/test_corrector_channel_wave_transport.py",)),
        },
    },
}


def _scope_definition(scope: str) -> dict:
    try:
        return ACCEPTANCE_SCOPES[scope]
    except KeyError:
        raise ValueError(f"Unknown acceptance scope: {scope}") from None


def scope_test_files(scope: str) -> tuple[str, ...]:
    """Return complete test files for one declared scope; never infer a lane."""
    criteria = _scope_definition(scope)["criteria"]
    return tuple(sorted({path for _, paths in criteria.values() for path in paths}))


def merge_criteria(*groups):
    result = {}
    for group in groups:
        for key, value in group.items():
            if "/" not in key or key in result:
                raise ValueError(f"Missing namespace or duplicate criterion: {key}")
            result[key] = value
    return result


def software_report(receipt, *, pytest_exit_code, source_unchanged,
                    scope="classical", selected=None, criteria=None,
                    allow_gpu_skips=False):
    """Require complete CPU evidence and explicitly report real-device gaps.

    The allowlist is a scope contract, not inferred from whichever tests happened
    to run. Unknown/omitted files, deselection, duplicates and empty collection
    fail closed. With ``allow_gpu_skips=True``, normal skips of reviewed actual
    GPU cases are NOT_RUN hardware evidence, not a CPU failure or a GPU pass.
    GPU failures and all other skips remain failures of this software scope.
    Synthetic receipts exercise this policy, not any physics.
    """
    definition = _scope_definition(scope)
    if criteria is None:
        criteria = definition["criteria"]
    if selected is None:
        selected = scope_test_files(scope)
    expected_files = {path for _, paths in criteria.values() for path in paths}
    selected = tuple(selected)
    errors = []
    if not isinstance(receipt, dict):
        errors.append("Invalid pytest receipt: expected an object")
        receipt = {}
    collected = receipt.get("collected", [])
    if not isinstance(collected, list) or not all(isinstance(node, str) for node in collected):
        errors.append("Invalid collected test IDs: expected a list of strings")
        collected = []
    cases = receipt.get("cases", {})
    if not isinstance(cases, dict):
        errors.append("Invalid test outcomes: expected an object")
        cases = {}
    else:
        valid_cases = {}
        for node, outcomes in cases.items():
            if not isinstance(node, str) or not isinstance(outcomes, dict) or not all(
                    isinstance(phase, str) and isinstance(outcome, str)
                    for phase, outcome in outcomes.items()):
                errors.append("Invalid test outcome entry: expected named phase outcomes")
                continue
            valid_cases[node] = outcomes
        cases = valid_cases
    deselected = receipt.get("deselected", [])
    if not isinstance(deselected, list) or not all(isinstance(node, str) for node in deselected):
        errors.append("Invalid deselected test IDs: expected a list of strings")
    if set(selected) != expected_files or len(selected) != len(set(selected)):
        errors.append("Selected tests differ from the declared scope")
    if receipt.get("complete") is not True:
        errors.append("Missing or interrupted pytest receipt")
    if deselected:
        errors.append("Tests were deselected")
    if any(n != 1 for n in Counter(collected).values()):
        errors.append("Duplicate collected test IDs")
    if any(node.split("::")[0] not in expected_files for node in collected):
        errors.append("Unknown test outside the declared scope")
    if set(cases) - set(collected):
        errors.append("Uncollected test outcomes")
    if not source_unchanged:
        errors.append("Source or input definitions changed during execution")
    if pytest_exit_code != 0:
        errors.append(f"pytest exited {pytest_exit_code}")
    skip_reasons = receipt.get("skip_reasons", {})
    if not isinstance(skip_reasons, dict) or not all(isinstance(node, str) and isinstance(reason, str)
                                                  for node, reason in skip_reasons.items()):
        errors.append("Invalid skip reasons: expected named text reasons")
        skip_reasons = {}
    gpu_cases = {node: cases.get(node, {}) for node in collected if is_gpu_hardware_test(node)}
    gpu_not_run = [node for node, outcomes in gpu_cases.items() if is_complete_skip(outcomes)]
    allowed_skips = {node for node in gpu_not_run if is_gpu_unavailable_reason(skip_reasons.get(node, ""))}
    if allow_gpu_skips is not True:
        allowed_skips.clear()
    rows = {}
    for key, (title, files) in criteria.items():
        nodes = [node for node in collected if node.split("::")[0] in files]
        missing = [path for path in files if not any(node.startswith(path + "::") for node in nodes)]
        status = "PASS"
        for node in nodes:
            outcomes = cases.get(node, {})
            if node in allowed_skips:
                continue
            if "failed" in outcomes.values():
                status = "FAIL"
                break
            if outcomes != {"setup": "passed", "call": "passed", "teardown": "passed"}:
                status = "NOT_RUN"
        if missing or not (set(nodes) - allowed_skips):
            status = "NOT_RUN" if status != "FAIL" else status
        rows[key] = {"description": title, "status": status, "tests": nodes,
                     "missing_files": missing, "gpu_not_run": sorted(set(nodes) & allowed_skips)}
    passed = not errors and bool(rows) and all(row["status"] == "PASS" for row in rows.values())
    return {
        "schema": ("classical-software-acceptance-v1" if scope == "classical"
                   else "scoped-software-acceptance-v1"),
        "scope": "classical-particle-software" if scope == "classical" else scope,
        "scope_key": scope, "description": definition["description"],
        "evidence_kind": definition["evidence_kind"],
        "software_scope_status": "PASS" if passed else "INCOMPLETE",
        "full_simulator_qualification": "UNQUALIFIED",
        "exit_code": 0 if passed else 1, "criteria": merge_criteria(rows), "errors": errors,
        "selected_tests": list(selected), "collected_count": len(set(collected)),
        "cases": cases, "source_unchanged_during_tests": source_unchanged,
        "pytest_exit_code": pytest_exit_code,
        "allow_gpu_skips": allow_gpu_skips is True,
        "allowed_gpu_skips": sorted(allowed_skips),
        "skip_reasons": skip_reasons,
        "gpu_hardware": {
            "status": ("FAIL" if any("failed" in value.values() for value in gpu_cases.values())
                       else "NOT_RUN" if not gpu_cases or gpu_not_run
                       else "EXECUTED" if all(value == {"setup": "passed", "call": "passed", "teardown": "passed"}
                                              for value in gpu_cases.values()) else "INCOMPLETE"),
            "not_run": gpu_not_run,
            "cases": gpu_cases,
            "note": "Only the collected hardware cases; never full GPU or microscope qualification.",
        },
        "exclusions": {
            "coherent-tip-to-image": "Development resumed; bounded operator and source-admission tests are not full image qualification",
            "actual-gpu-scientific-parity": "Full GPU qualification is outside this software lane; see gpu_hardware for executed cases. Emulated policy tests are not hardware evidence",
            "native-desktop": "Offscreen tests only",
            "experimental-calibration": "NOT_RUN; no OEM or experimental qualification",
            **({"round2/R2-AT-13..40": "Later packages are not selected by the R2-00..03 software lane"}
               if scope == "classical" else {}),
        },
    }
