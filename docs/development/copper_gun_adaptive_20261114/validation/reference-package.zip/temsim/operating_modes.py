"""Load and apply assembly-aware condenser/projector operating modes."""

from __future__ import annotations

from dataclasses import dataclass, field
import math
from pathlib import Path
from temsim import input_io
import tomllib

from temsim.paths import OPERATING_MODE_CONFIG_ROOT
from temsim.optics.excitation_policy import is_saturated_excitation


MINI_CONDENSER_MODE_CONTROL_SCHEMA = "signed_equal_magnitude_v1"


def is_nanoprobe_mode(key: str) -> bool:
    """Both Nanoprobe ranges use a focused probe and negative CM polarity."""
    return key in {"nano_probe", "nano_probe_large_angle"}


def has_two_condenser_hardware(state) -> bool:
    """C1+C2 hardware is distinct from an installed, switched-off C3."""
    return getattr(state, "layout_c3_hardware", "three_condenser") == "two_condenser"


def _operating_column_name(state, requested):
    if has_two_condenser_hardware(state):
        if requested not in (None, "C2"):
            raise ValueError("The installed two-condenser hardware requires the C2 operating reference")
        return "C2"
    if requested == "C2":
        raise ValueError("The C2 operating reference requires physical two-condenser hardware")
    return requested


def validate_nanoprobe_range(value: str) -> str:
    if value not in ("normal", "large_angle"):
        raise ValueError("Nanoprobe range must be normal or large_angle")
    return value


def condenser_mode_key(state) -> str:
    """Identify applied illumination, retaining range while in Microprobe.

    ``probe_mode`` is supported for existing lightweight observers; the live
    instrument uses illumination_mode and the separately persisted range.
    Unknown illumination remains unknown rather than implying Nanoprobe.
    """
    mode = str(getattr(state, "probe_mode", "")).lower()
    if mode not in {"micro_probe", "nano_probe", "nano_probe_large_angle"}:
        mode = {"TEM": "micro_probe", "STEM": "nano_probe"}.get(
            str(getattr(state, "illumination_mode", "")).upper(), "")
    if is_nanoprobe_mode(mode) and has_two_condenser_hardware(state):
        return "nano_probe"
    if mode == "nano_probe":
        selected = validate_nanoprobe_range(getattr(state, "nanoprobe_range", "normal"))
        return "nano_probe_large_angle" if selected == "large_angle" else mode
    return mode


def load_mini_condenser_default_excitation_percent(column_module: str | None = None) -> float:
    """Read an installation default, never an independent per-mode live value.

    Column overrides are keyed by resolved module path, not by a display name
    or the presence of any corrector. An unspecified column uses the historical
    baseline; operating-mode changes preserve the component's live magnitude.
    """
    path = OPERATING_MODE_CONFIG_ROOT / "catalog.toml"
    with input_io.open_input(path) as stream:
        control = tomllib.load(stream).get("mini_condenser_control", {})
    if control.get("schema") != MINI_CONDENSER_MODE_CONTROL_SCHEMA:
        raise ValueError(f"{path}: unsupported Mini Condenser control schema")
    overrides = control.get("column_startup_excitation_percent", {})
    if not isinstance(overrides, dict):
        raise ValueError(f"{path}: Mini Condenser column startup values must be a table")

    def validated(raw):
        if isinstance(raw, bool) or not isinstance(raw, (int, float)):
            raise ValueError(f"{path}: Mini Condenser default magnitude must be numeric")
        magnitude = float(raw)
        if not math.isfinite(magnitude) or not 0.0 < magnitude <= 100.0:
            raise ValueError(f"{path}: Mini Condenser default magnitude must be in (0, 100]")
        return magnitude

    baseline = validated(control.get("default_excitation_percent"))
    magnitudes = {key: validated(raw) for key, raw in overrides.items()}
    return magnitudes.get(column_module, baseline)


@dataclass(frozen=True)
class OperatingModeDefinition:
    key: str
    name: str
    family: str
    calibration_status: str
    compatible_columns: tuple[str, ...]
    compatible_recording_systems: tuple[str, ...]
    devices: dict[str, dict[str, object]]
    apertures: dict[str, dict[str, object]]
    targets: dict[str, object]
    calibration_reference: str


@dataclass(frozen=True)
class CrossoverConstraint:
    key: str
    upstream_lens: str
    downstream_lens: str
    target_z_source: str
    applies_to_modes: tuple[str, ...]
    status: str
    note: str


@dataclass(frozen=True)
class DirectAlignmentDefinition:
    """One user-level coupled adjustment backed by a live optical solve."""

    key: str
    name: str
    family: str
    mode_key: str
    unit: str
    minimum: float
    maximum: float
    default_value: float
    devices: tuple[str, ...]
    observable: str
    constraint: str
    calibration_status: str
    calibration_reference: str
    targets: dict[str, object]
    applies_to_modes: tuple[str, ...]
    state_parameters: tuple[str, ...]

    @property
    def definition_id(self) -> str:
        if self.observable == "sample_current_weighted_95_percent_semi_angle":
            return "chief-ray-current-contained-semiangle-95-v1"
        if self.observable == "sample_current_weighted_95_percent_diameter":
            return "chief-ray-current-contained-diameter-95-v1"
        return self.observable + "-v1"

    @property
    def active_mode_keys(self) -> tuple[str, ...]:
        return self.applies_to_modes or (self.mode_key,)


@dataclass(frozen=True)
class OperatingModeCatalog:
    modes: tuple[OperatingModeDefinition, ...]
    crossover_constraints: tuple[CrossoverConstraint, ...]
    direct_alignments: tuple[DirectAlignmentDefinition, ...]
    source_path: Path
    column_overrides: dict[str, dict[str, OperatingModeDefinition]] = field(default_factory=dict)


@dataclass(frozen=True)
class AppliedOperatingModes:
    condenser: OperatingModeDefinition
    projector: OperatingModeDefinition | None
    changed_devices: tuple[str, ...]
    image_projection: object | None = None

    @property
    def summary(self) -> str:
        convergence = self.condenser.targets.get(
            "achieved_convergence_sem_angle_mrad"
        )
        relay_um = (self.projector.targets.get("achieved_relay_error_um")
                    if self.projector and self.image_projection is None else None)
        details = []
        if convergence is not None:
            # Even a computed catalog entry describes its recorded working
            # point, not a new measurement of the user's current instrument.
            details.append(f"stored reference semi-angle {float(convergence):.3f} mrad")
        if relay_um is not None:
            details.append(f"stored reference conjugate residual {float(relay_um):.3f} µm")
        details.append(
            "condenser preset not recalculated for current controls, geometry or source model; "
            "edited working points require revalidation"
        )
        if self.image_projection is not None:
            details.append(self.image_projection.summary)
        suffix = "; ".join(details)
        return (
            (f"{self.condenser.name} + {self.projector.name}" if self.projector
             else f"{self.condenser.name} illumination; projection settings retained")
            + (f": {suffix}" if suffix else "")
        )


@dataclass(frozen=True)
class AppliedProjectorMode:
    projector: OperatingModeDefinition
    changed_devices: tuple[str, ...]
    image_projection: object | None = None

    @property
    def summary(self) -> str:
        if self.image_projection is not None:
            return (self.image_projection.summary + " Scan controls retained; use "
                    "Calibrate Descan (keep AC) for the new target optics.")
        return (f"Stored {self.projector.name} projector strengths applied. "
                "Current objective and recording-plane conjugacy are unqualified; "
                "no image focus or diffraction stability was recalculated. "
                "Scan controls retained; use Calibrate Descan (keep AC) to hold AC at the new target optics.")


@input_io.scoped_lru_cache(maxsize=8)
def load_operating_mode_catalog(simulation_mode: str | None = None) -> OperatingModeCatalog:
    """Load references for one field model without changing the live state.

    The default catalog retains historical calibration data. Model overrides
    merge device controls, but replace their entire target/qualification record
    so a new working point cannot inherit another model's measured claims.
    """
    path = OPERATING_MODE_CONFIG_ROOT / "catalog.toml"
    with input_io.open_input(path) as stream:
        document = tomllib.load(stream)
    if int(document.get("format_version", 0)) != 1:
        raise ValueError(f"{path}: unsupported operating-mode format")

    rows = document.get("modes", ())
    overrides = document.get("simulation_mode_overrides", {}).get(simulation_mode, {})
    known_keys = {str(item["key"]) for item in rows}
    if set(overrides) - known_keys:
        raise ValueError(f"{path}: simulation-model override references an unknown mode")
    resolved_rows = []
    for item in rows:
        override = overrides.get(str(item["key"]))
        if override is None:
            resolved_rows.append(item)
            continue
        allowed = {"devices", "targets", "calibration_status", "calibration_reference"}
        required = {"targets", "calibration_status", "calibration_reference"}
        if not isinstance(override, dict) or set(override) - allowed or not required <= set(override):
            raise ValueError(f"{path}: model override requires its own qualification record")
        devices = {key: dict(values) for key, values in item.get("devices", {}).items()}
        for key, values in override.get("devices", {}).items():
            if key not in devices:
                raise ValueError(f"{path}: model override references an unknown device {key!r}")
            devices[key].update(values)
        resolved_rows.append({**item, **override, "devices": devices})

    def definition(item):
        return OperatingModeDefinition(
            key=str(item["key"]),
            name=str(item["name"]),
            family=str(item["family"]),
            calibration_status=str(item["calibration_status"]),
            compatible_columns=tuple(
                str(value) for value in item["compatible_columns"]
            ),
            compatible_recording_systems=tuple(
                str(value)
                for value in item["compatible_recording_systems"]
            ),
            devices={
                str(key): dict(value)
                for key, value in item.get("devices", {}).items()
            },
            apertures={
                str(key): dict(value)
                for key, value in item.get("apertures", {}).items()
            },
            targets={
                str(key): value
                for key, value in item.get("targets", {}).items()
            },
            calibration_reference=str(
                item.get("calibration_reference", "")
            ),
        )

    modes = tuple(definition(item) for item in resolved_rows)
    mode_keys = [mode.key for mode in modes]
    if len(set(mode_keys)) != len(mode_keys):
        raise ValueError(f"{path}: duplicate operating-mode key")
    if {mode.family for mode in modes} - {"condenser", "projector"}:
        raise ValueError(f"{path}: unsupported operating-mode family")
    column_overrides = {}
    override_document = document.get("column_mode_overrides", {})
    if not isinstance(override_document, dict):
        raise ValueError(f"{path}: column mode overrides must be a table")
    base_rows = {str(item["key"]): item for item in resolved_rows}
    for column_name, column_rows in override_document.items():
        if not isinstance(column_rows, dict) or set(column_rows) - set(base_rows):
            raise ValueError(f"{path}: column override references an unknown operating mode")
        resolved = {}
        for key, override in column_rows.items():
            required = {"devices", "apertures", "targets", "calibration_status", "calibration_reference"}
            allowed = required | {"compatible_recording_systems", "name"}
            if not isinstance(override, dict) or set(override) - allowed or not required <= set(override):
                raise ValueError(f"{path}: column override requires its own complete controls and qualification record")
            for group in ("devices", "apertures", "targets"):
                if not isinstance(override[group], dict):
                    raise ValueError(f"{path}: column override {group} must be a table")
            if column_name == "C2":
                if key == "nano_probe_large_angle":
                    raise ValueError(f"{path}: two-condenser Nanoprobe has no Normal/Large angle branches")
                forbidden = {"condenser_lens_3", "adapter_lens"}
                if (forbidden.intersection(override["devices"])
                        or any(str(device).startswith("probe_") for device in override["devices"])
                        or "condenser_aperture_3" in override["apertures"]):
                    raise ValueError(f"{path}: C2 controls cannot reference absent C3 or probe-corrector hardware")
            # Entire tables replace the other assembly's controls and evidence.
            resolved[key] = definition({**base_rows[key], **override,
                                        "compatible_columns": [str(column_name)]})
        column_overrides[str(column_name)] = resolved
    definitions = (*modes, *(mode for values in column_overrides.values() for mode in values.values()))
    for mode in definitions:
        for key, values in mode.devices.items():
            if "percent" in values:
                percent = float(values["percent"])
                if not 0.0 <= percent <= 100.0:
                    raise ValueError(
                        f"{path}: {mode.key}.{key} exceeds 100%"
                    )
                if is_saturated_excitation(percent):
                    raise ValueError(
                        f"{path}: {mode.key}.{key} reaches 100%; enlarge "
                        "the lens maximum field and rebase the default into "
                        "the 30-70% operating window"
                    )
        for key, values in mode.apertures.items():
            if "radius_mm" in values:
                raise ValueError(
                    f"{path}: {mode.key}.{key} must use diameter_mm; "
                    "radius_mm is an internal legacy representation"
                )
            if "diameter_mm" not in values:
                raise ValueError(
                    f"{path}: {mode.key}.{key} must define diameter_mm"
                )
            if float(values["diameter_mm"]) <= 0.0:
                raise ValueError(
                    f"{path}: {mode.key}.{key}.diameter_mm must be positive"
                )

    constraints = tuple(
        CrossoverConstraint(
            key=str(item["key"]),
            upstream_lens=str(item["upstream_lens"]),
            downstream_lens=str(item["downstream_lens"]),
            target_z_source=str(item["target_z_source"]),
            applies_to_modes=tuple(
                str(value) for value in item.get("applies_to_modes", ())
            ),
            status=str(item.get("status", "pending")),
            note=str(item.get("note", "")),
        )
        for item in document.get("crossover_constraints", ())
    )
    known_modes = set(mode_keys)
    for constraint in constraints:
        unknown = set(constraint.applies_to_modes) - known_modes
        if unknown:
            raise ValueError(
                f"{path}: crossover {constraint.key} references unknown modes"
            )

    direct_alignments = tuple(
        DirectAlignmentDefinition(
            key=str(item["key"]),
            name=str(item["name"]),
            family=str(item["family"]),
            mode_key=str(item["mode_key"]),
            unit=str(item["unit"]),
            minimum=float(item["minimum"]),
            maximum=float(item["maximum"]),
            default_value=float(item["default_value"]),
            devices=tuple(str(value) for value in item["devices"]),
            observable=str(item["observable"]),
            constraint=str(item["constraint"]),
            calibration_status=str(item["calibration_status"]),
            calibration_reference=str(item["calibration_reference"]),
            targets={
                str(key): value
                for key, value in item.get("targets", {}).items()
            },
            applies_to_modes=tuple(
                str(value)
                for value in item.get("applies_to_modes", ())
            ),
            state_parameters=tuple(
                str(value)
                for value in item.get("state_parameters", ())
            ),
        )
        for item in document.get("direct_alignments", ())
    )
    direct_keys = [definition.key for definition in direct_alignments]
    if len(set(direct_keys)) != len(direct_keys):
        raise ValueError(f"{path}: duplicate direct-alignment key")
    expected_direct_keys = {
        "nanoprobe_convergence",
        "microprobe_illumination",
        "image_magnification",
        "diffraction_camera_length",
    }
    if set(direct_keys) != expected_direct_keys:
        raise ValueError(
            f"{path}: direct alignments must define exactly "
            + ", ".join(sorted(expected_direct_keys))
        )
    expected_devices = {
        "nanoprobe_convergence": (
            "condenser_lens_2", "condenser_lens_3",
        ),
        "microprobe_illumination": (
            "condenser_lens_2", "condenser_lens_3",
        ),
        "image_magnification": (
            "objective_lens", "diffraction_lens", "intermediate_lens",
            "projector_lens_1", "projector_lens_2",
        ),
        "diffraction_camera_length": (
            "diffraction_lens", "intermediate_lens",
            "projector_lens_1", "projector_lens_2",
        ),
    }
    expected_state_parameters = {
        "nanoprobe_convergence": (),
        "microprobe_illumination": (),
        "image_magnification": (),
        "diffraction_camera_length": (),
    }
    for definition in direct_alignments:
        if definition.family not in {"condenser", "projector"}:
            raise ValueError(
                f"{path}: {definition.key} has unsupported family"
            )
        if definition.mode_key not in known_modes:
            raise ValueError(
                f"{path}: {definition.key} references unknown mode "
                f"{definition.mode_key!r}"
            )
        mode = next(item for item in modes if item.key == definition.mode_key)
        if mode.family != definition.family:
            raise ValueError(
                f"{path}: {definition.key} family does not match its mode"
            )
        unknown_modes = set(definition.active_mode_keys) - known_modes
        if unknown_modes:
            raise ValueError(
                f"{path}: {definition.key} references unknown active modes"
            )
        if any(
            next(item for item in modes if item.key == mode_key).family
            != definition.family
            for mode_key in definition.active_mode_keys
        ):
            raise ValueError(
                f"{path}: {definition.key} active modes do not match its family"
            )
        if not (
            0.0 < definition.minimum
            <= definition.default_value
            <= definition.maximum
        ):
            raise ValueError(
                f"{path}: {definition.key} has an invalid target range"
            )
        if definition.devices != expected_devices[definition.key]:
            raise ValueError(
                f"{path}: {definition.key} must couple "
                + ", ".join(expected_devices[definition.key])
            )
        if (
            definition.state_parameters
            != expected_state_parameters[definition.key]
        ):
            raise ValueError(
                f"{path}: {definition.key} has an invalid state parameter set"
            )
        if not definition.unit.strip():
            raise ValueError(f"{path}: {definition.key} unit is empty")
        if not definition.calibration_status.strip():
            raise ValueError(
                f"{path}: {definition.key} calibration status is empty"
            )
        if not definition.calibration_reference.strip():
            raise ValueError(
                f"{path}: {definition.key} calibration reference is empty"
            )
    return OperatingModeCatalog(
        modes, constraints, direct_alignments, path, column_overrides
    )


def mode_by_key(
    key: str, catalog: OperatingModeCatalog | None = None, *, column_name: str | None = None
) -> OperatingModeDefinition:
    catalog = catalog or load_operating_mode_catalog()
    override = catalog.column_overrides.get(str(column_name), {}).get(str(key))
    if override is not None:
        return override
    try:
        mode = next(mode for mode in catalog.modes if mode.key == str(key))
        if column_name == "C2" and mode.family == "condenser":
            raise ValueError(f"{mode.name} has no independent C2 operating reference")
        return mode
    except StopIteration as exc:
        choices = ", ".join(mode.key for mode in catalog.modes)
        raise KeyError(f"Unknown operating mode {key!r}; choices: {choices}") from exc


def direct_alignment_by_key(
    key: str, catalog: OperatingModeCatalog | None = None
) -> DirectAlignmentDefinition:
    # Recovery is separate from the four calibrated imaging observables and
    # intentionally has no Nano/Microprobe focus claim or preset entry.
    if key == "column_transport":
        from temsim.optics.transport_matching import DEFINITION
        return DEFINITION
    if key == "beam_centre_direction":
        from temsim.beam_alignment import DEFINITION
        return DEFINITION
    if key == "condenser_twofold_shape":
        from temsim.stigmator_alignment import DEFINITION
        return DEFINITION
    catalog = catalog or load_operating_mode_catalog()
    try:
        return next(
            definition
            for definition in catalog.direct_alignments
            if definition.key == str(key)
        )
    except StopIteration as exc:
        choices = ", ".join(
            definition.key for definition in catalog.direct_alignments
        )
        raise KeyError(
            f"Unknown direct alignment {key!r}; choices: {choices}"
        ) from exc


def compatible_modes(
    family: str,
    column_name: str,
    recording_name: str,
    catalog: OperatingModeCatalog | None = None,
) -> tuple[OperatingModeDefinition, ...]:
    """Return catalog modes that can be shown for one loaded assembly."""

    catalog = catalog or load_operating_mode_catalog()

    def matches(values: tuple[str, ...], selected: str) -> bool:
        return "*" in values or selected in values

    return tuple(
        mode
        for original in catalog.modes
        if (matches(original.compatible_columns, column_name)
            or original.key in catalog.column_overrides.get(column_name, {}))
        for mode in (mode_by_key(original.key, catalog, column_name=column_name),)
        if mode.family == family
        and matches(mode.compatible_columns, column_name)
        and matches(mode.compatible_recording_systems, recording_name)
    )


def _apply_values(state, mode: OperatingModeDefinition) -> tuple[str, ...]:
    # Imported lazily to keep catalog parsing independent of the runtime GUI.
    from temsim.runtime_parameters import (
        runtime_targets,
        validate_runtime_assignment,
    )

    targets = runtime_targets(state)
    mini = targets.get("mini_condenser")
    controls_mini_mode = (
        mode.family == "condenser"
        and (mode.key == "micro_probe" or is_nanoprobe_mode(mode.key))
        and "mini_condenser" in mode.devices
    )
    if controls_mini_mode and mini is not None:
        # Validate before applying any preset values. Old cached definitions
        # may still carry distinct CM percentages; they are not mode inputs.
        mini.obj.validate_probe_mode("nano_probe" if is_nanoprobe_mode(mode.key) else mode.key)
    changed = []
    for group in (mode.devices, mode.apertures):
        for key, values in group.items():
            try:
                target = targets[key]
            except KeyError as exc:
                raise ValueError(
                    f"Operating mode {mode.key!r} references missing device {key!r}"
                ) from exc
            if key == "mini_condenser" and controls_mini_mode:
                target.obj.set_probe_mode("nano_probe" if is_nanoprobe_mode(mode.key) else mode.key)
            for field, raw_value in values.items():
                if key == "mini_condenser" and controls_mini_mode and field in {
                    "percent", "polarity", "field_polarity", "enabled",
                }:
                    continue
                runtime_field = {
                    "field_polarity": "polarity",
                }.get(field, field)
                if not hasattr(target.obj, runtime_field):
                    raise ValueError(
                        f"Operating mode {mode.key!r}: {key}.{field} does not exist"
                    )
                value = validate_runtime_assignment(
                    target, runtime_field, raw_value
                )
                setattr(target.obj, runtime_field, value)
            changed.append(key)
    return tuple(changed)


def _apply_operating_mode_pair(
    state,
    condenser_key: str,
    projector_key: str | None,
    *,
    column_name: str | None = None,
    recording_name: str | None = None,
    catalog: OperatingModeCatalog | None = None,
) -> AppliedOperatingModes:
    """Apply one independently selectable illumination/projector preset pair."""

    catalog = catalog or load_operating_mode_catalog()
    column_name = _operating_column_name(state, column_name)
    condenser = mode_by_key(condenser_key, catalog, column_name=column_name)
    projector = mode_by_key(projector_key, catalog, column_name=column_name) if projector_key is not None else None
    if condenser.family != "condenser" or (projector is not None and projector.family != "projector"):
        raise ValueError("A mode pair requires one condenser and one projector mode")

    def require_compatible(mode: OperatingModeDefinition) -> None:
        if (
            column_name is not None
            and "*" not in mode.compatible_columns
            and column_name not in mode.compatible_columns
        ):
            raise ValueError(f"{mode.name} is not calibrated for {column_name}")
        if (
            recording_name is not None
            and "*" not in mode.compatible_recording_systems
            and recording_name not in mode.compatible_recording_systems
        ):
            raise ValueError(f"{mode.name} is not calibrated for {recording_name}")

    require_compatible(condenser)
    if projector is not None:
        require_compatible(projector)
    if "mini_condenser" in condenser.devices:
        state.mini_condenser.validate_probe_mode(
            "nano_probe" if is_nanoprobe_mode(condenser.key) else condenser.key)

    state.illumination_mode = {
        "micro_probe": "TEM",
        "nano_probe": "STEM",
        "nano_probe_large_angle": "STEM",
    }[condenser.key]
    if is_nanoprobe_mode(condenser.key):
        state.nanoprobe_range = "large_angle" if condenser.key == "nano_probe_large_angle" else "normal"
    if projector is not None:
        state.projector_mode = {
            "imaging": "image",
            "diffraction": "diffraction",
        }[projector.key]
    # A physical TEM screen/camera path and the inserted STEM detector stack
    # are mutually exclusive presets.  In TEM, retract annular/disk STEM
    # detectors before wave propagation; in STEM, retract the fluorescent
    # screen and Camera so they cannot stop rays between detector channels.
    if state.illumination_mode == "TEM":
        for detector in getattr(state, "stem_detectors", ()):
            detector.inserted = False
            detector.readout_enabled = False
        if not (
            bool(getattr(state.fluorescent_screen, "inserted", False))
            or bool(getattr(state.camera, "inserted", False))
        ):
            # The Camera branch owns the complete configured camera-length
            # range.  Keep a real recording target after a STEM -> TEM switch;
            # users can insert the FluScreen instead and re-run alignment for
            # that upstream plane.
            state.camera.inserted = True
    else:
        for detector in getattr(state, "stem_detectors", ()):
            detector.inserted = True
            detector.readout_enabled = True
        state.fluorescent_screen.inserted = False
        state.camera.inserted = False
    changed = _apply_values(state, condenser)
    if projector is not None:
        changed += _apply_values(state, projector)
    if not bool(getattr(state, "monochromator_installed", False)):
        state.condenser_aperture_3.radius_mm = (
            state.condenser_aperture_3.maximum_radius_mm
        )

    state.sync_objective()
    if bool(getattr(getattr(state, "nanopulser", None), "installed", False)):
        from temsim.optics.condenser_recalibration import (
            recalibrate_nanopulser_condenser,
        )
        condenser = recalibrate_nanopulser_condenser(state, condenser, catalog)
    image_projection = None
    if projector is not None and projector.key == "imaging":
        from temsim.optics.projector_reference import focus_image_projector
        image_projection = focus_image_projector(state)
    return AppliedOperatingModes(condenser, projector, changed, image_projection)


def apply_operating_mode_pair(
    state,
    condenser_key: str,
    projector_key: str | None,
    *,
    column_name: str | None = None,
    recording_name: str | None = None,
    catalog: OperatingModeCatalog | None = None,
) -> AppliedOperatingModes:
    """Apply presets; an installed Electrostatic beam blanker requires a validated live solve.

    The additional gun-to-C1 distance changes the incident beam.  Do not leave
    a partially applied pair when its recalculation cannot meet the requested
    sample illumination and focus constraints.
    """
    if catalog is None:
        from temsim.simulation_modes import mode_key
        catalog = load_operating_mode_catalog(mode_key(state))
    column_name = _operating_column_name(state, column_name)
    arguments = dict(
        column_name=column_name, recording_name=recording_name, catalog=catalog,
    )
    from temsim.runtime_parameters import runtime_targets

    targets = runtime_targets(state)
    saved = []
    for key in (condenser_key, projector_key):
        if key is None:
            continue
        definition = mode_by_key(key, catalog, column_name=column_name)
        for group in (definition.devices, definition.apertures):
            for device_key, values in group.items():
                obj = targets[device_key].obj
                if device_key == "mini_condenser" and definition.family == "condenser":
                    # The mode helper owns the sign even if a historical
                    # definition omitted an explicit polarity field.
                    saved.append((obj, "polarity", obj.polarity))
                for field in values:
                    field = {"field_polarity": "polarity"}.get(field, field)
                    saved.append((obj, field, getattr(obj, field)))
    saved.extend((
        (state, "illumination_mode", state.illumination_mode),
        (state, "nanoprobe_range", state.nanoprobe_range),
        (state, "projector_mode", state.projector_mode),
        (state.condenser_aperture_3, "radius_mm", state.condenser_aperture_3.radius_mm),
    ))
    for device in (*getattr(state, "stem_detectors", ()),
                   state.fluorescent_screen, state.camera):
        for field in ("inserted", "readout_enabled"):
            if hasattr(device, field):
                saved.append((device, field, getattr(device, field)))
    try:
        return _apply_operating_mode_pair(
            state, condenser_key, projector_key, **arguments
        )
    except Exception:
        for obj, field, value in reversed(saved):
            setattr(obj, field, value)
        state.sync_objective()
        raise


def apply_condenser_mode(
    state, condenser_key: str, *, column_name: str | None = None,
    recording_name: str | None = None, catalog: OperatingModeCatalog | None = None,
) -> AppliedOperatingModes:
    """Apply illumination transactionally without loading a projector preset.

    A downstream image corrector can share validated incident optics while
    its projector/recording-plane conjugacy remains separately unqualified.
    Blanker recalibration and rollback use the complete-preset transaction.
    """
    return apply_operating_mode_pair(
        state, condenser_key, None, column_name=column_name,
        recording_name=recording_name, catalog=catalog,
    )


def apply_projector_mode(
    state, projector_key: str, *, column_name: str | None = None,
    recording_name: str | None = None, catalog: OperatingModeCatalog | None = None,
) -> AppliedProjectorMode:
    """Apply D/I/P1/P2 while retaining the incident working point.

    Image refocuses D/I to the active screen or Camera reference and validates
    the first-order sample image. Diffraction applies its stored strengths.
    The Objective, physical tip, receiver insertion and held scan record stay
    owned by the current working point. Image callers should run asynchronously.
    """
    column_name = _operating_column_name(state, column_name)
    projector = mode_by_key(projector_key, catalog or load_operating_mode_catalog(), column_name=column_name)
    if projector.family != "projector" or projector.key not in {"imaging", "diffraction"}:
        raise ValueError("A projector switch requires Image or Diffraction")
    for selected, supported, label in (
        (column_name, projector.compatible_columns, "column"),
        (recording_name, projector.compatible_recording_systems, "recording system"),
    ):
        if selected is not None and "*" not in supported and selected not in supported:
            raise ValueError(f"{projector.name} is not compatible with {label} {selected}")
    allowed = {"diffraction_lens", "intermediate_lens", "projector_lens_1", "projector_lens_2"}
    if set(projector.devices) - allowed or projector.apertures:
        raise ValueError("A projector-only preset may change only D/I/P1/P2")
    from temsim.runtime_parameters import runtime_targets
    targets = runtime_targets(state)
    saved = [(targets[key].obj, dict(vars(targets[key].obj))) for key in projector.devices]
    previous_mode = state.projector_mode
    try:
        changed = _apply_values(state, projector)
        state.projector_mode = {"imaging": "image", "diffraction": "diffraction"}[projector.key]
        image_projection = None
        if projector.key == "imaging":
            from temsim.optics.projector_reference import focus_image_projector
            image_projection = focus_image_projector(state)
    except Exception:
        for obj, values in saved:
            obj.__dict__.clear()
            obj.__dict__.update(values)
        state.projector_mode = previous_mode
        raise
    return AppliedProjectorMode(projector, changed, image_projection)
