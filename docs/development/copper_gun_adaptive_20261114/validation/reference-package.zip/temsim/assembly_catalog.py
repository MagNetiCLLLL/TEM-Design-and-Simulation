"""Catalog-backed selection of complete TEM assemblies."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from temsim import input_io
import tomllib

from temsim import module_manifest
from temsim.column.state_layout import apply_physical_layout_to_state
from temsim.optics.corrector_structure import ensure_corrector_structure
from temsim.paths import INSTRUMENT_CONFIG_ROOT


@dataclass(frozen=True, slots=True)
class AssemblyOption:
    name: str
    file: str
    properties: dict[str, object]


@dataclass(frozen=True, slots=True)
class AssemblySelection:
    gun: str
    column: str
    recording: str
    beam_blanker: str = "None"


class AssemblyCatalog:
    def __init__(self, root: Path = INSTRUMENT_CONFIG_ROOT) -> None:
        self.root = Path(root).resolve()
        with input_io.open_input(self.root / "catalog.toml") as stream:
            document = tomllib.load(stream)
        self._validate_document(document)
        self.guns = self._options(document["gun_variants"])
        self.columns = self._options(document["column_variants"])
        self.beam_blankers = (
            AssemblyOption("None", "", {"installed": False}),
            *self._options(document.get("beam_blanker_variants", ())),
        )
        self._recording_system_modules = self._options(
            document["project_and_recording_system_variants"]
        )
        self.recording_systems = tuple(
            option
            for option in self._recording_system_modules
            if bool(option.properties.get("selectable", True))
        )

    def _validate_document(self, document) -> None:
        if int(document.get("format_version", 0)) != 1:
            raise ValueError("Unsupported instrument-catalog format")
        if document.get("coordinate_system") != "module_local_z_mm":
            raise ValueError("Invalid instrument-catalog coordinate system")

        required = (
            ("gun", "gun_variants"),
            ("column", "column_variants"),
            (
                "project_and_recording_system",
                "project_and_recording_system_variants",
            ),
        )
        has_blanker = bool(document.get("beam_blanker_variants"))
        expected = (
            required[:1]
            + (("beam_blanker", "beam_blanker_variants"),)
            + required[1:]
            if has_blanker else required
        )
        order = tuple(document.get("assembly", {}).get("order", ()))
        expected_order = tuple(module_type for module_type, _ in expected)
        if order != expected_order:
            raise ValueError(
                "Instrument catalog assembly order must be exactly "
                f"{expected_order}, found {order}"
            )

        selected_files: list[str] = []
        module_keys: list[str] = []
        for module_type, group in expected:
            entries = tuple(document.get(group, ()))
            if not entries:
                raise ValueError(f"Instrument catalog has no {group}")
            names = [str(entry["name"]) for entry in entries]
            if module_type == "beam_blanker":
                if "None" in names or any(
                    entry.get("installed") is not True for entry in entries
                ):
                    raise ValueError(
                        "Beam-blanker catalog entries must describe installed "
                        "modules; None is the implicit absent selection"
                    )
            if module_type == "column":
                for entry in entries:
                    if entry.get("image_corrector", False) and entry.get("image_corrector_design", "cetcor") not in {"cetcor", "bcor"}:
                        raise ValueError("Image-corrector catalog design must be cetcor or bcor")
            files = [Path(str(entry["file"])).as_posix() for entry in entries]
            signatures = [
                tuple(sorted(
                    (str(key), repr(value))
                    for key, value in entry.items()
                    if key not in {"name", "file"}
                ))
                for entry in entries
            ]
            for label, values in (
                ("name", names),
                ("file", files),
                ("selection properties", signatures),
            ):
                if len(set(values)) != len(values):
                    raise ValueError(
                        f"Duplicate {label} in instrument catalog {group}"
                    )
            for relative in files:
                path = (self.root / relative).resolve()
                if not path.is_relative_to(self.root):
                    raise ValueError(
                        f"Instrument module escapes catalog root: {relative}"
                    )
                if not input_io.is_file(path):
                    raise ValueError(
                        f"Instrument catalog module does not exist: {relative}"
                    )
                module_document = module_manifest.read_document(path)
                module_manifest.validate_document(module_document)
                if module_type == "column":
                    entry = next(item for item in entries if Path(str(item["file"])).as_posix() == relative)
                    if bool(entry.get("image_corrector", False)):
                        declared = str(entry.get("image_corrector_design", "cetcor"))
                        actual = str(module_document["module"].get("image_corrector_design", "cetcor"))
                        if declared != actual:
                            raise ValueError(f"Image-corrector design mismatch for {relative}: {declared} != {actual}")
                actual_type = str(module_document["module"]["type"])
                if actual_type != module_type:
                    raise ValueError(
                        f"Instrument module {relative} has type "
                        f"{actual_type!r}, expected {module_type!r}"
                    )
                module_keys.append(str(module_document["module"]["key"]))
            selected_files.extend(files)

        if len(set(selected_files)) != len(selected_files):
            raise ValueError("Instrument module file is listed more than once")
        if len(set(module_keys)) != len(module_keys):
            raise ValueError("Instrument module key is defined more than once")

        selectable_recordings = tuple(
            entry
            for entry in document["project_and_recording_system_variants"]
            if bool(entry.get("selectable", True))
        )
        if any(
            not isinstance(entry.get("selectable", True), bool)
            for entry in document["project_and_recording_system_variants"]
        ):
            raise ValueError(
                "Instrument recording-system selectable flags must be Boolean"
            )
        if not selectable_recordings:
            raise ValueError("Instrument catalog must expose a recording system")
        disk_files = {
            path.relative_to(self.root).as_posix()
            for path in input_io.input_paths(self.root, "*.toml", recursive=True)
            if path.name != "catalog.toml"
        }
        catalog_files = set(selected_files)
        if disk_files != catalog_files:
            raise ValueError(
                "Instrument TOML/catalog mismatch: "
                f"unlisted={sorted(disk_files - catalog_files)}, "
                f"missing={sorted(catalog_files - disk_files)}"
            )

    @staticmethod
    def _options(entries) -> tuple[AssemblyOption, ...]:
        return tuple(
            AssemblyOption(
                name=str(entry["name"]),
                file=str(entry["file"]),
                properties={
                    key: value
                    for key, value in entry.items()
                    if key not in {"name", "file"}
                },
            )
            for entry in entries
        )

    @staticmethod
    def _by_name(options, name: str) -> AssemblyOption:
        try:
            return next(option for option in options if option.name == name)
        except StopIteration as exc:
            raise ValueError(f"Unknown assembly option: {name}") from exc

    def default_selection(self) -> AssemblySelection:
        return AssemblySelection(
            gun="FEG",
            column="C3 + Probe Corrector",
            recording=next(o.name for o in self.recording_systems
                           if o.properties.get("energy_filter") is False),
        )

    def selection_for_resolved(self, assembly) -> AssemblySelection:
        """Read the captured module identities without applying defaults."""
        paths = dict(assembly.selected_module_paths)
        def selected(kind, options):
            path = paths.get(kind, "")
            matches = [option.name for option in options if option.file == path]
            if len(matches) != 1:
                raise ValueError(f"Captured {kind} module is not uniquely available in this catalog")
            return matches[0]
        return AssemblySelection(
            gun=selected("gun", self.guns), column=selected("column", self.columns),
            recording=selected("project_and_recording_system", self._recording_system_modules),
            beam_blanker=selected("beam_blanker", self.beam_blankers))

    def normalise_selection(
        self, selection: AssemblySelection
    ) -> AssemblySelection:
        """Validate explicit current hardware choices without renaming them."""

        # Keep explicit installation choices, including no filter.
        self._by_name(self.recording_systems, selection.recording)
        self._by_name(self.guns, selection.gun)
        self._by_name(self.columns, selection.column)
        blanker = selection.beam_blanker
        self._by_name(self.beam_blankers, blanker)
        return AssemblySelection(
            gun=selection.gun,
            column=selection.column,
            recording=selection.recording,
            beam_blanker=blanker,
        )

    def selected_paths(self, selection: AssemblySelection) -> dict[str, str]:
        selection = self.normalise_selection(selection)
        paths = {
            "gun": self._by_name(self.guns, selection.gun).file,
        }
        if selection.beam_blanker != "None":
            paths["beam_blanker"] = self._by_name(
                self.beam_blankers, selection.beam_blanker
            ).file
        paths.update({
            "column": self._by_name(self.columns, selection.column).file,
            "project_and_recording_system": self._by_name(
                self.recording_systems, selection.recording
            ).file,
        })
        return paths

    def apply(
        self,
        state,
        selection: AssemblySelection,
        *,
        preserve_operating_parameters: bool = False,
    ):
        """Resolve one complete assembly into ``state``.

        A newly selected assembly starts from its manifest defaults.  Editors
        that merely reload geometry for the already installed assembly may
        instead retain the live lens strengths and apply a preset explicitly
        after all mechanical edits are complete.
        """
        selection = self.normalise_selection(selection)
        gun = self._by_name(self.guns, selection.gun)
        column = self._by_name(self.columns, selection.column)
        recording = self._by_name(self.recording_systems, selection.recording)
        retained_component_keys = set(getattr(state, "image_corrector_initialized_keys", ()))
        retained_component_keys.update(getattr(state, "_module_manifest_parts", {}))
        from temsim.optics.nanopulser import ensure_nanopulser
        ensure_nanopulser(state).installed = selection.beam_blanker != "None"

        gun_type = (
            "thermionic"
            if gun.properties["electron_gun"] == "Thermionic"
            else "cold_feg"
        )
        if state.electron_gun.type_key != gun_type:
            state.select_electron_gun(gun_type)
        installed = bool(gun.properties.get("monochromator", False))
        if state.monochromator_installed != installed:
            # The setter reloads the global catalog. An unchanged selection
            # must keep this catalog's resolved defaults and live overrides.
            state.monochromator_installed = installed

        has_c3 = bool(column.properties["c3_lens"])
        has_probe = bool(column.properties["probe_corrector"])
        has_image = bool(column.properties["image_corrector"])
        if has_probe and has_image:
            corrector_mode = "double_corrector"
        elif has_probe:
            corrector_mode = "probe_corrector"
        elif has_image:
            corrector_mode = "image_corrector"
        else:
            corrector_mode = "no_corrector"
        state.corrector_mode = corrector_mode
        state.probe_corrector_installed = has_probe
        state.image_corrector_installed = has_image
        state.image_corrector_design = str(column.properties.get("image_corrector_design", "cetcor"))
        state.layout_c3_hardware = "three_condenser" if has_c3 else "two_condenser"
        state.layout_c3_excited = has_c3
        state.column_mode = "three_lens" if has_c3 else "two_condenser"

        has_filter = bool(recording.properties["energy_filter"])
        state.energy_filter_mode = "energy_filter" if has_filter else "no_energy_filter"
        state.energy_filter_installed = has_filter
        from temsim.optics.energy_filter import ensure_energy_filter
        if getattr(state, "energy_filter", None) is not None:
            state.energy_filter.enabled = has_filter
        ensure_energy_filter(state)
        ensure_corrector_structure(state)
        # Fresh hardware receives its manifest working point. This is an
        # explicit installation operation, unlike state/profile restoration,
        # which must keep the supplied drive values even without a prior
        # in-memory resolved assembly.
        state._initialise_new_assembly_hardware = frozenset(
            item.key for item in (*state.lenses, *state.corrector_elements)
            if item.key not in retained_component_keys
        )
        try:
            apply_physical_layout_to_state(
                state,
                preserve_operating_parameters=preserve_operating_parameters,
                assembly_root=self.root,
            )
        finally:
            del state._initialise_new_assembly_hardware
        state.electron_gun._manifest_catalog_root = self.root
        if not preserve_operating_parameters and state.electron_gun.type_key == "cold_feg":
            from temsim.optics.electron_gun.tip_assembly import apply_tip_part
            apply_tip_part(state.electron_gun.emitter,
                           state._resolved_assembly.part("feg_tip").data, reset_source=True)
        from temsim.component_keys import (
            CAMERA,
            FLUORESCENT_SCREEN,
        )
        from temsim.detector.recording_system import ensure_recording_system
        ensure_recording_system(state)
        if not preserve_operating_parameters:
            for plane in state.recording_planes:
                if plane.key in {
                    FLUORESCENT_SCREEN,
                    CAMERA,
                }:
                    # Initial installation retracts recording surfaces before
                    # the Energy Filter. A geometry reload must keep the user's
                    # physical interception/readout choices, even with a filter.
                    plane.inserted = not has_filter
            state.condenser_aperture_3.radius_mm = (
                0.05
                if state.monochromator_installed
                else state.condenser_aperture_3.maximum_radius_mm
            )
        return state._resolved_assembly
